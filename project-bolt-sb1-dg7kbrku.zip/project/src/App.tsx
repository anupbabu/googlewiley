import React, { useState, useEffect } from 'react';
import { Shield, FileText, Calendar, Settings } from 'lucide-react';
import { DataSource, AuditReport, ComparisonResult, AuditType } from './types/audit';
import { DataExtractionPanel } from './components/DataExtractionPanel';
import { DataComparisonPanel } from './components/DataComparisonPanel';
import { ReportPanel } from './components/ReportPanel';
import { TestDataPanel } from './components/TestDataPanel';
import { AuditTypeSelector } from './components/AuditTypeSelector';
import { AdminPanel } from './components/AdminPanel';
import { DataMatcher } from './services/dataMatcher';
import { ReportGenerator } from './services/reportGenerator';
import { TestDataGenerator } from './data/testData';
import { AuditTypeService } from './data/auditTypes';
import { LLMConfigService } from './services/llmConfigService';

function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [auditId] = useState(TestDataGenerator.generateAuditId());
  const [contractNumber, setContractNumber] = useState(TestDataGenerator.generateContractNumber());
  const [selectedAuditType, setSelectedAuditType] = useState<AuditType>('contract-to-invoice');
  const [showTestPanel, setShowTestPanel] = useState(true);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [sampleText, setSampleText] = useState('');
  const [dataSources, setDataSources] = useState<DataSource[]>([
    {
      id: 'pdf',
      name: 'Order Form',
      type: 'pdf',
      status: 'pending',
      data: null
    },
    {
      id: 'sap',
      name: 'SAP System',
      type: 'sap',
      status: 'pending',
      data: null
    },
    {
      id: 'oreo',
      name: 'OREO UI',
      type: 'oreo',
      status: 'pending',
      data: null
    },
    {
      id: 'mithra',
      name: 'Mithra/Billy System',
      type: 'mithra',
      status: 'pending',
      data: null
    }
  ]);
  const [comparisons, setComparisons] = useState<ComparisonResult[]>([]);
  const [isComparing, setIsComparing] = useState(false);
  const [auditReport, setAuditReport] = useState<AuditReport | null>(null);

  // Update data source names based on selected audit type
  useEffect(() => {
    const auditConfig = AuditTypeService.getAuditTypeConfig(selectedAuditType);
    const sourceLabels = AuditTypeService.getDataSourceLabels(selectedAuditType);
    
    setDataSources(prev => {
      const updatedSources = [...prev];
      
      // Update the first three sources based on audit type
      if (sourceLabels[0]) updatedSources[0] = { ...updatedSources[0], name: sourceLabels[0] };
      if (sourceLabels[1]) updatedSources[1] = { ...updatedSources[1], name: sourceLabels[1] };
      if (sourceLabels[2]) updatedSources[2] = { ...updatedSources[2], name: sourceLabels[2] };
      
      // Reset all sources
      return updatedSources.map(source => ({
        ...source,
        status: 'pending',
        data: null,
        error: undefined
      }));
    });
    
    // Reset state when audit type changes
    setComparisons([]);
    setAuditReport(null);
    setCurrentStep(1);
  }, [selectedAuditType]);

  const handleDataSourceUpdate = (updatedSource: DataSource) => {
    setDataSources(prev => 
      prev.map(source => 
        source.id === updatedSource.id ? updatedSource : source
      )
    );
  };

  const handleLoadTestData = (testDataSources: DataSource[], testContractNumber: string) => {
    setDataSources(testDataSources);
    setContractNumber(testContractNumber);
    setComparisons([]);
    setAuditReport(null);
    setCurrentStep(1);
  };

  const handleLoadSampleText = (text: string) => {
    setSampleText(text);
  };

  const getRequiredSources = () => {
    const auditConfig = AuditTypeService.getAuditTypeConfig(selectedAuditType);
    const requiredTypes = ['pdf', 'sap'];
    
    // For Contract to Provisioning, include both OREO and Mithra/Billy
    if (selectedAuditType === 'contract-to-provisioning') {
      requiredTypes.push('oreo', 'mithra');
    } else if (auditConfig.dataSources.tertiary) {
      if (auditConfig.dataSources.tertiary.includes('OREO')) requiredTypes.push('oreo');
      if (auditConfig.dataSources.tertiary.includes('Mithra')) requiredTypes.push('mithra');
    }
    
    return dataSources.filter(ds => requiredTypes.includes(ds.type));
  };

  const allDataExtracted = getRequiredSources().every(source => source.status === 'success' && source.data);

  const runComparison = async () => {
    if (!allDataExtracted) return;
    
    setIsComparing(true);
    setCurrentStep(3); // Move to step 3 immediately when GenAI is triggered

    try {
      // Use GenAI-powered comparison
      const matcher = new DataMatcher();
      const requiredSources = getRequiredSources();
      
      console.log('Starting GenAI-powered data comparison...');
      
      // Use AI comparison with enhanced processing time simulation
      await new Promise(resolve => setTimeout(resolve, 2000)); // Slightly longer for AI processing
      
      const results = await matcher.compareDataWithAI(
        requiredSources[0]?.data!,
        requiredSources[1]?.data!,
        requiredSources[2]?.data || null,
        requiredSources[3]?.data || null,
        selectedAuditType
      );
      
      setComparisons(results);
      
      // Get AI Agent ID from active LLM configuration
      const activeConfig = LLMConfigService.getActiveConfig();
      const aiAgentId = activeConfig ? `${activeConfig.provider.toUpperCase()}-${activeConfig.model}-${Date.now().toString().slice(-6)}` : undefined;
      
      // Auto-generate report after comparison
      const report = ReportGenerator.generateReport(
        auditId,
        contractNumber,
        selectedAuditType,
        dataSources,
        results,
        aiAgentId
      );
      
      setAuditReport(report);
      setCurrentStep(3);
    } catch (error) {
      console.error('AI comparison failed, falling back to rule-based comparison:', error);
      
      // Fallback to traditional rule-based comparison
      const matcher = new DataMatcher();
      const requiredSources = getRequiredSources();
      
      const results = matcher.compareData(
        requiredSources[0]?.data!,
        requiredSources[1]?.data!,
        requiredSources[2]?.data || null,
        requiredSources[3]?.data || null
      );
      
      setComparisons(results);
      
      // Generate fallback AI Agent ID
      const fallbackAiAgentId = `FALLBACK-RULES-${Date.now().toString().slice(-6)}`;
      
      const report = ReportGenerator.generateReport(
        auditId,
        contractNumber,
        selectedAuditType,
        dataSources,
        results,
        fallbackAiAgentId
      );
      
      setAuditReport(report);
      setCurrentStep(3);
    } finally {
      setIsComparing(false);
    }
  };


  const getStepClass = (step: number) => {
    // Step 3 should be green immediately when GenAI is triggered (currentStep = 3)
    if (step < currentStep || (step === 3 && currentStep === 3)) return 'bg-green-500 text-white';
    // Step 2 should be blue while processing (when currentStep = 3 and isComparing = true)
    if (step === 2 && currentStep === 3 && isComparing) return 'bg-blue-500 text-white';
    return 'bg-gray-300 text-gray-600';
  };

  const auditConfig = AuditTypeService.getAuditTypeConfig(selectedAuditType);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Comprehensive Compliance Audit System
                </h1>
                <p className="text-sm text-gray-600 mt-1">
                  End-to-end contract data extraction, comparison, and reporting
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4" />
                <span>Audit ID: {auditId}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4" />
                <span>{new Date().toLocaleDateString()}</span>
              </div>
              <button
                onClick={() => setShowTestPanel(!showTestPanel)}
                className="px-4 py-2 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 text-sm font-medium"
              >
                {showTestPanel ? 'Hide' : 'Show'} Test Data
              </button>
              <button
                onClick={() => setShowAdminPanel(!showAdminPanel)}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 text-sm font-medium"
              >
                <Settings className="h-4 w-4" />
                <span>Admin</span>
              </button>
            </div>
          </div>
          
          {/* Contract Info and Audit Type Selector */}
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700">Contract Number: </span>
              <span className="text-sm font-mono text-gray-900">{contractNumber}</span>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Audit Type
              </label>
              <AuditTypeSelector
                selectedAuditType={selectedAuditType}
                onAuditTypeChange={setSelectedAuditType}
              />
            </div>
          </div>

          {/* Audit Type Info */}
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-sm font-semibold text-blue-800">Current Audit:</span>
              <span className="text-sm text-blue-700">{auditConfig.name}</span>
            </div>
            <p className="text-sm text-blue-600 mb-2">{auditConfig.description}</p>
            <div className="text-xs text-blue-500">
              <strong>Data Flow:</strong> {auditConfig.dataSources.primary} → {auditConfig.dataSources.secondary}
              {auditConfig.dataSources.tertiary && ` → ${auditConfig.dataSources.tertiary}`}
            </div>
          </div>
        </div>
      </div>

      {/* Admin Panel Modal */}
      {showAdminPanel && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full mx-4 max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <div className="flex items-center space-x-3">
                <Settings className="h-6 w-6 text-gray-600" />
                <h3 className="text-lg font-semibold">Admin Panel</h3>
              </div>
              <button
                onClick={() => setShowAdminPanel(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
              <AdminPanel />
            </div>
          </div>
        </div>
      )}

      {/* Progress Steps */}
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex items-center justify-center space-x-8 mb-8">
          <div className="flex items-center space-x-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${getStepClass(1)}`}>
              1
            </div>
            <span className="text-sm font-medium text-gray-700">Data Extraction</span>
          </div>
          <div className="w-16 h-0.5 bg-gray-300"></div>
          <div className="flex items-center space-x-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${getStepClass(2)}`}>
              2
            </div>
            <span className="text-sm font-medium text-gray-700">GenAI Analysis</span>
          </div>
          <div className="w-16 h-0.5 bg-gray-300"></div>
          <div className="flex items-center space-x-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${getStepClass(3)}`}>
              3
            </div>
            <span className="text-sm font-medium text-gray-700">Audit Report Generation</span>
          </div>
        </div>

        {/* Content Panels */}
        <div className="space-y-8">
          {/* Test Data Panel */}
          {showTestPanel && (
            <TestDataPanel
              onLoadTestData={handleLoadTestData}
              onLoadSampleText={handleLoadSampleText}
            />
          )}

          {/* Step 1: Data Extraction */}
          <DataExtractionPanel
            dataSources={dataSources}
            onDataSourceUpdate={handleDataSourceUpdate}
            contractNumber={contractNumber}
            sampleText={sampleText}
            auditType={selectedAuditType}
          />

          {/* Step 2: Data Comparison */}
          {(currentStep >= 2 || allDataExtracted) && (
            <DataComparisonPanel
              comparisons={comparisons}
              isLoading={isComparing}
              allDataExtracted={allDataExtracted}
              onRunComparison={runComparison}
            />
          )}

          {/* Step 3: Report Generation */}
          {(currentStep >= 3 || auditReport) && (
            <ReportPanel
              report={auditReport}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;