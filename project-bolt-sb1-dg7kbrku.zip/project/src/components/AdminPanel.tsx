import React, { useState, useEffect } from 'react';
import { Settings, Upload, FileText, Brain, Save, Plus, Trash2, AlertCircle, CheckCircle, Info, MessageSquare, Edit3, Copy, Zap, MoreVertical, Cpu } from 'lucide-react';
import { GenAIDataMatcher } from '../services/genAIDataMatcher';
import { GenAIService } from '../services/genAIService';
import { PromptLibraryPanel } from './PromptLibraryPanel';
import { LLMConfigPanel } from './LLMConfigPanel';
import { PromptLibraryService } from '../services/promptLibrary';
import { AuditType } from '../types/audit';
import { AUDIT_TYPE_CONFIGS } from '../data/auditTypes';

interface ValidationRule {
  id: string;
  category: string;
  condition: string;
  enforcement: string;
  auditType?: AuditType;
  rubric?: string;
  priority?: 'high' | 'medium' | 'low';
  description?: string;
  rule?: string;
}

export const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'knowledge' | 'prompts' | 'llm-config'>('knowledge');
  const [knowledgeFile, setKnowledgeFile] = useState<File | null>(null);
  const [knowledgeText, setKnowledgeText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedRules, setExtractedRules] = useState<ValidationRule[]>([]);
  const [filteredRules, setFilteredRules] = useState<ValidationRule[]>([]);
  const [editingRule, setEditingRule] = useState<string | null>(null);
  const [extractionResult, setExtractionResult] = useState<{
    confidence: number;
    processingNotes?: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openActionMenu, setOpenActionMenu] = useState<string | null>(null);
  
  // Filter states
  const [selectedAuditTypeForRules, setSelectedAuditTypeForRules] = useState<AuditType>('contract-to-provisioning');
  const [selectedRubric, setSelectedRubric] = useState<string>('all');
  
  // Knowledge extraction filter states
  const [selectedAuditTypeForKnowledge, setSelectedAuditTypeForKnowledge] = useState<AuditType>('contract-to-provisioning');
  const [selectedRubricForKnowledge, setSelectedRubricForKnowledge] = useState<string>('all');

  // Filter options
  const auditTypeOptions: { value: AuditType; label: string }[] = [
    { value: 'contract-to-provisioning', label: 'Contract to Provisioning' },
    { value: 'contract-to-invoice', label: 'Contract to Invoice' },
    { value: 'contract-to-booking', label: 'Contract to Booking' },
    { value: 'approval-vs-policy', label: 'Approval vs Policy' },
    { value: 'approval-vs-contract', label: 'Approval vs Contract' }
  ];

  const rubricOptions = [
    { value: 'all', label: 'All Rubrics' },
    { value: 'order-processed', label: 'Order Has Been Processed?' },
    { value: 'booking-terms', label: 'Terms of Booking vs Order Form Amendment Matching?' },
    { value: 'billing-systems', label: 'Mithra/Google Admin/Billy Systems Reflect Contract?' }
  ];

  // Category options for rule types
  const categoryOptions = [
    { value: 'Order Lookup', label: 'Order Lookup' },
    { value: 'Customer Validation', label: 'Customer Validation' },
    { value: 'Product Verification', label: 'Product Verification' },
    { value: 'Financial Verification', label: 'Financial Verification' },
    { value: 'Date Validation', label: 'Date Validation' },
    { value: 'System Integration', label: 'System Integration' },
    { value: 'Billing Compliance', label: 'Billing Compliance' },
    { value: 'Data Quality Assurance', label: 'Data Quality Assurance' },
    { value: '2-Way Matching', label: '2-Way Matching' },
    { value: '3-Way Matching', label: '3-Way Matching' },
    { value: 'General Validation', label: 'General Validation' },
    { value: 'Threshold Checks', label: 'Threshold Checks' },
    { value: 'Compliance Verification', label: 'Compliance Verification' },
    { value: 'Risk Assessment', label: 'Risk Assessment' }
  ];

  // Filter rules when filters or rules change
  useEffect(() => {
    let filtered = extractedRules;

    // Filter by audit type
    if (selectedAuditTypeForRules) {
      filtered = filtered.filter(rule => rule.auditType === selectedAuditTypeForRules);
    }

    // Filter by rubric
    if (selectedRubric !== 'all') {
      filtered = filtered.filter(rule => rule.rubric === selectedRubric);
    }

    setFilteredRules(filtered);
  }, [extractedRules, selectedAuditTypeForRules, selectedRubric]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setKnowledgeFile(file);
      setError(null);
      
      try {
        // Extract text from file for preview
        const extractedText = await GenAIService.extractTextFromFile(file);
        if (extractedText.length > 1000) {
          setKnowledgeText(extractedText.substring(0, 1000) + '...\n[File content truncated for display]');
        } else {
          setKnowledgeText(extractedText);
        }
      } catch (err) {
        setError('Failed to read file content');
      }
    }
  };

  const handleLoadSampleContent = () => {
    const sampleContent = GenAIService.getSampleKnowledgeContent();
    setKnowledgeText(sampleContent);
    setKnowledgeFile(null);
    setError(null);
  };

  const handleExtractRules = async () => {
    setIsProcessing(true);
    setError(null);
    
    try {
      let contentToProcess = knowledgeText;
      
      // If a file is uploaded, extract its full content
      if (knowledgeFile) {
        contentToProcess = await GenAIService.extractTextFromFile(knowledgeFile);
      }
      
      if (!contentToProcess.trim()) {
        throw new Error('No content to process. Please upload a file or paste text.');
      }
      
      const result = await GenAIService.extractValidationRules(contentToProcess, 'text');
      
      // Convert to new rule structure
      const rulesWithNewStructure = result.rules.map(rule => ({
        id: rule.id || `R${Date.now().toString().slice(-6)}${Math.random().toString(36).substr(2, 3).toUpperCase()}`,
        category: mapFieldToCategory(rule.field || 'general'),
        condition: rule.condition || 'exact_match',
        rule: extractActualRule(rule.description || rule.name || '', rule.field || 'general'),
        auditType: 'contract-to-provisioning' as AuditType, // Default audit type
        rubric: 'all', // Default rubric - users can change in table
        priority: rule.priority || 'medium',
        description: rule.description || rule.name || 'Auto-generated validation rule',
        extractedValues: rule.extractedValues || [],
        originalText: rule.originalText || '',
        enforcement: mapPriorityToEnforcement(rule.priority || 'medium')
      }));
      
      setExtractedRules(rulesWithNewStructure);
      setExtractionResult({
        confidence: result.confidence,
        processingNotes: result.processingNotes
      });
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to extract rules';
      setError(errorMessage);
      console.error('Rule extraction error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const mapFieldToCategory = (field: string): string => {
    const categoryMap: Record<string, string> = {
      'quoteId': 'Identifier Validation',
      'customerName': 'Customer Information',
      'serviceStartDate': 'Date Validation',
      'serviceEndDate': 'Date Validation', 
      'unitCost': 'Financial Verification',
      'billingFrequency': 'Billing Compliance',
      'apiRetry': 'System Integration',
      'ocrConfidence': 'Data Quality Assurance',
      'escalation': 'Escalation Workflows',
      'approval': 'Approval Workflows',
      'variance': 'Financial Verification',
      'product': 'Product Validation',
      'productId': 'Product Validation',
      'operationType': 'Operation Validation',
      'serviceStartDate': 'Date Validation',
      'serviceEndDate': 'Date Validation',
      'orderTerm': 'Term Validation',
      'quantity': 'Quantity Validation',
      'unitCost': 'Financial Validation',
      'billingFrequency': 'Billing Validation',
      'contractValue': 'Financial Validation'
    };
    
    return categoryMap[field] || 'General Validation';
  };

  const mapPriorityToEnforcement = (priority: string): string => {
    const enforcementMap: Record<string, string> = {
      'high': 'Mandatory',
      'medium': 'Recommended',
      'low': 'Optional'
    };
    
    return enforcementMap[priority] || 'Recommended';
  };

  const handleRuleEdit = (ruleId: string, field: keyof ValidationRule, value: any) => {
    setExtractedRules(prev => 
      prev.map(rule => 
        rule.id === ruleId ? { ...rule, [field]: value } : rule
      )
    );
  };

  const handleAddRule = () => {
    const newRule: ValidationRule = {
      id: `R${Date.now().toString().slice(-6)}M`,
      category: 'Order Lookup',
      condition: 'exact_match',
      rule: 'Verify field matches expected value; if mismatch detected, flag for review and escalate if critical',
      auditType: 'contract-to-provisioning',
      rubric: 'all',
      priority: 'medium',
      description: 'New validation rule'
    };
    setExtractedRules(prev => [...prev, newRule]);
    setEditingRule(newRule.id);
  };

  const extractActualRule = (description: string, field: string): string => {
    // If the description already contains specific values and actionable steps, use it directly
    if (description && (
      description.includes('within') || 
      description.includes('exceeds') || 
      description.includes('maximum') ||
      description.includes('minimum') ||
      description.match(/\d+\s*(days?|hours?|minutes?|%|attempts?|times?)/i)
    )) {
      return description; // Already contains specific business logic
    }
    
    // If description is generic, try to enhance it with field-specific logic
    const fieldRules: Record<string, string> = {
      'quoteId': 'Verify quote ID format matches Q-XXXXXX pattern; cross-reference with SAP SQN-XXXXXX; escalate to contracts team if mismatch detected',
      'customerName': 'Validate customer name consistency across systems; allow standard abbreviations (Pvt Ltd vs Private Limited); escalate if substantial entity difference found',
      'serviceStartDate': 'Validate service start date is within 30 days from current date; if exceeds 30 days, flag for review; if exceeds 90 days, escalate to contracts manager immediately',
      'unitCost': 'Calculate variance between systems using formula: |Amount1 - Amount2| / Amount1 * 100; if variance exceeds 5%, escalate to finance team within 2 hours',
      'apiRetry': 'For failed API calls, implement automatic retry mechanism with maximum 3 attempts and 1 minute intervals; escalate to IT operations if all retries fail',
      'ocrConfidence': 'Monitor OCR confidence scores; if below 90%, re-run extraction; if below 70%, escalate to data quality team within 2 hours',
      'product': 'Confirm product name matches exactly across all systems; check for typos or version differences; escalate to product team if discrepancy affects provisioning',
      'unitCost': 'Verify unit cost within 1% tolerance across systems; check currency formatting; escalate to finance if variance exceeds 5%',
      'serviceStartDate': 'Validate service dates represent same calendar date; allow different formats; escalate if actual date differences impact service delivery',
      'billingFrequency': 'Ensure billing frequency matches contract terms exactly; verify against payment schedule; escalate if mismatch affects revenue recognition'
    };
    
    return fieldRules[field] || `Validate ${field} consistency across systems; check for acceptable variations; escalate if business impact identified`;
    return fieldRules[field] || description || `Validate ${field} consistency across systems; check for acceptable variations; escalate if business impact identified`;
  };

  // Helper function to show extracted values in the UI
  const formatExtractedValues = (values: string[]): string => {
    return values.length > 0 ? values.join(', ') : 'None';
  };

  const generateAdvancedPromptFromRule = (rule: ValidationRule): string => {
    // Get system-specific field mappings
    const systemMappings = getSystemFieldMappings();
    
    return `You are performing intelligent data comparison for ${rule.category.toLowerCase()} validation in a compliance audit system.

VALIDATION RULE CONTEXT:
- Category: ${rule.category}
- Condition/Trigger: ${rule.condition}
- Rule: ${rule.rule}
- Audit Type: ${rule.auditType || 'contract-to-provisioning'}
- Rubric Section: ${rule.rubric || 'general'}
- Priority: ${rule.priority || 'medium'}

DATA SOURCES AND FIELD MAPPINGS:
${generateSystemFieldMappings(rule.category)}

VALIDATION LOGIC:
${generateValidationLogic(rule.condition, rule.priority || 'medium')}

BUSINESS INTELLIGENCE RULES:
${generateBusinessRules(rule.category, rule.priority || 'medium')}

COMPARISON ANALYSIS:
Analyze the following data across all systems:

PDF CONTRACT DATA (Source of Truth):
{pdfData}

SAP SYSTEM DATA:
{sapData}

OREO UI DATA:
{oreoData}

MITHRA/BILLY BILLING DATA:
{mithraData}

SPECIFIC FIELD ANALYSIS:
Field Name: {fieldName}
Expected Value: {expectedValue}
Tolerance: {tolerance}

PRIORITY REQUIREMENTS:
${rule.priority === 'high' ? 
  'This validation is HIGH PRIORITY and must pass for compliance. Any failure requires immediate attention and escalation.' :
  rule.priority === 'medium' ? 
  'This validation is MEDIUM PRIORITY for data quality. Failures should be flagged for review and addressed promptly.' :
  'This validation is LOW PRIORITY for enhanced quality assurance. Failures should be logged and addressed during regular maintenance.'
}

RULE ENFORCEMENT:
${rule.rule}

RESPONSE FORMAT:
Provide a detailed JSON response with the following structure:
{
  "fieldAnalysis": {
    "fieldName": "{fieldName}",
    "pdfValue": "extracted from PDF data",
    "sapValue": "extracted from SAP data", 
    "oreoValue": "extracted from OREO data",
    "mithraValue": "extracted from Mithra data"
  },
  "validationResult": {
    "isValid": true/false,
    "confidence": 0-100,
    "match": true/false,
    "riskLevel": "low|medium|high|critical",
    "businessImpact": "description of business impact"
  },
  "systemComparison": {
    "pdfToSap": {
      "match": true/false,
      "confidence": 0-100,
      "notes": "detailed comparison notes"
    },
    "pdfToOreo": {
      "match": true/false, 
      "confidence": 0-100,
      "notes": "detailed comparison notes"
    },
    "pdfToMithra": {
      "match": true/false,
      "confidence": 0-100, 
      "notes": "detailed comparison notes"
    }
  },
  "recommendations": [
    "specific actionable recommendations"
  ],
  "complianceNotes": "overall compliance assessment"
}

Apply business intelligence to understand acceptable variations while maintaining strict compliance standards.`;
  };

  const getSystemFieldMappings = () => {
    return {
      'PDF Contract': ['quoteId', 'customerName', 'product', 'productId', 'operationType', 'serviceStartDate', 'serviceEndDate', 'orderTerm', 'quantity', 'unitCost', 'billingFrequency'],
      'SAP System': ['solutionQuoteNumber', 'soldToParty', 'product', 'productId', 'operationType', 'serviceStartDate', 'serviceEndDate', 'duration', 'quantity', 'lineAmount'],
      'OREO UI': ['solutionQuoteNumber', 'soldToParty', 'product', 'productId', 'operationType', 'serviceStartDate', 'serviceEndDate', 'duration', 'quantity', 'lineAmount'],
      'Mithra/Billy': ['soldToParty', 'billingParty', 'billingFrequency']
    };
  };

  const generateSystemFieldMappings = (category: string): string => {
    const mappings = {
      'Identifier Validation': `
- PDF: quoteId (Q-XXXXXX format)
- SAP: solutionQuoteNumber (SQN-XXXXXX format) 
- OREO: solutionQuoteNumber (SQN-XXXXXX format)
- Expected: Same base number with different prefixes`,
      
      'Customer Information': `
- PDF: customerName (full legal name)
- SAP: soldToParty (may have case variations)
- OREO: soldToParty (may have abbreviations)
- Mithra: soldToParty, billingParty (may differ for billing)
- Expected: Same legal entity with acceptable variations`,
      
      'Product Validation': `
- PDF: product, productId (exact product specifications)
- SAP: product, productId (must match exactly)
- OREO: product, productId (must match exactly)
- Expected: Identical product information across all systems`,
      
      'Financial Validation': `
- PDF: unitCost, contractValue (source pricing)
- SAP: lineAmount (may have currency format differences)
- OREO: lineAmount (may have currency format differences)
- Expected: Same amounts with acceptable formatting variations`,
      
      'Date Validation': `
- PDF: serviceStartDate, serviceEndDate (various formats)
- SAP: serviceStartDate, serviceEndDate (may be DD/MM/YYYY)
- OREO: serviceStartDate, serviceEndDate (may be MM/DD/YYYY)
- Expected: Same calendar dates regardless of format`,
      
      'Billing Validation': `
- PDF: billingFrequency (detailed terms)
- SAP: billingFrequency (may be simplified)
- OREO: billingFrequency (may be simplified)
- Mithra: billingFrequency (billing system format)
- Expected: Consistent billing terms across systems`
    };
    
    return mappings[category as keyof typeof mappings] || 'Standard field mapping across all systems';
  };

  const generateValidationLogic = (condition: string, enforcement: string): string => {
    const riskLevel = enforcement === 'high' ? 'CRITICAL' : enforcement === 'medium' ? 'HIGH' : 'MEDIUM';
    
    const logicMap: Record<string, string> = {
      'exact_match': `
1. Extract field values from all relevant systems
2. Normalize formatting (case, whitespace, punctuation)
3. Compare normalized values for exact equality
4. Account for acceptable business variations (abbreviations, formatting)
5. Flag any substantive differences based on ${riskLevel} priority level`,
      
      'within_tolerance': `
1. Extract numeric values from all systems
2. Convert to common currency/unit format
3. Calculate percentage variance between systems
4. Apply tolerance thresholds based on ${riskLevel} priority level
5. Flag variances exceeding acceptable limits`,
      
      'matches_pattern': `
1. Extract field values from all systems
2. Apply regex pattern matching for format validation
3. Check for consistent pattern compliance across systems
4. Validate business logic embedded in patterns
5. Flag pattern violations based on ${riskLevel} priority level`,
      
      'date_format': `
1. Extract date values from all systems
2. Parse various date formats (ISO, US, European)
3. Convert to standard format for comparison
4. Validate date logic (start before end, business days)
5. Flag date inconsistencies based on ${riskLevel} priority level`,
      
      'allowed_values': `
1. Extract field values from all systems
2. Check against predefined allowed value list
3. Account for acceptable synonyms and variations
4. Validate business context for value appropriateness
5. Flag invalid values based on ${riskLevel} priority level`
    };
    
    return logicMap[condition] || 'Apply appropriate validation logic based on the condition type';
  };

  const generateBusinessRules = (category: string, enforcement: string): string => {
    const riskLevel = enforcement === 'high' ? 'CRITICAL' : enforcement === 'medium' ? 'HIGH' : 'MEDIUM';
    
    const businessRules = {
      'Order Lookup': `
- Order lookup requests must include all required fields (${riskLevel} RISK if missing)
- Search variations should be attempted before escalation (MEDIUM RISK)
- Escalation to Tier 2 required if order not found within 5 minutes (${riskLevel} RISK)`,
      
      'Customer Validation': `
- Legal entity must be consistent across systems (${riskLevel} RISK if different)
- Abbreviations like "Pvt Ltd" vs "Private Limited" are acceptable (LOW RISK)
- Case variations are acceptable (LOW RISK)
- Completely different customer names are critical failures (CRITICAL RISK)`,
      
      'Product Verification': `
- Product names and IDs must match exactly (${riskLevel} RISK if different)
- Minor formatting differences may be acceptable (MEDIUM RISK)
- Wrong product entirely is a critical compliance failure (CRITICAL RISK)`,
      
      'Financial Verification': `
- Currency formatting differences are acceptable (LOW RISK)
- Amount variances >1% require investigation (${riskLevel} RISK)
- Amount variances >5% are critical failures (CRITICAL RISK)`,
      
      'Date Validation': `
- Date format differences are acceptable if same date (LOW RISK)
- Different actual dates require investigation (${riskLevel} RISK)
- Invalid date sequences are critical failures (CRITICAL RISK)`,
      
      'System Integration': `
- Data sync failures require immediate attention (${riskLevel} RISK)
- API connectivity issues should trigger automatic retries (MEDIUM RISK)
- Persistent failures require IT escalation (CRITICAL RISK)`,
      
      'Billing Compliance': `
- Billing frequency must be consistent (${riskLevel} RISK if different)
- Payment terms must align with contract (${riskLevel} RISK if different)
- Billing party variations may be acceptable for internal billing (MEDIUM RISK)`,
      
      'Data Quality Assurance': `
- Missing required fields trigger re-extraction (${riskLevel} RISK)
- Low confidence scores require manual review (MEDIUM RISK)
- Critical field extraction failures require escalation (CRITICAL RISK)`,
      
      '2-Way Matching': `
- Two-way comparison between primary systems (${riskLevel} RISK if mismatch)
- Focus on critical business fields only (HIGH RISK)
- Acceptable variations documented and approved (LOW RISK)`,
      
      '3-Way Matching': `
- Three-way comparison across all primary systems (${riskLevel} RISK if mismatch)
- Majority consensus approach for conflict resolution (MEDIUM RISK)
- All three systems must align for critical fields (CRITICAL RISK)`,
      
      'General Validation': `
- Standard validation rules apply (${riskLevel} RISK)
- Business context considered for exceptions (MEDIUM RISK)
- Escalation procedures followed for failures (HIGH RISK)`,
      
      'Threshold Checks': `
- Numeric thresholds must be within acceptable ranges (${riskLevel} RISK)
- Percentage variances calculated accurately (HIGH RISK)
- Tolerance levels applied consistently (MEDIUM RISK)`,
      
      'Compliance Verification': `
- Regulatory requirements must be met (CRITICAL RISK)
- Audit trail maintained for all checks (${riskLevel} RISK)
- Non-compliance triggers immediate escalation (CRITICAL RISK)`,
      
      'Risk Assessment': `
- Risk levels assigned based on business impact (${riskLevel} RISK)
- Critical risks require immediate attention (CRITICAL RISK)
- Risk mitigation strategies documented (MEDIUM RISK)`
    };
    
    return businessRules[category as keyof typeof businessRules] || `Apply standard business validation rules with ${riskLevel} risk assessment`;
  };

  // Close action menu when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (openActionMenu) {
        const target = event.target as Element;
        if (!target.closest('.action-menu-container')) {
          setOpenActionMenu(null);
        }
      }
    };
    
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [openActionMenu]);

  const handleEditRule = (ruleId: string) => {
    setEditingRule(editingRule === ruleId ? null : ruleId);
    setOpenActionMenu(null);
  };

  const handleCloneRule = (ruleId: string) => {
    const originalRule = extractedRules.find(rule => rule.id === ruleId);
    if (originalRule) {
      const clonedRule: ValidationRule = {
        ...originalRule,
        id: `R${Date.now().toString().slice(-6)}C`,
        description: `${originalRule.description} (Copy)`
      };
      setExtractedRules(prev => [...prev, clonedRule]);
      setOpenActionMenu(null);
    }
  };

  const handleGeneratePrompt = (rule: ValidationRule) => {
    // Generate a comprehensive prompt based on the rule
    const promptContent = generateAdvancedPromptFromRule(rule);
    
    const newPrompt = {
      id: `P${Date.now().toString().slice(-6)}${rule.id.slice(-3)}`,
      name: `${rule.category} - ${rule.condition} Validation`,
      category: 'validation' as const,
      section: rule.rubric || 'general',
      description: `Auto-generated prompt for ${rule.category} validation using ${rule.condition} condition`,
      prompt: promptContent,
      variables: ['pdfData', 'sapData', 'oreoData', 'mithraData', 'fieldName', 'expectedValue', 'tolerance'],
      lastModified: new Date().toISOString(),
      version: 1,
      isActive: false
    };

    PromptLibraryService.savePrompt(newPrompt);
    setOpenActionMenu(null);
    alert(`Advanced prompt generated and saved to library: "${newPrompt.name}"`);
  };

  const handleDeleteRule = (ruleId: string) => {
    if (confirm('Are you sure you want to delete this rule?')) {
      setExtractedRules(prev => prev.filter(rule => rule.id !== ruleId));
      setOpenActionMenu(null);
    }
  };

  const handleSaveRules = () => {
    // Validate all rules before saving
    const allErrors: string[] = [];
    filteredRules.forEach((rule, index) => {
      if (!rule.category || !rule.condition || !rule.enforcement) {
        allErrors.push(`Rule ${index + 1}: Missing required fields`);
      }
    });
    
    if (allErrors.length > 0) {
      alert(`Please fix the following validation errors:\n\n${allErrors.join('\n')}`);
      return;
    }
    
    // In a real implementation, this would save to a backend
    console.log('Saving rules:', extractedRules);
    localStorage.setItem('validationRules', JSON.stringify(extractedRules));
    alert(`Successfully saved ${filteredRules.length} validation rules!`);
  };

  return (
    <div className="p-6">
      {/* Tab Navigation */}
      <div className="mb-6 border-b border-gray-200">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('knowledge')}
            className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm ${
              activeTab === 'knowledge'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Brain className="h-4 w-4" />
            <span>Knowledge Management</span>
          </button>
          <button
            onClick={() => setActiveTab('prompts')}
            className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm ${
              activeTab === 'prompts'
                ? 'border-purple-500 text-purple-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <MessageSquare className="h-4 w-4" />
            <span>Prompt Library</span>
          </button>
          <button
            onClick={() => setActiveTab('llm-config')}
            className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm ${
              activeTab === 'llm-config'
                ? 'border-green-500 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Cpu className="h-4 w-4" />
            <span>LLM Models</span>
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'knowledge' && (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Knowledge Database Management</h2>
            <p className="text-gray-600">Extract validation rules using GenAI</p>
          </div>


          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-red-900">Error</h4>
                  <p className="text-sm text-red-700 mt-1">{error}</p>
                </div>
              </div>
            </div>
          )}

          {/* Knowledge Database Upload Section */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Knowledge Database</h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* File Upload */}
              <div className="space-y-4">
                <div>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.txt"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="knowledge-file"
                    />
                    <label
                      htmlFor="knowledge-file"
                      className="cursor-pointer text-blue-600 hover:text-blue-700"
                    >
                      Click to upload or drag and drop
                    </label>
                    <p className="text-sm text-gray-500 mt-1">
                      PDF, DOC, DOCX, TXT files up to 10MB
                    </p>
                    {knowledgeFile && (
                      <p className="text-sm text-green-600 mt-2">
                        Selected: {knowledgeFile.name}
                      </p>
                    )}
                  </div>
                  
                  <button
                    onClick={handleLoadSampleContent}
                    className="mt-2 w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 text-sm"
                  >
                    Load Sample Knowledge Content
                  </button>
                </div>
              </div>

              {/* Text Input */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Knowledge Content Preview
                  </label>
                  <textarea
                    value={knowledgeText}
                    onChange={(e) => setKnowledgeText(e.target.value)}
                    placeholder="Paste your knowledge database content here or upload a file..."
                    className="w-full h-32 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {knowledgeText.length} characters
                  </p>
                </div>
              </div>
            </div>

            {/* Extract Rules Button */}
            <div className="mt-6">
              <button
                onClick={handleExtractRules}
                disabled={!knowledgeFile && !knowledgeText.trim() || isProcessing}
                className="flex items-center space-x-2 px-6 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Processing with GenAI...</span>
                  </>
                ) : (
                  <>
                    <Brain className="h-4 w-4" />
                    <span>Extract Rules with GenAI</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Extraction Results */}
          {extractionResult && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-green-900">Extraction Complete</h4>
                  <p className="text-sm text-green-700 mt-1">
                    Extracted {extractedRules.length} rules with {extractionResult.confidence}% confidence.
                    {extractionResult.processingNotes && ` ${extractionResult.processingNotes}`}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Extracted Rules Section */}
          {extractedRules.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Extracted Validation Rules</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={handleAddRule}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Add Rule</span>
                  </button>
                  <button
                    onClick={handleSaveRules}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    <Save className="h-4 w-4" />
                    <span>Save Rules</span>
                  </button>
                </div>
              </div>

              {/* Filter Controls */}
              <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg border">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filter by Audit Type - All Items
                  </label>
                  <select
                    value={selectedAuditTypeForRules}
                    onChange={(e) => setSelectedAuditTypeForRules(e.target.value as AuditType)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="all">All Audit Types</option>
                    {auditTypeOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filter by Rubric
                  </label>
                  <select
                    value={selectedRubric}
                    onChange={(e) => setSelectedRubric(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    {rubricOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Updated Rules Table Structure */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300 table-fixed">
                  <colgroup>
                    <col style={{ width: '8%' }} />  {/* Rule ID */}
                    <col style={{ width: '15%' }} /> {/* Category */}
                    <col style={{ width: '20%' }} /> {/* Condition */}
                    <col style={{ width: '25%' }} /> {/* Rule */}
                    <col style={{ width: '12%' }} /> {/* Audit Type */}
                    <col style={{ width: '12%' }} /> {/* Rubric */}
                    <col style={{ width: '10%' }} /> {/* Actions */}
                    <col style={{ width: '8%' }} />  {/* Extracted Values */}
                  </colgroup>
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Rule ID</th>
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Category</th>
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Condition / Trigger</th>
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Business Rule</th>
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Audit Type</th>
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Rubric</th>
                      <th className="border border-gray-300 p-2 text-center text-xs font-semibold">Actions</th>
                      <th className="border border-gray-300 p-2 text-left text-xs font-semibold">Extracted Values</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRules.map((rule) => (
                      <tr key={rule.id} className="hover:bg-gray-50">
                        <td className="border border-gray-300 p-2">
                          <div className="text-xs font-mono text-gray-900 font-medium truncate" title={rule.id}>
                            {rule.id}
                          </div>
                        </td>
                        <td className="border border-gray-300 p-2">
                          <select
                            value={rule.category}
                            onChange={(e) => handleRuleEdit(rule.id, 'category', e.target.value)}
                            className="w-full p-1 border border-gray-200 rounded text-xs"
                          >
                            {categoryOptions.map((option) => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="border border-gray-300 p-2">
                          <input
                            type="text"
                            value={rule.condition}
                            onChange={(e) => handleRuleEdit(rule.id, 'condition', e.target.value)}
                            className="w-full p-1 border border-gray-200 rounded text-xs"
                            placeholder="e.g., exact_match, within_tolerance, matches_pattern"
                          />
                        </td>
                        <td className="border border-gray-300 p-2">
                          <textarea
                            value={rule.rule}
                            onChange={(e) => handleRuleEdit(rule.id, 'rule', e.target.value)}
                            className="w-full p-1 border border-gray-200 rounded text-xs resize-none"
                            rows={2}
                            placeholder="Business Rule needs to be extracted based on the knowledge article. Eg Search CRM/order tool; if not found, verify spelling, try other email, escalate to Tier 2"
                          />
                        </td>
                        <td className="border border-gray-300 p-2">
                          <select
                            value={rule.auditType || 'contract-to-provisioning'}
                            onChange={(e) => handleRuleEdit(rule.id, 'auditType', e.target.value as AuditType)}
                            className="w-full p-1 border border-gray-200 rounded text-xs"
                          >
                            {auditTypeOptions.map((option) => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="border border-gray-300 p-2">
                          <select
                            value={rule.rubric || 'all'}
                            onChange={(e) => handleRuleEdit(rule.id, 'rubric', e.target.value)}
                            className="w-full p-1 border border-gray-200 rounded text-xs"
                          >
                            {rubricOptions.map((option) => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="border border-gray-300 p-2">
                          <div className="relative flex items-center justify-center action-menu-container">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setOpenActionMenu(openActionMenu === rule.id ? null : rule.id);
                              }}
                              className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md"
                              title="Actions"
                            >
                              <MoreVertical className="h-3 w-3" />
                            </button>
                            
                            {/* Action Menu */}
                            {openActionMenu === rule.id && (
                              <div className="absolute right-0 top-6 z-10 bg-white border border-gray-200 rounded-md shadow-lg py-1 min-w-[140px]">
                                <button
                                  onClick={() => handleEditRule(rule.id)}
                                  className="flex items-center space-x-2 w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-100"
                                >
                                  <Edit3 className="h-3 w-3" />
                                  <span>Edit</span>
                                </button>
                                <button
                                  onClick={() => handleCloneRule(rule.id)}
                                  className="flex items-center space-x-2 w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-100"
                                >
                                  <Copy className="h-3 w-3" />
                                  <span>Clone</span>
                                </button>
                                <button
                                  onClick={() => handleGeneratePrompt(rule)}
                                  className="flex items-center space-x-2 w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-100"
                                >
                                  <Zap className="h-3 w-3" />
                                  <span>Generate Prompt</span>
                                </button>
                                <hr className="my-1" />
                                <button
                                  onClick={() => handleDeleteRule(rule.id)}
                                  className="flex items-center space-x-2 w-full px-3 py-2 text-xs text-red-600 hover:bg-red-50"
                                >
                                  <Trash2 className="h-3 w-3" />
                                  <span>Delete</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="border border-gray-300 p-2">
                          <div className="text-xs text-gray-600">
                            {rule.extractedValues && rule.extractedValues.length > 0 ? (
                              <div className="space-y-1">
                                {rule.extractedValues.map((value, idx) => (
                                  <span key={idx} className="inline-block bg-blue-100 text-blue-800 px-1 rounded text-xs mr-1">
                                    {value}
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <span className="text-gray-400">None extracted</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4 text-xs text-gray-600">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p><strong>Filtered Rules:</strong> {filteredRules.length}</p>
                    <p className="text-xs text-gray-500">Total: {extractedRules.length}</p>
                  </div>
                  <div>
                    <p><strong>High Priority:</strong> {filteredRules.filter(r => r.priority === 'high').length}</p>
                  </div>
                  <div>
                    <p><strong>Medium Priority:</strong> {filteredRules.filter(r => r.priority === 'medium').length}</p>
                  </div>
                  <div>
                    <p><strong>Low Priority:</strong> {filteredRules.filter(r => r.priority === 'low').length}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* No Rules Message */}
          {extractedRules.length > 0 && filteredRules.length === 0 && (
            <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
              {/* Filter Controls - Always Visible */}
              <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg border">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filter by Audit Type - All Items
                  </label>
                  <select
                    value={selectedAuditTypeForRules}
                    onChange={(e) => setSelectedAuditTypeForRules(e.target.value as AuditType)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="all">All Audit Types</option>
                    {auditTypeOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filter by Rubric
                  </label>
                  <select
                    value={selectedRubric}
                    onChange={(e) => setSelectedRubric(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    {rubricOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Rules Match Current Filters</h3>
              <p className="text-gray-600 mb-4">
                Try adjusting the audit type or rubric filters to see more rules.
              </p>
              <div className="text-sm text-gray-500">
                <p>Total rules available: {extractedRules.length}</p>
                <p>Current filters: {auditTypeOptions.find(opt => opt.value === selectedAuditTypeForRules)?.label} 
                   {selectedRubric !== 'all' && ` → ${rubricOptions.find(opt => opt.value === selectedRubric)?.label}`}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'prompts' && <PromptLibraryPanel />}

      {activeTab === 'llm-config' && <LLMConfigPanel />}
    </div>
  );
};