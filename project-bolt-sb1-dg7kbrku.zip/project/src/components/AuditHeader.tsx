import React from 'react';
import { Shield, FileText, Calendar } from 'lucide-react';

interface AuditHeaderProps {
  auditId: string;
  contractNumber: string;
  auditDate: string;
}

export const AuditHeader: React.FC<AuditHeaderProps> = ({ auditId, contractNumber, auditDate }) => {
  return (
    <div className="bg-white shadow-sm border-b border-gray-200 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Shield className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Compliance Audit Reconciliation</h1>
              <p className="text-sm text-gray-600 mt-1">Contract Data Verification & Compliance Check</p>
            </div>
          </div>
          <div className="flex items-center space-x-6 text-sm text-gray-600">
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Audit ID: {auditId}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>{auditDate}</span>
            </div>
          </div>
        </div>
        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <span className="text-sm font-medium text-gray-700">Contract Number: </span>
          <span className="text-sm font-mono text-gray-900">{contractNumber}</span>
        </div>
      </div>
    </div>
  );
};