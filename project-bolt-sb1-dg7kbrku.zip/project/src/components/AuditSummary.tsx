import React from 'react';
import { CheckCircle, XCircle, AlertCircle, Clock, Download, Send } from 'lucide-react';

interface AuditSummaryProps {
  checks: Array<{
    title: string;
    status: 'pass' | 'fail' | 'warning' | 'pending';
  }>;
  onGenerateReport: () => void;
  onSubmitAudit: () => void;
}

export const AuditSummary: React.FC<AuditSummaryProps> = ({ 
  checks, 
  onGenerateReport, 
  onSubmitAudit 
}) => {
  const getOverallStatus = () => {
    const statuses = checks.map(check => check.status);
    if (statuses.includes('fail')) return 'fail';
    if (statuses.includes('warning')) return 'warning';
    if (statuses.includes('pending')) return 'pending';
    return 'pass';
  };

  const getStatusCounts = () => {
    return checks.reduce((acc, check) => {
      acc[check.status] = (acc[check.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  };

  const overallStatus = getOverallStatus();
  const statusCounts = getStatusCounts();

  const getOverallColor = () => {
    switch (overallStatus) {
      case 'pass': return 'bg-green-50 border-green-200';
      case 'fail': return 'bg-red-50 border-red-200';
      case 'warning': return 'bg-yellow-50 border-yellow-200';
      case 'pending': return 'bg-gray-50 border-gray-200';
    }
  };

  const getOverallIcon = () => {
    switch (overallStatus) {
      case 'pass': return <CheckCircle className="h-8 w-8 text-green-500" />;
      case 'fail': return <XCircle className="h-8 w-8 text-red-500" />;
      case 'warning': return <AlertCircle className="h-8 w-8 text-yellow-500" />;
      case 'pending': return <Clock className="h-8 w-8 text-gray-400" />;
    }
  };

  const canSubmit = overallStatus !== 'pending';

  return (
    <div className={`border-2 rounded-lg p-6 ${getOverallColor()}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          {getOverallIcon()}
          <div>
            <h3 className="text-xl font-bold text-gray-900">Audit Summary</h3>
            <p className="text-sm text-gray-600 mt-1">Overall Status: {overallStatus.charAt(0).toUpperCase() + overallStatus.slice(1)}</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="text-center p-3 bg-white rounded-lg">
          <div className="text-2xl font-bold text-green-600">{statusCounts.pass || 0}</div>
          <div className="text-sm text-gray-600">Passed</div>
        </div>
        <div className="text-center p-3 bg-white rounded-lg">
          <div className="text-2xl font-bold text-red-600">{statusCounts.fail || 0}</div>
          <div className="text-sm text-gray-600">Failed</div>
        </div>
        <div className="text-center p-3 bg-white rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">{statusCounts.warning || 0}</div>
          <div className="text-sm text-gray-600">Warnings</div>
        </div>
        <div className="text-center p-3 bg-white rounded-lg">
          <div className="text-2xl font-bold text-gray-400">{statusCounts.pending || 0}</div>
          <div className="text-sm text-gray-600">Pending</div>
        </div>
      </div>
      
      <div className="flex space-x-4">
        <button
          onClick={onGenerateReport}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="h-4 w-4" />
          <span>Generate Report</span>
        </button>
        <button
          onClick={onSubmitAudit}
          disabled={!canSubmit}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
            canSubmit 
              ? 'bg-green-600 text-white hover:bg-green-700' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          <Send className="h-4 w-4" />
          <span>Submit Audit</span>
        </button>
      </div>
    </div>
  );
};