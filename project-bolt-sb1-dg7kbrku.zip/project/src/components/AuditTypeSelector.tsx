import React from 'react';
import { ChevronDown, Shield, Receipt, Calendar, Settings, CheckCircle, FileCheck } from 'lucide-react';
import { AuditType, AuditTypeConfig } from '../types/audit';
import { AUDIT_TYPE_CONFIGS } from '../data/auditTypes';

interface AuditTypeSelectorProps {
  selectedAuditType: AuditType;
  onAuditTypeChange: (auditType: AuditType) => void;
}

export const AuditTypeSelector: React.FC<AuditTypeSelectorProps> = ({
  selectedAuditType,
  onAuditTypeChange
}) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const selectedConfig = AUDIT_TYPE_CONFIGS[selectedAuditType];

  const getIcon = (iconName: string) => {
    const iconProps = { className: "h-4 w-4" };
    switch (iconName) {
      case 'Shield': return <Shield {...iconProps} />;
      case 'Receipt': return <Receipt {...iconProps} />;
      case 'Calendar': return <Calendar {...iconProps} />;
      case 'Settings': return <Settings {...iconProps} />;
      case 'CheckCircle': return <CheckCircle {...iconProps} />;
      case 'FileCheck': return <FileCheck {...iconProps} />;
      default: return <Shield {...iconProps} />;
    }
  };

  const getColorClasses = (color: string, isSelected: boolean = false) => {
    const baseClasses = isSelected ? 'bg-opacity-20 border-opacity-50' : 'bg-opacity-10 border-opacity-30';
    switch (color) {
      case 'blue': return `bg-blue-500 border-blue-500 text-blue-700 ${baseClasses}`;
      case 'green': return `bg-green-500 border-green-500 text-green-700 ${baseClasses}`;
      case 'purple': return `bg-purple-500 border-purple-500 text-purple-700 ${baseClasses}`;
      case 'orange': return `bg-orange-500 border-orange-500 text-orange-700 ${baseClasses}`;
      case 'teal': return `bg-teal-500 border-teal-500 text-teal-700 ${baseClasses}`;
      case 'red': return `bg-red-500 border-red-500 text-red-700 ${baseClasses}`;
      default: return `bg-gray-500 border-gray-500 text-gray-700 ${baseClasses}`;
    }
  };

  const auditTypes = Object.values(AUDIT_TYPE_CONFIGS);
  const contractTypes = auditTypes.filter(type => type.id.startsWith('contract-'));
  const approvalTypes = auditTypes.filter(type => type.id.startsWith('approval-'));

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center space-x-3 px-4 py-3 border-2 rounded-lg transition-all hover:shadow-md ${getColorClasses(selectedConfig.color, true)}`}
      >
        {getIcon(selectedConfig.icon)}
        <div className="text-left">
          <div className="font-medium text-sm">{selectedConfig.name}</div>
          <div className="text-xs opacity-75">{selectedConfig.description}</div>
        </div>
        <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border-2 border-gray-200 rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
          {/* Contract Audits Section */}
          <div className="p-3 border-b border-gray-100">
            <h4 className="text-sm font-semibold text-gray-700 mb-2">Contract Audits</h4>
            <div className="space-y-1">
              {contractTypes.map((config) => (
                <button
                  key={config.id}
                  onClick={() => {
                    onAuditTypeChange(config.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-md transition-all hover:shadow-sm ${
                    selectedAuditType === config.id 
                      ? getColorClasses(config.color, true)
                      : `hover:${getColorClasses(config.color)} border border-transparent hover:border-current`
                  }`}
                >
                  {getIcon(config.icon)}
                  <div className="text-left flex-1">
                    <div className="font-medium text-sm">{config.name}</div>
                    <div className="text-xs opacity-75">{config.description}</div>
                    <div className="text-xs mt-1 opacity-60">
                      {config.dataSources.primary} → {config.dataSources.secondary}
                      {config.dataSources.tertiary && ` → ${config.dataSources.tertiary}`}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Approval Audits Section */}
          <div className="p-3">
            <h4 className="text-sm font-semibold text-gray-700 mb-2">Approval Audits</h4>
            <div className="space-y-1">
              {approvalTypes.map((config) => (
                <button
                  key={config.id}
                  onClick={() => {
                    onAuditTypeChange(config.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-md transition-all hover:shadow-sm ${
                    selectedAuditType === config.id 
                      ? getColorClasses(config.color, true)
                      : `hover:${getColorClasses(config.color)} border border-transparent hover:border-current`
                  }`}
                >
                  {getIcon(config.icon)}
                  <div className="text-left flex-1">
                    <div className="font-medium text-sm">{config.name}</div>
                    <div className="text-xs opacity-75">{config.description}</div>
                    <div className="text-xs mt-1 opacity-60">
                      {config.dataSources.primary} → {config.dataSources.secondary}
                      {config.dataSources.tertiary && ` → ${config.dataSources.tertiary}`}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};