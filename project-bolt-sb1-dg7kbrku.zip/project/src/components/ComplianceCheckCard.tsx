import React from 'react';
import { CheckCircle, XCircle, AlertCircle, HelpCircle } from 'lucide-react';

interface ComplianceCheckCardProps {
  title: string;
  description: string;
  status: 'pass' | 'fail' | 'warning' | 'pending';
  details?: string;
  onStatusChange: (status: 'pass' | 'fail' | 'warning' | 'pending') => void;
}

export const ComplianceCheckCard: React.FC<ComplianceCheckCardProps> = ({
  title,
  description,
  status,
  details,
  onStatusChange
}) => {
  const getStatusIcon = () => {
    switch (status) {
      case 'pass': return <CheckCircle className="h-6 w-6 text-green-500" />;
      case 'fail': return <XCircle className="h-6 w-6 text-red-500" />;
      case 'warning': return <AlertCircle className="h-6 w-6 text-yellow-500" />;
      case 'pending': return <HelpCircle className="h-6 w-6 text-gray-400" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'pass': return 'border-green-200 bg-green-50';
      case 'fail': return 'border-red-200 bg-red-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      case 'pending': return 'border-gray-200 bg-gray-50';
    }
  };

  const getButtonClass = (buttonStatus: string) => {
    const baseClass = "px-3 py-1.5 text-sm font-medium rounded-md border transition-colors";
    const isActive = status === buttonStatus;
    
    switch (buttonStatus) {
      case 'pass':
        return `${baseClass} ${isActive ? 'bg-green-500 text-white border-green-500' : 'bg-white text-green-600 border-green-200 hover:bg-green-50'}`;
      case 'fail':
        return `${baseClass} ${isActive ? 'bg-red-500 text-white border-red-500' : 'bg-white text-red-600 border-red-200 hover:bg-red-50'}`;
      case 'warning':
        return `${baseClass} ${isActive ? 'bg-yellow-500 text-white border-yellow-500' : 'bg-white text-yellow-600 border-yellow-200 hover:bg-yellow-50'}`;
      case 'pending':
        return `${baseClass} ${isActive ? 'bg-gray-500 text-white border-gray-500' : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'}`;
      default:
        return baseClass;
    }
  };

  return (
    <div className={`border-2 rounded-lg p-6 ${getStatusColor()}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start space-x-3">
          {getStatusIcon()}
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
            <p className="text-sm text-gray-600 mt-1">{description}</p>
          </div>
        </div>
      </div>
      
      {details && (
        <div className="mb-4 p-3 bg-white rounded-md">
          <p className="text-sm text-gray-700">{details}</p>
        </div>
      )}
      
      <div className="flex space-x-2">
        <button
          onClick={() => onStatusChange('pass')}
          className={getButtonClass('pass')}
        >
          Pass
        </button>
        <button
          onClick={() => onStatusChange('fail')}
          className={getButtonClass('fail')}
        >
          Fail
        </button>
        <button
          onClick={() => onStatusChange('warning')}
          className={getButtonClass('warning')}
        >
          Warning
        </button>
        <button
          onClick={() => onStatusChange('pending')}
          className={getButtonClass('pending')}
        >
          Pending
        </button>
      </div>
    </div>
  );
};