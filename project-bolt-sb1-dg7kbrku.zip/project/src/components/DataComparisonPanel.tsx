import React from 'react';
import { CheckCircle, XCircle, AlertTriangle, BarChart3, FileText, Database, Globe, CreditCard, Bot, Brain, Zap } from 'lucide-react';
import { ComparisonResult } from '../types/audit';
import { GenAIDataMatcher } from '../services/genAIDataMatcher';

interface DataComparisonPanelProps {
  comparisons: ComparisonResult[];
  isLoading: boolean;
  allDataExtracted: boolean;
  onRunComparison: () => void;
}

interface ComparisonSection {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  comparisons: ComparisonResult[];
}

export const DataComparisonPanel: React.FC<DataComparisonPanelProps> = ({
  comparisons,
  isLoading,
  allDataExtracted,
  onRunComparison
}) => {
  const aiStatus = GenAIDataMatcher.getAIStatus();
  const isUsingRealAI = GenAIDataMatcher.isUsingRealAI();

  const getMatchIcon = (match: boolean, confidence: number) => {
    if (match) return <CheckCircle className="h-5 w-5 text-green-500" />;
    if (confidence >= 60) return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
    return <XCircle className="h-5 w-5 text-red-500" />;
  };

  const getRowClass = (match: boolean, confidence: number) => {
    if (match) return 'bg-green-50 border-green-200';
    if (confidence >= 60) return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  // Organize comparisons into sections
  const sections: ComparisonSection[] = [
    {
      title: "Order Has Been Processed?",
      description: "Verification that the order has been properly processed across all systems",
      icon: <FileText className="h-5 w-5 text-blue-600" />,
      color: "border-blue-200 bg-blue-50",
      comparisons: comparisons.filter(comp => 
        ['quoteId', 'customerName', 'product', 'productId', 'operationType', 
         'serviceStartDate', 'serviceEndDate', 'orderTerm', 'quantity', 'unitCost'].includes(comp.field)
      )
    },
    {
      title: "Terms of Booking vs Order Form Amendment Matching?",
      description: "Comparison of booking terms and billing arrangements",
      icon: <Database className="h-5 w-5 text-purple-600" />,
      color: "border-purple-200 bg-purple-50",
      comparisons: comparisons.filter(comp => 
        ['billingFrequency', 'orderTerm'].includes(comp.field)
      )
    },
    {
      title: "Mithra/Google Admin/Billy Systems Reflect Contract?",
      description: "Verification that billing systems accurately reflect contract details",
      icon: <CreditCard className="h-5 w-5 text-orange-600" />,
      color: "border-orange-200 bg-orange-50",
      comparisons: comparisons.filter(comp => 
        comp.source4Value && ['customerName', 'billingFrequency'].includes(comp.field)
      )
    }
  ];

  const getSectionSummary = (sectionComparisons: ComparisonResult[]) => {
    const total = sectionComparisons.length;
    const passed = sectionComparisons.filter(c => c.match).length;
    const warnings = sectionComparisons.filter(c => !c.match && c.confidence >= 60).length;
    const failed = sectionComparisons.filter(c => !c.match && c.confidence < 60).length;
    
    return { total, passed, warnings, failed };
  };

  const getSectionStatus = (summary: any) => {
    if (summary.failed > 0) return { status: 'fail', color: 'text-red-600', bgColor: 'bg-red-100' };
    if (summary.warnings > 0) return { status: 'warning', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    return { status: 'pass', color: 'text-green-600', bgColor: 'bg-green-100' };
  };

  return (
    <div className="bg-white rounded-lg border-2 border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <BarChart3 className="h-6 w-6 text-blue-600" />
          <h3 className="text-lg font-semibold">Data Comparison Results</h3>
        </div>
        
        {/* Trigger AI Agent Button - Right Aligned */}
        {allDataExtracted && comparisons.length === 0 && !isLoading && (
          <button
            onClick={onRunComparison}
            className="flex items-center space-x-3 px-8 py-4 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:via-blue-700 hover:to-indigo-700 font-medium shadow-lg transform transition-all duration-200 hover:scale-105"
          >
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <Zap className="h-4 w-4" />
            </div>
            <span>Trigger GenAI Analysis</span>
          </button>
        )}
      </div>

      {/* AI Status Indicator */}
      {allDataExtracted && comparisons.length === 0 && !isLoading && (
        <div className={`mb-4 p-4 rounded-lg border ${
          aiStatus.available 
            ? 'bg-green-50 border-green-200' 
            : 'bg-yellow-50 border-yellow-200'
        }`}>
          <div className="flex items-center space-x-2 text-sm">
            <Brain className={`h-4 w-4 ${aiStatus.available ? 'text-green-600' : 'text-blue-600'}`} />
            <span className={`font-medium ${aiStatus.available ? 'text-green-800' : 'text-blue-800'}`}>
              {aiStatus.available ? 'GenAI Analysis Ready' : 'GenAI Mock Mode'}
            </span>
          </div>
          {aiStatus.reason && (
            <p className={`text-xs mt-2 ${aiStatus.available ? 'text-green-600' : 'text-blue-600'}`}>
              {aiStatus.reason}
            </p>
          )}
          {!aiStatus.available && (
            <div className="mt-3 p-2 bg-yellow-100 border border-yellow-300 rounded text-xs">
              <p className="text-yellow-800 font-medium">⚠️ Real AI Analysis Not Available</p>
              <p className="text-yellow-700 mt-1">
                To use real AI analysis, configure your API key in the environment variable. 
                The system will use enhanced mock data that simulates realistic AI behavior for demonstration.
              </p>
            </div>
          )}
        </div>
      )}
      {isLoading && (
        <div className="flex flex-col items-center justify-center h-32 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
            <Brain className="h-8 w-8 text-purple-600 animate-pulse" />
            <Zap className="h-6 w-6 text-blue-600 animate-bounce" />
          </div>
          <div className="text-center">
            <div className="text-lg font-medium text-gray-800 mb-1">GenAI Analyzing Contract Data</div>
            <div className="text-sm text-gray-600">Applying business intelligence and compliance rules...</div>
            <div className={`text-xs mt-2 px-2 py-1 rounded ${
              isUsingRealAI 
                ? 'bg-green-100 text-green-700' 
                : 'bg-blue-100 text-blue-700'
            }`}>
              {aiStatus.available ? 'Using Google Gemini for analysis' : 'Using enhanced mock AI analysis'}
            </div>
          </div>
        </div>
      )}

      {/* Show analysis type indicator when results are displayed */}
      {comparisons.length > 0 && (
        <div className={`mb-4 p-3 rounded-lg border text-center ${
          isUsingRealAI ? 'bg-green-50 border-green-200' : 'bg-blue-50 border-blue-200'
        }`}>
          <p className={`text-sm font-medium ${isUsingRealAI ? 'text-green-800' : 'text-blue-800'}`}>
            📊 Analysis Results: {isUsingRealAI ? '🤖 Real AI Analysis' : '🎭 Enhanced Mock Analysis'} • Provider: {GenAIDataMatcher.getCurrentAIProvider()}
          </p>
        </div>
      )}

      {!isLoading && sections.map((section, sectionIndex) => {
        const summary = getSectionSummary(section.comparisons);
        const status = getSectionStatus(summary);
        
        return (
          <div key={sectionIndex} className={`mb-8 border-2 rounded-lg p-6 ${section.color}`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                {section.icon}
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">{section.title}</h4>
                  <p className="text-sm text-gray-600">{section.description}</p>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${status.bgColor} ${status.color}`}>
                {summary.passed}/{summary.total} Passed
              </div>
            </div>

            {section.comparisons.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b-2 border-gray-200">
                      <th className="text-left p-3 font-semibold text-gray-900">Field</th>
                      <th className="text-left p-3 font-semibold text-gray-900">Order Form Value</th>
                      <th className="text-left p-3 font-semibold text-gray-900">SAP Value</th>
                      <th className="text-left p-3 font-semibold text-gray-900">OREO Value</th>
                      {section.title.includes('Mithra') && (
                        <th className="text-left p-3 font-semibold text-gray-900">Mithra Value</th>
                      )}
                      <th className="text-center p-3 font-semibold text-gray-900">Match</th>
                      <th className="text-center p-3 font-semibold text-gray-900">Confidence</th>
                      <th className="text-left p-3 font-semibold text-gray-900">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {section.comparisons.map((comparison, index) => (
                      <tr
                        key={index}
                        className={`border-2 ${getRowClass(comparison.match, comparison.confidence)}`}
                      >
                        <td className="p-3 font-medium text-gray-900 capitalize">
                          {getFieldDisplayName(comparison.field)}
                        </td>
                        <td className="p-3 text-gray-700 font-mono text-sm">
                          {comparison.source1Value || 'N/A'}
                        </td>
                        <td className="p-3 text-gray-700 font-mono text-sm">
                          {comparison.source2Value || 'N/A'}
                        </td>
                        <td className="p-3 text-gray-700 font-mono text-sm">
                          {comparison.source3Value || 'N/A'}
                        </td>
                        {section.title.includes('Mithra') && (
                          <td className="p-3 text-gray-700 font-mono text-sm">
                            {comparison.source4Value || 'N/A'}
                          </td>
                        )}
                        <td className="p-3 text-center">
                          {getMatchIcon(comparison.match, comparison.confidence)}
                        </td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            comparison.confidence >= 80 ? 'bg-green-100 text-green-800' :
                            comparison.confidence >= 60 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {comparison.confidence}%
                          </span>
                        </td>
                        <td className="p-3 text-sm text-gray-600">
                          {comparison.notes || 'GenAI analysis completed'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No comparison data available for this section.
              </div>
            )}

            {/* Section Summary */}
            <div className="mt-4 grid grid-cols-4 gap-4">
              <div className="text-center p-3 bg-white rounded-lg">
                <div className="text-lg font-bold text-gray-900">{summary.total}</div>
                <div className="text-xs text-gray-600">Total Checks</div>
              </div>
              <div className="text-center p-3 bg-white rounded-lg">
                <div className="text-lg font-bold text-green-600">{summary.passed}</div>
                <div className="text-xs text-gray-600">Passed</div>
              </div>
              <div className="text-center p-3 bg-white rounded-lg">
                <div className="text-lg font-bold text-yellow-600">{summary.warnings}</div>
                <div className="text-xs text-gray-600">Warnings</div>
              </div>
              <div className="text-center p-3 bg-white rounded-lg">
                <div className="text-lg font-bold text-red-600">{summary.failed}</div>
                <div className="text-xs text-gray-600">Failed</div>
              </div>
            </div>
          </div>
        );
      })}

      {comparisons.length === 0 && !isLoading && !allDataExtracted && (
        <div className="text-center py-8 text-gray-500">
          Please extract data from all required sources to enable AI Agent comparison.
        </div>
      )}

      {comparisons.length === 0 && !isLoading && allDataExtracted && (
        <div className="text-center py-8 text-gray-500">
          All data sources ready. Click "Trigger GenAI Analysis" to start intelligent comparison.
        </div>
      )}
    </div>
  );
};

// Helper function to get display names for fields
function getFieldDisplayName(field: string): string {
  const fieldNames: Record<string, string> = {
    'quoteId': 'Quote ID',
    'customerName': 'Customer Name',
    'product': 'Product',
    'productId': 'Product ID',
    'operationType': 'Operation Type',
    'serviceStartDate': 'Service Start Date',
    'serviceEndDate': 'Service End Date',
    'orderTerm': 'Order Term',
    'quantity': 'Quantity',
    'unitCost': 'Unit Cost',
    'billingFrequency': 'Billing Frequency',
    // Billing system specific fields
    'billingCustomerName': 'Customer Name (Billing)',
    'billingSystemFrequency': 'Billing Frequency (System)'
  };
  
  return fieldNames[field] || field.replace(/([A-Z])/g, ' $1').trim();
}