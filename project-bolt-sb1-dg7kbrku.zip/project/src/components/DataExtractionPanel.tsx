import React, { useState, useEffect } from 'react';
import { Upload, Database, Globe, FileText, Loader2, CheckCircle, AlertCircle, Eye, CreditCard } from 'lucide-react';
import { DataSource, AuditType, ExtractedOrderForm, ContractData } from '../types/audit';
import { PDFExtractor } from '../services/pdfExtractor';
import { SAPApiService } from '../services/sapApi';
import { OreoScraper } from '../services/oreoScraper';
import { MithraService } from '../services/mithraService';
import { PDFExtractionViewer } from './PDFExtractionViewer';
import { AuditTypeService } from '../data/auditTypes';

interface DataExtractionPanelProps {
  dataSources: DataSource[];
  onDataSourceUpdate: (dataSource: DataSource) => void;
  contractNumber: string;
  sampleText?: string;
  auditType: AuditType;
}

export const DataExtractionPanel: React.FC<DataExtractionPanelProps> = ({
  dataSources,
  onDataSourceUpdate,
  contractNumber,
  sampleText = '',
  auditType
}) => {
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [extractionText, setExtractionText] = useState(sampleText);
  const [showExtractionViewer, setShowExtractionViewer] = useState(false);
  const [extractionData, setExtractionData] = useState<any>(null);

  const auditConfig = AuditTypeService.getAuditTypeConfig(auditType);

  // Update extraction text when sampleText prop changes
  useEffect(() => {
    setExtractionText(sampleText);
  }, [sampleText]);

  const handlePDFUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setPdfFile(file);
    const pdfSource = dataSources.find(ds => ds.type === 'pdf')!;
    
    onDataSourceUpdate({
      ...pdfSource,
      status: 'loading'
    });

    try {
      const extractedData: ExtractedOrderForm = await PDFExtractor.extractFromPDF(file);
      const fullExtractionData = PDFExtractor.generateExtractionReport(extractedData);
      
      setExtractionData(fullExtractionData);
      
      onDataSourceUpdate({
        ...pdfSource,
        status: 'success',
        data: extractedData.legacyData || extractedData,
        extractedAt: new Date().toISOString()
      });
    } catch (error) {
      onDataSourceUpdate({
        ...pdfSource,
        status: 'error',
        error: error instanceof Error ? error.message : 'Extraction failed'
      });
    }
  };

  const handleTextExtraction = async () => {
    if (!extractionText.trim()) return;

    const pdfSource = dataSources.find(ds => ds.type === 'pdf')!;
    
    onDataSourceUpdate({
      ...pdfSource,
      status: 'loading'
    });

    try {
      const extractedData: ExtractedOrderForm = await PDFExtractor.extractFromText(extractionText);
      const fullExtractionData = PDFExtractor.generateExtractionReport(extractedData);
      
      setExtractionData(fullExtractionData);
      
      onDataSourceUpdate({
        ...pdfSource,
        status: 'success',
        data: extractedData.legacyData || extractedData,
        extractedAt: new Date().toISOString()
      });
    } catch (error) {
      onDataSourceUpdate({
        ...pdfSource,
        status: 'error',
        error: error instanceof Error ? error.message : 'Extraction failed'
      });
    }
  };

  const handleSAPFetch = async () => {
    const sapSource = dataSources.find(ds => ds.type === 'sap')!;
    
    onDataSourceUpdate({
      ...sapSource,
      status: 'loading'
    });

    try {
      const sapData = await SAPApiService.fetchContractData(contractNumber);
      onDataSourceUpdate({
        ...sapSource,
        status: 'success',
        data: sapData,
        extractedAt: new Date().toISOString()
      });
    } catch (error) {
      onDataSourceUpdate({
        ...sapSource,
        status: 'error',
        error: error instanceof Error ? error.message : 'SAP API call failed'
      });
    }
  };

  const handleOreoScrape = async () => {
    const oreoSource = dataSources.find(ds => ds.type === 'oreo')!;
    
    onDataSourceUpdate({
      ...oreoSource,
      status: 'loading'
    });

    try {
      const oreoData = await OreoScraper.scrapeContractData(contractNumber);
      onDataSourceUpdate({
        ...oreoSource,
        status: 'success',
        data: oreoData,
        extractedAt: new Date().toISOString()
      });
    } catch (error) {
      onDataSourceUpdate({
        ...oreoSource,
        status: 'error',
        error: error instanceof Error ? error.message : 'OREO scraping failed'
      });
    }
  };

  const handleMithraFetch = async () => {
    const mithraSource = dataSources.find(ds => ds.type === 'mithra')!;
    
    onDataSourceUpdate({
      ...mithraSource,
      status: 'loading'
    });

    try {
      const mithraData = await MithraService.fetchBillingData(contractNumber);
      onDataSourceUpdate({
        ...mithraSource,
        status: 'success',
        data: mithraData,
        extractedAt: new Date().toISOString()
      });
    } catch (error) {
      onDataSourceUpdate({
        ...mithraSource,
        status: 'error',
        error: error instanceof Error ? error.message : 'Mithra/Billy API call failed'
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'loading': return <Loader2 className="h-5 w-5 animate-spin text-blue-500" />;
      case 'success': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error': return <AlertCircle className="h-5 w-5 text-red-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'border-green-200 bg-green-50';
      case 'loading': return 'border-blue-200 bg-blue-50';
      case 'error': return 'border-red-200 bg-red-50';
      default: return 'border-gray-200 bg-white';
    }
  };

  const getRequiredSources = () => {
    const requiredTypes = ['pdf', 'sap'];
    if (auditConfig.dataSources.tertiary) {
      if (auditConfig.dataSources.tertiary.includes('OREO')) requiredTypes.push('oreo');
      if (auditConfig.dataSources.tertiary.includes('Mithra')) requiredTypes.push('mithra');
    }
    return dataSources.filter(ds => requiredTypes.includes(ds.type));
  };

  const requiredSources = getRequiredSources();
  const pdfSource = dataSources.find(ds => ds.type === 'pdf');

  // Helper function to check if data is ExtractedOrderForm
  const isExtractedOrderForm = (data: any): data is ExtractedOrderForm => {
    return data && typeof data === 'object' && 'orderHeader' in data && 'orderLineItems' in data && 'summary' in data;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-900">Data Extraction</h2>
        <div className="text-sm text-gray-600">
          <span className="font-medium">Audit Type:</span> {auditConfig.name}
        </div>
      </div>
      
      {/* PDF Extraction - Side by Side Layout */}
      <div className={`rounded-lg border-2 p-6 ${getStatusColor(pdfSource?.status || 'pending')}`}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <FileText className="h-6 w-6 text-blue-600" />
            <h3 className="text-lg font-semibold">Order Form</h3>
            {getStatusIcon(pdfSource?.status || 'pending')}
          </div>
          
          {/* PDF Upload Controls - Moved to Header */}
          <div className="flex items-center space-x-4">
            {extractionData && (
              <button
                onClick={() => setShowExtractionViewer(true)}
                className="flex items-center space-x-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 text-sm"
              >
                <Eye className="h-4 w-4" />
                <span>View JSON Extract</span>
              </button>
            )}
            
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700">Upload Order Form:</label>
              <input
                type="file"
                accept=".pdf"
                onChange={handlePDFUpload}
                className="text-sm text-gray-500 file:mr-2 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
              />
            </div>
          </div>
        </div>
        
        {/* Side by Side Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Side - Text Input */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Paste contract text or JSON data for extraction
              </label>
              <textarea
                value={extractionText}
                onChange={(e) => setExtractionText(e.target.value)}
                placeholder="Paste contract text or JSON order form data here (or use the test data generator above)..."
                className="w-full h-64 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-sm"
              />
              <button
                onClick={handleTextExtraction}
                disabled={!extractionText.trim() || pdfSource?.status === 'loading'}
                className="mt-3 w-full px-4 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed font-medium"
              >
                {pdfSource?.status === 'loading' ? (
                  <div className="flex items-center justify-center space-x-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Extracting...</span>
                  </div>
                ) : (
                  'Extract from Text/JSON'
                )}
              </button>
            </div>
          </div>

          {/* Right Side - Extracted Results */}
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-900">Extracted Data Preview</h4>
              {pdfSource?.status === 'success' && pdfSource.data && (
                <div className="flex items-center space-x-2">
                  <select 
                    className="text-xs border border-gray-300 rounded px-2 py-1"
                    onChange={(e) => {
                      // This will allow switching between view modes
                      console.log('View mode:', e.target.value);
                    }}
                  >
                    <option value="structured">📋 Structured View</option>
                    <option value="all-fields">📊 All Fields View</option>
                    <option value="legacy">🔄 Legacy View</option>
                  </select>
                </div>
              )}
            </div>
            
            {pdfSource?.status === 'loading' && (
              <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-2" />
                  <p className="text-gray-600">Processing contract data...</p>
                </div>
              </div>
            )}

            {pdfSource?.status === 'success' && pdfSource.data && (
              <CompleteExtractionPreview data={pdfSource.data} extractedAt={pdfSource.extractedAt} key={pdfSource.extractedAt} />
            )}

            {pdfSource?.status === 'error' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-800 text-sm">
                  <strong>Extraction Error:</strong> {pdfSource.error}
                </p>
              </div>
            )}

            {(!pdfSource || pdfSource.status === 'pending') && (
              <div className="bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 p-8 text-center">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-gray-900 mb-2">No Data Extracted</h4>
                <p className="text-gray-600">
                  Upload a PDF file, paste contract text, or paste JSON order form data to extract.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SAP API */}
      <div className={`rounded-lg border-2 p-6 ${getStatusColor(dataSources.find(ds => ds.type === 'sap')?.status || 'pending')}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Database className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold">SAP System</h3>
            {getStatusIcon(dataSources.find(ds => ds.type === 'sap')?.status || 'pending')}
          </div>
          <button
            onClick={handleSAPFetch}
            disabled={dataSources.find(ds => ds.type === 'sap')?.status === 'loading'}
            className="w-40 h-12 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium"
          >
            {dataSources.find(ds => ds.type === 'sap')?.status === 'loading' ? 'Fetching...' : 'Fetch from SAP'}
          </button>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          Contract Number: {contractNumber}
        </p>
        
        {/* Show SAP data preview */}
        {dataSources.find(ds => ds.type === 'sap')?.data && (
          <div className="mt-4 p-3 bg-white rounded-md border">
            <h4 className="font-medium text-gray-900 mb-2">SAP Data Preview:</h4>
            <div className="text-sm text-gray-600 space-y-1">
              <div><strong>Solution Quote Number:</strong> {dataSources.find(ds => ds.type === 'sap')?.data?.solutionQuoteNumber}</div>
              <div><strong>Sold to Party:</strong> {dataSources.find(ds => ds.type === 'sap')?.data?.soldToParty}</div>
              <div><strong>Product:</strong> {dataSources.find(ds => ds.type === 'sap')?.data?.product}</div>
              <div><strong>Line Amount:</strong> {dataSources.find(ds => ds.type === 'sap')?.data?.lineAmount}</div>
            </div>
          </div>
        )}
      </div>

      {/* OREO UI Scraping */}
      {requiredSources.some(source => source.type === 'oreo') && (
        <div className={`rounded-lg border-2 p-6 ${getStatusColor(dataSources.find(ds => ds.type === 'oreo')?.status || 'pending')}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Globe className="h-6 w-6 text-purple-600" />
              <h3 className="text-lg font-semibold">OREO UI</h3>
              {getStatusIcon(dataSources.find(ds => ds.type === 'oreo')?.status || 'pending')}
            </div>
            <button
              onClick={handleOreoScrape}
              disabled={dataSources.find(ds => ds.type === 'oreo')?.status === 'loading'}
              className="w-40 h-12 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium"
            >
              {dataSources.find(ds => ds.type === 'oreo')?.status === 'loading' ? 'Scraping...' : 'Scrape OREO Data'}
            </button>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Screen scraping contract data from OREO UI
          </p>
          
          {/* Show OREO data preview */}
          {dataSources.find(ds => ds.type === 'oreo')?.data && (
            <div className="mt-4 p-3 bg-white rounded-md border">
              <h4 className="font-medium text-gray-900 mb-2">OREO UI Data Preview:</h4>
              <div className="text-sm text-gray-600 space-y-1">
                <div><strong>Solution Quote Number:</strong> {dataSources.find(ds => ds.type === 'oreo')?.data?.solutionQuoteNumber}</div>
                <div><strong>Sold to Party:</strong> {dataSources.find(ds => ds.type === 'oreo')?.data?.soldToParty}</div>
                <div><strong>Product:</strong> {dataSources.find(ds => ds.type === 'oreo')?.data?.product}</div>
                <div><strong>Quantity:</strong> {dataSources.find(ds => ds.type === 'oreo')?.data?.quantity}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Mithra/Billy System */}
      {requiredSources.some(source => source.type === 'mithra') && (
        <div className={`rounded-lg border-2 p-6 ${getStatusColor(dataSources.find(ds => ds.type === 'mithra')?.status || 'pending')}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <CreditCard className="h-6 w-6 text-orange-600" />
              <h3 className="text-lg font-semibold">Mithra/Billy System</h3>
              {getStatusIcon(dataSources.find(ds => ds.type === 'mithra')?.status || 'pending')}
            </div>
            <button
              onClick={handleMithraFetch}
              disabled={dataSources.find(ds => ds.type === 'mithra')?.status === 'loading'}
              className="w-40 h-12 bg-orange-600 text-white rounded-md hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed font-medium"
            >
              {dataSources.find(ds => ds.type === 'mithra')?.status === 'loading' ? 'Fetching...' : 'Fetch Billing Data'}
            </button>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Fetching billing data from Mithra/Billy System
          </p>
          
          {/* Show Mithra/Billy data preview */}
          {dataSources.find(ds => ds.type === 'mithra')?.data && (
            <div className="mt-4 p-3 bg-white rounded-md border">
              <h4 className="font-medium text-gray-900 mb-2">Mithra/Billy Data Preview:</h4>
              <div className="text-sm text-gray-600 space-y-1">
                <div><strong>Sold to Party:</strong> {dataSources.find(ds => ds.type === 'mithra')?.data?.soldToParty}</div>
                <div><strong>Billing Party:</strong> {dataSources.find(ds => ds.type === 'mithra')?.data?.billingParty}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Error Messages */}
      {dataSources.some(ds => ds.error) && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h4 className="font-medium text-red-800 mb-2">Extraction Errors:</h4>
          <ul className="text-sm text-red-700 space-y-1">
            {dataSources.filter(ds => ds.error).map(ds => (
              <li key={ds.id}>• {ds.name}: {ds.error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* PDF Extraction Viewer Modal */}
      {showExtractionViewer && extractionData && (
        <PDFExtractionViewer
          extractionData={extractionData}
          onClose={() => setShowExtractionViewer(false)}
        />
      )}
    </div>
  );
};

// New Complete Extraction Preview Component
const CompleteExtractionPreview: React.FC<{ data: any; extractedAt?: string }> = ({ data, extractedAt }) => {
  const [viewMode, setViewMode] = useState<'structured' | 'all-fields' | 'legacy'>('all-fields');
  
  // Force re-render when data changes
  React.useEffect(() => {
    console.log('Preview data updated:', data);
  }, [data]);
  
  // Helper function to check if data is ExtractedOrderForm
  const isExtractedOrderForm = (data: any): data is ExtractedOrderForm => {
    return data && typeof data === 'object' && 'orderHeader' in data && 'orderLineItems' in data && 'summary' in data;
  };
  
  const isStructured = isExtractedOrderForm(data);

  // Count all fields function
  const countAllFields = (data: any): { total: number; filled: number; breakdown: any } => {
    if (isExtractedOrderForm(data)) {
      const headerFields = Object.values(data.orderHeader).filter(v => v && v.toString().trim() !== '').length;
      const lineItemFields = data.orderLineItems.reduce((acc, item) => {
        return acc + Object.values(item).filter(v => v !== null && v !== undefined && v.toString().trim() !== '').length;
      }, 0);
      const summaryFields = Object.values(data.summary).filter(v => v && v !== 0).length;
      
      return {
        total: 9 + (data.orderLineItems.length * 10) + 1,
        filled: headerFields + lineItemFields + summaryFields,
        breakdown: {
          header: { total: 9, filled: headerFields },
          lineItems: { total: data.orderLineItems.length * 10, filled: lineItemFields },
          summary: { total: 1, filled: summaryFields }
        }
      };
    } else {
      // Legacy data
      const filled = Object.values(data).filter(v => v && v.toString().trim() !== '').length;
      const total = Object.keys(data).length;
      return { total, filled, breakdown: { legacy: { total, filled } } };
    }
  };

  const fieldStats = countAllFields(data);

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-4 max-h-96 overflow-y-auto">
      {/* Header with View Mode Selector */}
      <div className="flex items-center justify-between border-b pb-3">
        <div className="flex items-center space-x-2">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <h5 className="font-semibold text-gray-800">
            {isExtractedOrderForm(data) ? 'Structured Order Form Data' : 'Legacy Contract Data'}
          </h5>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-xs text-gray-500">View:</span>
          <select 
            value={viewMode}
            onChange={(e) => setViewMode(e.target.value as any)}
            className="text-xs border border-gray-300 rounded px-2 py-1 bg-white"
          >
            <option value="structured">📋 Structured</option>
            <option value="all-fields">📊 All Fields</option>
            <option value="legacy">🔄 Legacy</option>
          </select>
        </div>
      </div>

      {/* Field Statistics Bar */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 p-3 rounded-lg border">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Extraction Progress</span>
          <span className="text-sm font-bold text-gray-900">
            {fieldStats.filled}/{fieldStats.total} fields ({Math.round((fieldStats.filled / fieldStats.total) * 100)}%)
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(fieldStats.filled / fieldStats.total) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Content based on view mode */}
      {viewMode === 'structured' && isExtractedOrderForm(data) && (
        <StructuredView data={data} key={`structured-${extractedAt}`} />
      )}
      
      {viewMode === 'all-fields' && (
        <AllFieldsView data={data} isStructured={isStructured} key={`all-fields-${extractedAt}`} />
      )}
      
      {viewMode === 'legacy' && (
        <LegacyView data={isStructured ? data.legacyData || data : data} key={`legacy-${extractedAt}`} />
      )}

      {/* Footer Info */}
      <div className="pt-3 mt-4 border-t border-gray-200">
        {extractedAt && (
          <p className="text-xs text-gray-500">
            Extracted at: {new Date(extractedAt).toLocaleString()}
          </p>
        )}
        <div className="flex justify-between items-center mt-2">
          <p className="text-xs text-gray-500">
            Type: {isStructured ? '✅ Complete Structured Format' : '🔄 Legacy Format'}
          </p>
          <p className="text-xs text-gray-500">
            {fieldStats.filled} of {fieldStats.total} fields extracted
          </p>
        </div>
      </div>
    </div>
  );
};

// Structured View Component
const StructuredView: React.FC<{ data: ExtractedOrderForm }> = ({ data }) => (
  <div className="space-y-4">
    {/* Order Header */}
    <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
      <h6 className="font-medium text-blue-900 mb-3 flex items-center">
        📋 Order Header Section ({Object.keys(data.orderHeader || {}).length} Fields)
      </h6>
      <div className="grid grid-cols-1 gap-2 text-sm">
        {Object.entries(data.orderHeader).map(([key, value]) => (
          <div key={key} className="flex justify-between">
            <span className="font-medium text-gray-700 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
            <span className={`text-gray-900 text-right ${key.includes('Details') ? 'text-xs max-w-xs truncate' : ''}`}>
              {value && value.toString().trim() !== '' ? value.toString() : 'Not extracted'}
            </span>
          </div>
        ))}
      </div>
    </div>

    {/* Order Line Items */}
    <div className="bg-green-50 p-3 rounded-lg border border-green-200">
      <h6 className="font-medium text-green-900 mb-3 flex items-center">
        📦 Order Line Items ({(data.orderLineItems || []).length} items)
      </h6>
      <div className="space-y-3">
        {(data.orderLineItems || []).map((item, index) => (
          <div key={index} className="bg-white p-3 rounded border">
            <div className="font-medium text-gray-800 text-sm mb-2 border-b pb-1">
              Item {index + 1}: {item.serviceName || 'Service Item'}
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {Object.entries(item).map(([key, value]) => (
                <div key={key} className="flex justify-between">
                  <span className="font-medium text-gray-700 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                  <span className="text-gray-900">
                    {value !== null && value !== undefined && value.toString().trim() !== '' 
                      ? (typeof value === 'number' ? value.toLocaleString() : value.toString())
                      : 'Not extracted'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* Summary */}
    <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
      <h6 className="font-medium text-yellow-900 mb-3 flex items-center">
        💰 Summary Section
      </h6>
      <div className="text-center">
        <div className="text-2xl font-bold text-gray-900">
          ₹{(data.summary?.totalINR && data.summary.totalINR > 0) ? data.summary.totalINR.toLocaleString() : 'Not extracted'}
        </div>
        <div className="text-sm text-gray-600">Total INR (Numeric)</div>
      </div>
    </div>
  </div>
);

// All Fields View Component
const AllFieldsView: React.FC<{ data: any; isStructured: boolean }> = ({ data, isStructured }) => {
  const getAllFields = (data: any): Array<{ section: string; field: string; value: any; type: string }> => {
    const fields: Array<{ section: string; field: string; value: any; type: string }> = [];
    
    if (isStructured) {
      // Order Header fields - show actual values
      Object.entries(data.orderHeader || {}).forEach(([key, value]) => {
        fields.push({
          section: 'Order Header',
          field: key.replace(/([A-Z])/g, ' $1').trim().replace(/^./, str => str.toUpperCase()),
          value: value && value.toString().trim() !== '' ? value.toString() : 'Not extracted',
          type: typeof value
        });
      });
      
      // Line Item fields - show actual values
      (data.orderLineItems || []).forEach((item: any, index: number) => {
        Object.entries(item || {}).forEach(([key, value]) => {
          fields.push({
            section: `Line Item ${index + 1}`,
            field: key.replace(/([A-Z])/g, ' $1').trim().replace(/^./, str => str.toUpperCase()),
            value: value !== null && value !== undefined && value.toString().trim() !== '' 
              ? (typeof value === 'number' ? value.toLocaleString() : value.toString())
              : 'Not extracted',
            type: typeof value
          });
        });
      });
      
      // Summary fields - show actual values
      Object.entries(data.summary || {}).forEach(([key, value]) => {
        fields.push({
          section: 'Summary',
          field: key.replace(/([A-Z])/g, ' $1').trim().replace(/^./, str => str.toUpperCase()),
          value: value !== null && value !== undefined && value.toString().trim() !== '' 
            ? (typeof value === 'number' ? value.toLocaleString() : value.toString())
            : 'Not extracted',
          type: typeof value
        });
      });
    } else {
      // Legacy data - show actual values
      Object.entries(data || {}).forEach(([key, value]) => {
        fields.push({
          section: 'Contract Data',
          field: key.replace(/([A-Z])/g, ' $1').trim().replace(/^./, str => str.toUpperCase()),
          value: value && value.toString().trim() !== '' ? value.toString() : 'Not extracted',
          type: typeof value
        });
      });
    }
    
    return fields;
  };

  const allFields = getAllFields(data);
  const groupedFields = allFields.reduce((acc, field) => {
    if (!acc[field.section]) acc[field.section] = [];
    acc[field.section].push(field);
    return acc;
  }, {} as Record<string, typeof allFields>);

  return (
    <div className="space-y-4">
      <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
        <h6 className="font-medium text-purple-900 mb-2">📊 Complete Field Inventory</h6>
        <div className="text-sm text-purple-800">
          Total: {allFields.length} fields | Extracted: {allFields.filter(f => f.value !== 'Not extracted').length} | 
          Missing: {allFields.filter(f => f.value === 'Not extracted').length}
        </div>
      </div>
      
      {Object.entries(groupedFields).map(([section, fields]) => (
        <div key={section} className="bg-gray-50 p-3 rounded-lg border">
          <h6 className="font-medium text-gray-900 mb-3">
            {section} ({fields.filter(f => f.value !== 'Not extracted').length}/{fields.length} fields extracted)
          </h6>
          <div className="space-y-1">
            {fields.map((field, index) => (
              <div key={index} className={`flex justify-between items-center py-2 px-2 rounded border-b border-gray-200 last:border-b-0 ${
                field.value === 'Not extracted' ? 'bg-red-50' : 'bg-green-50'
              }`}>
                <span className="font-medium text-gray-700 text-sm capitalize">{field.field}:</span>
                <div className="flex items-center space-x-2">
                  <span className={`text-sm font-mono ${field.value === 'Not extracted' ? 'text-red-600 italic' : 'text-gray-900 font-semibold'}`}>
                    {field.value === 'Not extracted' ? '✗ Not extracted' : `✓ ${field.value}`}
                  </span>
                  <span className="text-xs text-gray-400 bg-gray-100 px-1 rounded">
                    {field.type}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

// Legacy View Component
const LegacyView: React.FC<{ data: any }> = ({ data }) => {
  if (!data) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No legacy data available</p>
      </div>
    );
  }

  return (
    <div className="space-y-2 text-sm">
      <h6 className="font-semibold text-gray-800 mb-3 border-b pb-2">🔄 Legacy Contract Data Format</h6>
      
      {Object.entries(data || {}).map(([key, value]) => (
        <div key={key} className={`flex justify-between py-1 px-2 rounded ${
          value && value.toString().trim() !== '' ? 'bg-green-50' : 'bg-red-50'
        }`}>
          <span className="font-medium text-gray-700 capitalize">
            {key.replace(/([A-Z])/g, ' $1').trim().replace(/^./, str => str.toUpperCase())}:
          </span>
          <span className={`text-right font-mono ${
            value && value.toString().trim() !== '' ? 'text-gray-900 font-semibold' : 'text-red-600 italic'
          }`}>
            {value && value.toString().trim() !== '' ? `✓ ${value.toString()}` : '✗ Not extracted'}
          </span>
        </div>
      ))}
    </div>
  );
};