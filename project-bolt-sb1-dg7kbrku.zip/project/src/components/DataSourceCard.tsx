import React from 'react';
import { CheckCircle, AlertCircle, Clock, FileText, Database, Globe } from 'lucide-react';

interface DataSourceCardProps {
  title: string;
  type: 'pdf' | 'sap' | 'oreo';
  status: 'loaded' | 'loading' | 'error';
  data: Record<string, any>;
  lastUpdated?: string;
}

export const DataSourceCard: React.FC<DataSourceCardProps> = ({ 
  title, 
  type, 
  status, 
  data, 
  lastUpdated 
}) => {
  const getIcon = () => {
    switch (type) {
      case 'pdf': return <FileText className="h-5 w-5" />;
      case 'sap': return <Database className="h-5 w-5" />;
      case 'oreo': return <Globe className="h-5 w-5" />;
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'loaded': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'loading': return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'loaded': return 'border-green-200 bg-green-50';
      case 'loading': return 'border-yellow-200 bg-yellow-50';
      case 'error': return 'border-red-200 bg-red-50';
    }
  };

  return (
    <div className={`border-2 rounded-lg p-6 ${getStatusColor()}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-white rounded-md shadow-sm">
            {getIcon()}
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
            <p className="text-sm text-gray-600">Data Source</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {getStatusIcon()}
          <span className="text-sm font-medium text-gray-700 capitalize">{status}</span>
        </div>
      </div>
      
      <div className="space-y-3">
        {Object.entries(data).map(([key, value]) => (
          <div key={key} className="flex justify-between items-center py-2 border-b border-gray-200 last:border-b-0">
            <span className="text-sm font-medium text-gray-700">{key}:</span>
            <span className="text-sm text-gray-900 font-mono">{value}</span>
          </div>
        ))}
      </div>
      
      {lastUpdated && (
        <div className="mt-4 pt-3 border-t border-gray-200">
          <p className="text-xs text-gray-500">Last updated: {lastUpdated}</p>
        </div>
      )}
    </div>
  );
};