import React, { useState, useEffect } from 'react';
import { 
  Brain, Settings, Plus, Edit3, Trash2, Save, X, Download, Upload, 
  CheckCircle, AlertCircle, Zap, TestTube, Eye, EyeOff, Copy, 
  Wifi, WifiOff, Loader2
} from 'lucide-react';
import { LLMConfig, LLMConfigService } from '../services/llmConfigService';

export const LLMConfigPanel: React.FC = () => {
  const [configs, setConfigs] = useState<LLMConfig[]>([]);
  const [editingConfig, setEditingConfig] = useState<LLMConfig | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [showApiKeys, setShowApiKeys] = useState<Record<string, boolean>>({});
  const [testingConnection, setTestingConnection] = useState<string | null>(null);
  const [connectionResults, setConnectionResults] = useState<Record<string, { success: boolean; message: string }>>({});
  const [importData, setImportData] = useState('');
  const [showImport, setShowImport] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    loadConfigs();
  }, []);

  const loadConfigs = () => {
    const allConfigs = LLMConfigService.getAllConfigs();
    setConfigs(allConfigs);
  };

  const handleCreateNew = () => {
    const newConfig: LLMConfig = {
      id: `config_${Date.now()}`,
      name: 'New LLM Configuration',
      provider: 'openai',
      model: 'gpt-4',
      apiEndpoint: 'https://api.openai.com/v1/chat/completions',
      apiKeyEnvVar: 'VITE_OPENAI_API_KEY',
      maxTokens: 3000,
      temperature: 0.2,
      isActive: false,
      description: '',
      supportedFeatures: []
    };
    setEditingConfig(newConfig);
    setIsCreating(true);
  };

  const handleEdit = (config: LLMConfig) => {
    setEditingConfig({ ...config });
    setIsCreating(false);
  };

  const handleSave = () => {
    if (!editingConfig) return;

    const errors = LLMConfigService.validateConfig(editingConfig);
    if (errors.length > 0) {
      setMessage({ type: 'error', text: errors.join(', ') });
      return;
    }

    if (isCreating) {
      LLMConfigService.addConfig(editingConfig);
    } else {
      LLMConfigService.updateConfig(editingConfig);
    }

    loadConfigs();
    setEditingConfig(null);
    setIsCreating(false);
    setMessage({ type: 'success', text: 'Configuration saved successfully' });
  };

  const handleCancel = () => {
    setEditingConfig(null);
    setIsCreating(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this configuration?')) {
      LLMConfigService.deleteConfig(id);
      loadConfigs();
      setMessage({ type: 'success', text: 'Configuration deleted successfully' });
    }
  };

  const handleSetActive = (id: string) => {
    LLMConfigService.setActiveConfig(id);
    loadConfigs();
    setMessage({ type: 'success', text: 'Active configuration updated' });
  };

  const handleTestConnection = async (config: LLMConfig) => {
    setTestingConnection(config.id);
    
    try {
      const result = await LLMConfigService.testConnection(config);
      setConnectionResults(prev => ({
        ...prev,
        [config.id]: result
      }));
      
      setMessage({ 
        type: result.success ? 'success' : 'error', 
        text: result.message 
      });
    } catch (error) {
      setConnectionResults(prev => ({
        ...prev,
        [config.id]: {
          success: false,
          message: 'Connection test failed'
        }
      }));
    } finally {
      setTestingConnection(null);
    }
  };

  const handleClone = (config: LLMConfig) => {
    const clonedConfig: LLMConfig = {
      ...config,
      id: `${config.id}_copy_${Date.now()}`,
      name: `${config.name} (Copy)`,
      isActive: false
    };
    
    LLMConfigService.addConfig(clonedConfig);
    loadConfigs();
    setMessage({ type: 'success', text: 'Configuration cloned successfully' });
  };

  const handleExport = () => {
    const exportData = LLMConfigService.exportConfigs();
    const blob = new Blob([exportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `llm-configurations-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const result = LLMConfigService.importConfigs(importData);
    setMessage({ type: result.success ? 'success' : 'error', text: result.message });
    
    if (result.success) {
      loadConfigs();
      setShowImport(false);
      setImportData('');
    }
  };

  const toggleApiKeyVisibility = (configId: string) => {
    setShowApiKeys(prev => ({
      ...prev,
      [configId]: !prev[configId]
    }));
  };

  const getApiKeyValue = (envVar: string): string => {
    const value = import.meta.env[envVar];
    return value || 'Not configured';
  };

  const getConnectionStatus = (configId: string) => {
    const result = connectionResults[configId];
    if (!result) return null;
    
    return (
      <div className={`flex items-center space-x-1 text-xs ${
        result.success ? 'text-green-600' : 'text-red-600'
      }`}>
        {result.success ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
        <span>{result.success ? 'Connected' : 'Failed'}</span>
      </div>
    );
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Brain className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">LLM Model Configuration</h2>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowImport(true)}
            className="flex items-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </button>
          <button
            onClick={handleExport}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
          <button
            onClick={handleCreateNew}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            <Plus className="h-4 w-4" />
            <span>New Config</span>
          </button>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`mb-4 p-3 rounded-lg border ${
          message.type === 'success' 
            ? 'bg-green-50 border-green-200 text-green-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center space-x-2">
            {message.type === 'success' ? 
              <CheckCircle className="h-4 w-4" /> : 
              <AlertCircle className="h-4 w-4" />
            }
            <span>{message.text}</span>
            <button
              onClick={() => setMessage(null)}
              className="ml-auto text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Configuration List */}
      <div className="space-y-4">
        {configs.map((config) => (
          <div key={config.id} className={`bg-white border-2 rounded-lg p-6 ${
            config.isActive ? 'border-green-300 bg-green-50' : 'border-gray-200'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <span className="text-2xl">{LLMConfigService.getProviderIcon(config.provider)}</span>
                  <h3 className="text-lg font-semibold text-gray-900">{config.name}</h3>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${
                    LLMConfigService.getProviderColor(config.provider)
                  }`}>
                    {config.provider.toUpperCase()}
                  </span>
                  {config.isActive && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <Zap className="h-3 w-3 mr-1" />
                      Active
                    </span>
                  )}
                </div>
                
                <p className="text-gray-600 mb-3">{config.description}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-700">Model:</span>
                    <span className="ml-2 font-mono text-gray-900">{config.model}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Max Tokens:</span>
                    <span className="ml-2 text-gray-900">{config.maxTokens.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Temperature:</span>
                    <span className="ml-2 text-gray-900">{config.temperature}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">API Key:</span>
                    <div className="flex items-center space-x-2 ml-2">
                      <span className="font-mono text-xs text-gray-600">
                        {showApiKeys[config.id] 
                          ? getApiKeyValue(config.apiKeyEnvVar)
                          : '••••••••••••••••'
                        }
                      </span>
                      <button
                        onClick={() => toggleApiKeyVisibility(config.id)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        {showApiKeys[config.id] ? 
                          <EyeOff className="h-3 w-3" /> : 
                          <Eye className="h-3 w-3" />
                        }
                      </button>
                    </div>
                  </div>
                </div>

                {config.supportedFeatures.length > 0 && (
                  <div className="mt-3">
                    <span className="text-sm font-medium text-gray-700">Features:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {config.supportedFeatures.map(feature => (
                        <span key={feature} className="inline-flex items-center px-2 py-1 rounded bg-blue-100 text-blue-800 text-xs">
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mt-3 flex items-center space-x-4">
                  {getConnectionStatus(config.id)}
                  <span className="text-xs text-gray-500">
                    Endpoint: {config.apiEndpoint.length > 50 ? 
                      config.apiEndpoint.substring(0, 50) + '...' : 
                      config.apiEndpoint
                    }
                  </span>
                </div>
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                <button
                  onClick={() => handleTestConnection(config)}
                  disabled={testingConnection === config.id}
                  className="p-2 text-blue-400 hover:text-blue-600 disabled:opacity-50"
                  title="Test connection"
                >
                  {testingConnection === config.id ? 
                    <Loader2 className="h-4 w-4 animate-spin" /> : 
                    <TestTube className="h-4 w-4" />
                  }
                </button>
                
                {!config.isActive && (
                  <button
                    onClick={() => handleSetActive(config.id)}
                    className="p-2 text-green-400 hover:text-green-600"
                    title="Set as active"
                  >
                    <Zap className="h-4 w-4" />
                  </button>
                )}
                
                <button
                  onClick={() => handleEdit(config)}
                  className="p-2 text-gray-400 hover:text-gray-600"
                  title="Edit"
                >
                  <Edit3 className="h-4 w-4" />
                </button>
                
                <button
                  onClick={() => handleClone(config)}
                  className="p-2 text-purple-400 hover:text-purple-600"
                  title="Clone"
                >
                  <Copy className="h-4 w-4" />
                </button>
                
                <button
                  onClick={() => handleDelete(config.id)}
                  className="p-2 text-red-400 hover:text-red-600"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
        
        {configs.length === 0 && (
          <div className="text-center py-12">
            <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No LLM configurations found</h3>
            <p className="text-gray-600 mb-4">Create your first LLM configuration to get started.</p>
            <button
              onClick={handleCreateNew}
              className="inline-flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              <Plus className="h-4 w-4" />
              <span>Create Configuration</span>
            </button>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingConfig && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-lg font-semibold">
                {isCreating ? 'Create New LLM Configuration' : 'Edit LLM Configuration'}
              </h3>
              <button onClick={handleCancel} className="text-gray-400 hover:text-gray-600">
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                    <input
                      type="text"
                      value={editingConfig.name}
                      onChange={(e) => setEditingConfig({...editingConfig, name: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Provider</label>
                    <select
                      value={editingConfig.provider}
                      onChange={(e) => setEditingConfig({...editingConfig, provider: e.target.value as any})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="openai">OpenAI</option>
                      <option value="gemini">Google Gemini</option>
                      <option value="anthropic">Anthropic Claude</option>
                      <option value="azure">Azure OpenAI</option>
                    </select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
                    <input
                      type="text"
                      value={editingConfig.model}
                      onChange={(e) => setEditingConfig({...editingConfig, model: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="e.g., gpt-4, gemini-pro, claude-3-opus"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">API Key Environment Variable</label>
                    <input
                      type="text"
                      value={editingConfig.apiKeyEnvVar}
                      onChange={(e) => setEditingConfig({...editingConfig, apiKeyEnvVar: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="e.g., VITE_OPENAI_API_KEY"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">API Endpoint</label>
                  <input
                    type="url"
                    value={editingConfig.apiEndpoint}
                    onChange={(e) => setEditingConfig({...editingConfig, apiEndpoint: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="https://api.openai.com/v1/chat/completions"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Max Tokens</label>
                    <input
                      type="number"
                      value={editingConfig.maxTokens}
                      onChange={(e) => setEditingConfig({...editingConfig, maxTokens: parseInt(e.target.value) || 3000})}
                      min="100"
                      max="10000"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Temperature</label>
                    <input
                      type="number"
                      value={editingConfig.temperature}
                      onChange={(e) => setEditingConfig({...editingConfig, temperature: parseFloat(e.target.value) || 0.2})}
                      min="0"
                      max="2"
                      step="0.1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    value={editingConfig.description}
                    onChange={(e) => setEditingConfig({...editingConfig, description: e.target.value})}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Describe this LLM configuration..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Supported Features (comma-separated)</label>
                  <input
                    type="text"
                    value={editingConfig.supportedFeatures.join(', ')}
                    onChange={(e) => setEditingConfig({
                      ...editingConfig, 
                      supportedFeatures: e.target.value.split(',').map(f => f.trim()).filter(f => f)
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Data Comparison, Rule Extraction, Risk Assessment"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-3 p-6 border-t bg-gray-50">
              <button
                onClick={handleCancel}
                className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                <Save className="h-4 w-4" />
                <span>Save Configuration</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImport && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-lg font-semibold">Import LLM Configurations</h3>
              <button onClick={() => setShowImport(false)} className="text-gray-400 hover:text-gray-600">
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">JSON Data</label>
                <textarea
                  value={importData}
                  onChange={(e) => setImportData(e.target.value)}
                  rows={10}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-sm"
                  placeholder="Paste your exported LLM configurations JSON here..."
                />
              </div>
              
              <div className="flex items-center justify-end space-x-3">
                <button
                  onClick={() => setShowImport(false)}
                  className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleImport}
                  disabled={!importData.trim()}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
                >
                  <Upload className="h-4 w-4" />
                  <span>Import</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};