import React, { useState } from 'react';
import { FileText, Download, Eye, Code, CheckCircle, AlertTriangle, XCircle, PenTool } from 'lucide-react';
import { ExtractedOrderForm, OrderLineItem } from '../types/audit';

interface PDFExtractionViewerProps {
  extractionData: any;
  onClose: () => void;
}

interface ValidationResult {
  field: string;
  isValid: boolean;
  severity: 'critical' | 'high' | 'medium' | 'low';
  message: string;
  value?: string;
  expectedFormat?: string;
  suggestions?: string[];
}

interface ComplianceCheck {
  requirement: string;
  status: 'present' | 'missing' | 'partial';
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  location?: string;
}
export const PDFExtractionViewer: React.FC<PDFExtractionViewerProps> = ({
  extractionData,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'raw' | 'validation'>('overview');

  // Real validation logic implementation
  const performRealValidation = (): {
    fieldValidation: ValidationResult[];
    complianceChecks: ComplianceCheck[];
    overallScore: number;
    criticalIssues: number;
    recommendations: string[];
  } => {
    const fieldValidation: ValidationResult[] = [];
    const complianceChecks: ComplianceCheck[] = [];
    const recommendations: string[] = [];
    
    const contractData = extractionData.contractData || {};
    
    // 1. Quote ID Validation
    const quoteId = contractData.quoteId || contractData.contractNumber;
    if (quoteId) {
      const quoteIdPattern = /^Q-\d{6}$/;
      const isValidFormat = quoteIdPattern.test(quoteId);
      fieldValidation.push({
        field: 'Quote ID',
        isValid: isValidFormat,
        severity: isValidFormat ? 'low' : 'high',
        message: isValidFormat 
          ? 'Quote ID format is correct (Q-XXXXXX)' 
          : 'Quote ID format should be Q-XXXXXX (Q- followed by 6 digits)',
        value: quoteId,
        expectedFormat: 'Q-XXXXXX',
        suggestions: isValidFormat ? [] : ['Verify quote ID with sales team', 'Check for typos in quote number']
      });
    } else {
      fieldValidation.push({
        field: 'Quote ID',
        isValid: false,
        severity: 'critical',
        message: 'Quote ID is missing - required for contract processing',
        expectedFormat: 'Q-XXXXXX',
        suggestions: ['Extract quote ID from contract header', 'Contact sales team for quote number']
      });
    }
    
    // 2. Customer Name Validation
    const customerName = contractData.customerName;
    if (customerName) {
      const hasLegalEntity = /\b(Ltd|Limited|Inc|Corporation|Corp|LLC|Pvt|Private)\b/i.test(customerName);
      const minLength = customerName.length >= 3;
      const isValid = hasLegalEntity && minLength;
      
      fieldValidation.push({
        field: 'Customer Name',
        isValid: isValid,
        severity: isValid ? 'low' : 'medium',
        message: isValid 
          ? 'Customer name includes legal entity designation' 
          : 'Customer name should include legal entity (Ltd, Inc, Corp, etc.)',
        value: customerName,
        suggestions: isValid ? [] : ['Verify complete legal entity name', 'Check company registration details']
      });
    } else {
      fieldValidation.push({
        field: 'Customer Name',
        isValid: false,
        severity: 'critical',
        message: 'Customer name is missing - required for contract validity',
        suggestions: ['Extract customer name from contract header', 'Verify billing entity information']
      });
    }
    
    // 3. Financial Amount Validation
    const unitCost = contractData.unitCost || contractData.contractValue;
    if (unitCost) {
      const amountPattern = /^[₹$€£]\s*[\d,]+(?:\.\d{2})?$/;
      const isValidFormat = amountPattern.test(unitCost);
      const hasValidCurrency = /^[₹$€£]/.test(unitCost);
      
      fieldValidation.push({
        field: 'Financial Amount',
        isValid: isValidFormat && hasValidCurrency,
        severity: isValidFormat ? 'low' : 'high',
        message: isValidFormat 
          ? 'Financial amount format is correct with currency symbol' 
          : 'Financial amount should include currency symbol and proper formatting',
        value: unitCost,
        expectedFormat: '₹X,XXX.XX or $X,XXX.XX',
        suggestions: isValidFormat ? [] : ['Verify currency symbol', 'Check decimal places', 'Confirm amount accuracy']
      });
    } else {
      fieldValidation.push({
        field: 'Financial Amount',
        isValid: false,
        severity: 'critical',
        message: 'Financial amount is missing - required for billing setup',
        expectedFormat: '₹X,XXX.XX or $X,XXX.XX',
        suggestions: ['Extract unit cost or contract value', 'Verify pricing information']
      });
    }
    
    // 4. Date Validation
    const startDate = contractData.serviceStartDate || contractData.startDate;
    const endDate = contractData.serviceEndDate || contractData.endDate;
    
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const isValidDateRange = start < end;
      const isReasonableDuration = (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24) >= 30; // At least 30 days
      
      fieldValidation.push({
        field: 'Service Dates',
        isValid: isValidDateRange && isReasonableDuration,
        severity: isValidDateRange ? (isReasonableDuration ? 'low' : 'medium') : 'high',
        message: isValidDateRange 
          ? (isReasonableDuration ? 'Service dates are valid with reasonable duration' : 'Service duration is less than 30 days - verify if correct')
          : 'Service end date must be after start date',
        value: `${startDate} to ${endDate}`,
        suggestions: isValidDateRange && isReasonableDuration ? [] : ['Verify service period with customer', 'Check contract terms']
      });
    } else {
      fieldValidation.push({
        field: 'Service Dates',
        isValid: false,
        severity: 'high',
        message: 'Service start or end date is missing',
        suggestions: ['Extract service period from contract', 'Confirm service timeline with customer']
      });
    }
    
    // 5. Product Information Validation
    const product = contractData.product;
    const productId = contractData.productId;
    
    if (product && productId) {
      const hasValidProductId = /^[A-Z]{3,}-[A-Z0-9-]+$/i.test(productId);
      fieldValidation.push({
        field: 'Product Information',
        isValid: hasValidProductId,
        severity: hasValidProductId ? 'low' : 'medium',
        message: hasValidProductId 
          ? 'Product name and ID are present with valid format' 
          : 'Product ID format should follow standard pattern (XXX-XXX-XXX)',
        value: `${product} (${productId})`,
        expectedFormat: 'XXX-XXX-XXX (e.g., GAPPS-ENT-PLUS)',
        suggestions: hasValidProductId ? [] : ['Verify product SKU format', 'Check product catalog']
      });
    } else {
      fieldValidation.push({
        field: 'Product Information',
        isValid: false,
        severity: 'high',
        message: 'Product name or ID is missing',
        suggestions: ['Extract product details from contract', 'Verify SKU with product team']
      });
    }
    
    // 6. Quantity Validation
    const quantity = contractData.quantity;
    if (quantity) {
      const numericQuantity = parseInt(quantity.toString().replace(/,/g, ''));
      const isValidQuantity = numericQuantity > 0 && numericQuantity <= 1000000;
      
      fieldValidation.push({
        field: 'Quantity',
        isValid: isValidQuantity,
        severity: isValidQuantity ? 'low' : 'medium',
        message: isValidQuantity 
          ? 'Quantity is within reasonable range' 
          : 'Quantity seems unusually high or invalid - please verify',
        value: quantity.toString(),
        suggestions: isValidQuantity ? [] : ['Verify quantity with customer', 'Check for data entry errors']
      });
    } else {
      fieldValidation.push({
        field: 'Quantity',
        isValid: false,
        severity: 'high',
        message: 'Quantity is missing - required for licensing',
        suggestions: ['Extract quantity from contract', 'Confirm user count with customer']
      });
    }
    
    // COMPLIANCE CHECKS
    
    // 1. Required Contract Clauses
    const extractedText = extractionData.rawText?.fullDocument || '';
    
    complianceChecks.push({
      requirement: 'Customer Information',
      status: customerName ? 'present' : 'missing',
      severity: customerName ? 'low' : 'critical',
      description: 'Complete customer information including legal entity name',
      location: customerName ? 'Contract header section' : 'Not found'
    });
    
    complianceChecks.push({
      requirement: 'Product Specifications',
      status: (product && productId) ? 'present' : 'missing',
      severity: (product && productId) ? 'low' : 'high',
      description: 'Detailed product information and SKU codes',
      location: (product && productId) ? 'Product details section' : 'Not found'
    });
    
    complianceChecks.push({
      requirement: 'Pricing Information',
      status: unitCost ? 'present' : 'missing',
      severity: unitCost ? 'low' : 'critical',
      description: 'Unit costs, total amounts, and currency information',
      location: unitCost ? 'Financial summary section' : 'Not found'
    });
    
    complianceChecks.push({
      requirement: 'Service Terms',
      status: (startDate && endDate) ? 'present' : 'missing',
      severity: (startDate && endDate) ? 'low' : 'high',
      description: 'Service start date, end date, and duration',
      location: (startDate && endDate) ? 'Service terms section' : 'Not found'
    });
    
    complianceChecks.push({
      requirement: 'Payment Terms',
      status: contractData.billingFrequency ? 'present' : 'missing',
      severity: contractData.billingFrequency ? 'low' : 'medium',
      description: 'Billing frequency and payment schedule',
      location: contractData.billingFrequency ? 'Payment terms section' : 'Not found'
    });
    
    // 7. SIGNATURE PRESENCE CHECK (NEW)
    const hasSignatureKeywords = /\b(sign|signature|signed|executed|authorized|approve|approval)\b/i.test(extractedText);
    const hasSignatureDate = /\b(signature\s*date|signed\s*on|executed\s*on|date\s*of\s*signature)\b/i.test(extractedText);
    const hasSignatureSection = extractedText.toLowerCase().includes('signature') || extractedText.toLowerCase().includes('authorized');
    
    let signatureStatus: 'present' | 'missing' | 'partial' = 'missing';
    let signatureDescription = 'No signature indicators found in document';
    
    if (hasSignatureKeywords && hasSignatureDate && hasSignatureSection) {
      signatureStatus = 'present';
      signatureDescription = 'Signature section with date and authorization found';
    } else if (hasSignatureKeywords || hasSignatureSection) {
      signatureStatus = 'partial';
      signatureDescription = 'Partial signature information found - may need verification';
    }
    
    complianceChecks.push({
      requirement: 'Signature Presence',
      status: signatureStatus,
      severity: signatureStatus === 'present' ? 'low' : signatureStatus === 'partial' ? 'medium' : 'critical',
      description: signatureDescription,
      location: hasSignatureSection ? 'Signature section detected' : 'No signature section found'
    });
    
    fieldValidation.push({
      field: 'Digital Signature',
      isValid: signatureStatus === 'present',
      severity: signatureStatus === 'present' ? 'low' : signatureStatus === 'partial' ? 'medium' : 'critical',
      message: signatureStatus === 'present' 
        ? 'Signature section detected with proper authorization indicators'
        : signatureStatus === 'partial'
        ? 'Partial signature information found - manual verification recommended'
        : 'No signature or authorization section detected - contract may be unsigned',
      value: signatureStatus,
      suggestions: signatureStatus === 'present' ? [] : [
        'Verify document is fully executed',
        'Check for digital signature certificates',
        'Confirm authorization from both parties',
        'Review signature page completeness'
      ]
    });
    
    // Calculate overall score
    const totalChecks = fieldValidation.length;
    const passedChecks = fieldValidation.filter(v => v.isValid).length;
    const overallScore = Math.round((passedChecks / totalChecks) * 100);
    
    // Count critical issues
    const criticalIssues = fieldValidation.filter(v => !v.isValid && v.severity === 'critical').length +
                          complianceChecks.filter(c => c.status === 'missing' && c.severity === 'critical').length;
    
    // Generate recommendations
    if (criticalIssues > 0) {
      recommendations.push('Address critical validation failures before proceeding with contract processing');
    }
    if (overallScore < 80) {
      recommendations.push('Review and correct validation issues to improve data quality');
    }
    if (signatureStatus !== 'present') {
      recommendations.push('Verify contract execution status and obtain required signatures');
    }
    
    const highSeverityIssues = fieldValidation.filter(v => !v.isValid && v.severity === 'high').length;
    if (highSeverityIssues > 0) {
      recommendations.push('Resolve high-priority validation issues to ensure compliance');
    }
    
    return {
      fieldValidation,
      complianceChecks,
      overallScore,
      criticalIssues,
      recommendations
    };
  };

  const validationResults = performRealValidation();

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(extractionData, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pdf-extraction-${extractionData.extractionMetadata?.extractionId || 'data'}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const tabs = [
    { id: 'overview', name: 'Overview', icon: Eye },
    { id: 'raw', name: 'Raw Data', icon: Code },
    { id: 'validation', name: 'Validation', icon: CheckCircle }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <FileText className="h-6 w-6 text-blue-600" />
            <h3 className="text-lg font-semibold">PDF Extraction Results</h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={downloadJSON}
              className="flex items-center space-x-2 px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
            >
              <Download className="h-4 w-4" />
              <span>Download JSON</span>
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="border-b">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Extraction Metadata</h4>
                  <div className="space-y-1 text-sm">
                    <div><strong>ID:</strong> {extractionData.extractionMetadata?.extractionId}</div>
                    <div><strong>Confidence:</strong> {extractionData.extractionMetadata?.confidence}%</div>
                    <div><strong>Processing Time:</strong> {extractionData.extractionMetadata?.processingTime}</div>
                    <div><strong>Method:</strong> {extractionData.extractionMetadata?.extractionMethod}</div>
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Document Info</h4>
                  <div className="space-y-1 text-sm">
                    <div><strong>File:</strong> {extractionData.extractionMetadata?.fileName}</div>
                    <div><strong>Size:</strong> {extractionData.extractionMetadata?.fileSize}</div>
                    <div><strong>Pages:</strong> {extractionData.extractionMetadata?.pageCount}</div>
                    <div><strong>Type:</strong> {extractionData.extractionMetadata?.documentType}</div>
                  </div>
                </div>
              </div>

              {/* Order Header Section */}
              {extractionData.extractedOrderForm?.orderHeader && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">Order Header</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><strong>Date:</strong> {extractionData.extractedOrderForm.orderHeader.date}</div>
                    <div><strong>Quote ID:</strong> {extractionData.extractedOrderForm.orderHeader.quoteID}</div>
                    <div><strong>Pricing Valid Until:</strong> {extractionData.extractedOrderForm.orderHeader.pricingValidUntil}</div>
                    <div><strong>Customer:</strong> {extractionData.extractedOrderForm.orderHeader.customer}</div>
                    <div><strong>Primary Domain:</strong> {extractionData.extractedOrderForm.orderHeader.primaryDomain}</div>
                    <div><strong>Off-Domain Email:</strong> {extractionData.extractedOrderForm.orderHeader.offDomainEmail}</div>
                    <div><strong>Sales Rep:</strong> {extractionData.extractedOrderForm.orderHeader.salesRep}</div>
                  </div>
                  
                  {extractionData.extractedOrderForm.orderHeader.customerDetails && (
                    <div className="mt-3">
                      <strong className="text-sm">Customer Details:</strong>
                      <p className="text-sm text-gray-600 mt-1">{extractionData.extractedOrderForm.orderHeader.customerDetails}</p>
                    </div>
                  )}
                  
                  {extractionData.extractedOrderForm.orderHeader.customerBillingDetails && (
                    <div className="mt-3">
                      <strong className="text-sm">Billing Details:</strong>
                      <p className="text-sm text-gray-600 mt-1">{extractionData.extractedOrderForm.orderHeader.customerBillingDetails}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Order Line Items Section */}
              {extractionData.extractedOrderForm?.orderLineItems && extractionData.extractedOrderForm.orderLineItems.length > 0 && (
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">Order Line Items ({extractionData.extractedOrderForm.orderLineItems.length})</h4>
                  <div className="space-y-4">
                    {extractionData.extractedOrderForm.orderLineItems.map((item: OrderLineItem, index: number) => (
                      <div key={index} className="bg-white p-4 rounded border">
                        <h5 className="font-medium text-gray-800 mb-2">Item {index + 1}: {item.serviceName}</h5>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                          <div><strong>Operation Type:</strong> {item.operationType}</div>
                          <div><strong>Billing:</strong> {item.billingFrequency}</div>
                          <div><strong>Order Term:</strong> {item.orderTerm}</div>
                          <div><strong>Start Date:</strong> {item.serviceStartDate}</div>
                          <div><strong>End Date:</strong> {item.serviceEndDate}</div>
                          <div><strong>Quantity:</strong> {item.quantity.toLocaleString()}</div>
                          <div><strong>Unit Cost:</strong> ₹{item.unitCost.toLocaleString()}</div>
                          <div><strong>Discount:</strong> {item.discount}</div>
                          <div><strong>Total Cost:</strong> ₹{item.totalCost.toLocaleString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Summary Section */}
              {extractionData.extractedOrderForm?.summary && (
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">Summary</h4>
                  <div className="text-lg font-semibold text-gray-900">
                    <strong>Total (INR):</strong> ₹{extractionData.extractedOrderForm.summary.totalINR.toLocaleString()}
                  </div>
                </div>
              )}

              {/* Legacy Contract Data (if available) */}
              {extractionData.extractedOrderForm?.legacyData && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">Legacy Contract Data (Compatibility)</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><strong>Contract Number:</strong> {extractionData.extractedOrderForm.legacyData.contractNumber}</div>
                    <div><strong>Customer:</strong> {extractionData.extractedOrderForm.legacyData.customerName}</div>
                    <div><strong>Product:</strong> {extractionData.extractedOrderForm.legacyData.product}</div>
                    <div><strong>Value:</strong> {extractionData.extractedOrderForm.legacyData.contractValue}</div>
                    <div><strong>Currency:</strong> {extractionData.extractedOrderForm.legacyData.currency}</div>
                    <div><strong>Start Date:</strong> {extractionData.extractedOrderForm.legacyData.startDate}</div>
                    <div><strong>End Date:</strong> {extractionData.extractedOrderForm.legacyData.endDate}</div>
                    <div><strong>Billing:</strong> {extractionData.extractedOrderForm.legacyData.billingFrequency}</div>
                  </div>
                </div>
              )}

              {/* Legacy Extracted Fields (if available) */}
              {extractionData.extractedFields && (
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Detailed Fields</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <h5 className="font-medium mb-2">Service Provider</h5>
                      <div className="text-sm space-y-1">
                        <div>{extractionData.extractedFields.parties?.serviceProvider?.name}</div>
                        <div>{extractionData.extractedFields.parties?.serviceProvider?.address}</div>
                        <div>{extractionData.extractedFields.parties?.serviceProvider?.email}</div>
                      </div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <h5 className="font-medium mb-2">Customer</h5>
                      <div className="text-sm space-y-1">
                        <div>{extractionData.extractedFields.parties?.customer?.name}</div>
                        <div>{extractionData.extractedFields.parties?.customer?.address}</div>
                        <div>{extractionData.extractedFields.parties?.customer?.email}</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'raw' && (
            <div className="space-y-4">
              <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <pre>{JSON.stringify(extractionData, null, 2)}</pre>
              </div>
            </div>
          )}

          {activeTab === 'validation' && (
            <div className="space-y-6">
              {/* Validation Summary */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-blue-900">Validation Summary</h4>
                  <div className="flex items-center space-x-4">
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${validationResults.overallScore >= 80 ? 'text-green-600' : validationResults.overallScore >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                        {validationResults.overallScore}%
                      </div>
                      <div className="text-xs text-gray-600">Overall Score</div>
                    </div>
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${validationResults.criticalIssues === 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {validationResults.criticalIssues}
                      </div>
                      <div className="text-xs text-gray-600">Critical Issues</div>
                    </div>
                  </div>
                </div>
                
                {validationResults.recommendations.length > 0 && (
                  <div className="bg-white p-4 rounded border border-blue-200">
                    <h5 className="font-medium text-blue-900 mb-2">Recommendations:</h5>
                    <ul className="text-sm text-blue-800 space-y-1">
                      {validationResults.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-blue-600 mr-2">•</span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Field Validation Results */}
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                  Field Validation Results
                </h4>
                <div className="space-y-4">
                  {validationResults.fieldValidation.map((validation, index) => (
                    <div key={index} className={`p-4 rounded-lg border-l-4 ${
                      validation.isValid 
                        ? 'bg-green-50 border-green-400' 
                        : validation.severity === 'critical' 
                        ? 'bg-red-50 border-red-400'
                        : validation.severity === 'high'
                        ? 'bg-orange-50 border-orange-400'
                        : 'bg-yellow-50 border-yellow-400'
                    }`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            {validation.isValid ? (
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            ) : (
                              <XCircle className="h-4 w-4 text-red-600" />
                            )}
                            <span className="font-medium text-gray-900">{validation.field}</span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              validation.severity === 'critical' ? 'bg-red-100 text-red-800' :
                              validation.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                              validation.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }`}>
                              {validation.severity}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">{validation.message}</p>
                          {validation.value && (
                            <div className="text-xs text-gray-600 mb-2">
                              <strong>Current Value:</strong> <code className="bg-gray-100 px-1 rounded">{validation.value}</code>
                            </div>
                          )}
                          {validation.expectedFormat && (
                            <div className="text-xs text-gray-600 mb-2">
                              <strong>Expected Format:</strong> <code className="bg-gray-100 px-1 rounded">{validation.expectedFormat}</code>
                            </div>
                          )}
                          {validation.suggestions && validation.suggestions.length > 0 && (
                            <div className="text-xs text-gray-600">
                              <strong>Suggestions:</strong>
                              <ul className="mt-1 ml-4 space-y-1">
                                {validation.suggestions.map((suggestion, idx) => (
                                  <li key={idx} className="list-disc">{suggestion}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Compliance Checks */}
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                  <PenTool className="h-5 w-5 mr-2 text-blue-600" />
                  Compliance Requirements
                </h4>
                <div className="space-y-3">
                  {validationResults.complianceChecks.map((check, index) => (
                    <div key={index} className={`p-4 rounded-lg border ${
                      check.status === 'present' 
                        ? 'bg-green-50 border-green-200' 
                        : check.status === 'partial'
                        ? 'bg-yellow-50 border-yellow-200'
                        : 'bg-red-50 border-red-200'
                    }`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {check.status === 'present' ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : check.status === 'partial' ? (
                            <AlertTriangle className="h-4 w-4 text-yellow-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                          <span className="font-medium text-gray-900">{check.requirement}</span>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          check.status === 'present' ? 'bg-green-100 text-green-800' :
                          check.status === 'partial' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {check.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 mb-1">{check.description}</p>
                      {check.location && (
                        <p className="text-xs text-gray-600">
                          <strong>Location:</strong> {check.location}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Validation Statistics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-green-50 p-4 rounded-lg text-center border border-green-200">
                  <div className="text-2xl font-bold text-green-600">
                    {validationResults.fieldValidation.filter(v => v.isValid).length}
                  </div>
                  <div className="text-sm text-green-800">Passed</div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center border border-red-200">
                  <div className="text-2xl font-bold text-red-600">
                    {validationResults.fieldValidation.filter(v => !v.isValid && v.severity === 'critical').length}
                  </div>
                  <div className="text-sm text-red-800">Critical</div>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg text-center border border-orange-200">
                  <div className="text-2xl font-bold text-orange-600">
                    {validationResults.fieldValidation.filter(v => !v.isValid && v.severity === 'high').length}
                  </div>
                  <div className="text-sm text-orange-800">High Priority</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center border border-yellow-200">
                  <div className="text-2xl font-bold text-yellow-600">
                    {validationResults.fieldValidation.filter(v => !v.isValid && v.severity === 'medium').length}
                  </div>
                  <div className="text-sm text-yellow-800">Medium Priority</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};