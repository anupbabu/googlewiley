import React, { useState, useEffect } from 'react';
import { 
  MessageSquare, Plus, Edit3, Copy, Trash2, Save, X, Download, Upload, 
  Search, Filter, Eye, EyeOff, AlertCircle, CheckCircle, FileText,
  Brain, Zap, Settings, Code
} from 'lucide-react';
import { PromptTemplate, PromptLibraryService } from '../services/promptLibrary';

export const PromptLibraryPanel: React.FC = () => {
  const [prompts, setPrompts] = useState<PromptTemplate[]>([]);
  const [filteredPrompts, setFilteredPrompts] = useState<PromptTemplate[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSection, setSelectedSection] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [editingPrompt, setEditingPrompt] = useState<PromptTemplate | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [showPreview, setShowPreview] = useState<string | null>(null);
  const [importData, setImportData] = useState('');
  const [showImport, setShowImport] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'contract-to-provisioning', label: 'Contract to Provisioning' },
    { value: 'contract-to-invoice', label: 'Contract to Invoice' },
    { value: 'contract-to-booking', label: 'Contract to Booking' },
    { value: 'approval-vs-policy', label: 'Approval vs Policy' },
    { value: 'approval-vs-contract', label: 'Approval vs Contract' },
    { value: 'general', label: 'General' },
    { value: 'validation', label: 'Validation' }
  ];

  const sections = [
    { value: 'all', label: 'All Sections' },
    { value: 'order-processed', label: 'Order Has Been Processed?' },
    { value: 'booking-terms', label: 'Terms of Booking vs Order Form Amendment Matching?' },
    { value: 'billing-systems', label: 'Mithra/Google Admin/Billy Systems Reflect Contract?' },
    { value: 'rules-extraction', label: 'Rules Extraction' },
    { value: 'general', label: 'General' },
    { value: 'approval-workflow', label: 'Approval Workflow' },
    { value: 'contract-alignment', label: 'Contract Alignment' }
  ];

  useEffect(() => {
    loadPrompts();
  }, []);

  useEffect(() => {
    filterPrompts();
  }, [prompts, selectedCategory, selectedSection, searchTerm]);

  const loadPrompts = () => {
    const allPrompts = PromptLibraryService.getAllPrompts();
    setPrompts(allPrompts);
  };

  const filterPrompts = () => {
    let filtered = prompts;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    if (selectedSection !== 'all') {
      filtered = filtered.filter(p => p.section === selectedSection);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term) ||
        p.prompt.toLowerCase().includes(term)
      );
    }

    setFilteredPrompts(filtered);
  };

  const handleCreateNew = () => {
    const newPrompt: PromptTemplate = {
      id: `prompt_${Date.now()}`,
      name: 'New Prompt',
      category: 'general',
      section: 'general',
      description: '',
      prompt: '',
      variables: [],
      tags: [],
      lastModified: new Date().toISOString(),
      version: 1,
      isActive: false
    };
    setEditingPrompt(newPrompt);
    setIsCreating(true);
  };

  const handleEdit = (prompt: PromptTemplate) => {
    setEditingPrompt({ ...prompt });
    setIsCreating(false);
  };

  const handleSave = () => {
    if (!editingPrompt) return;

    const errors = PromptLibraryService.validatePrompt(editingPrompt);
    if (errors.length > 0) {
      setMessage({ type: 'error', text: errors.join(', ') });
      return;
    }

    PromptLibraryService.savePrompt(editingPrompt);
    loadPrompts();
    setEditingPrompt(null);
    setIsCreating(false);
    setMessage({ type: 'success', text: 'Prompt saved successfully' });
  };

  const handleCancel = () => {
    setEditingPrompt(null);
    setIsCreating(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this prompt?')) {
      PromptLibraryService.deletePrompt(id);
      loadPrompts();
      setMessage({ type: 'success', text: 'Prompt deleted successfully' });
    }
  };

  const handleDuplicate = (id: string) => {
    const duplicated = PromptLibraryService.duplicatePrompt(id);
    if (duplicated) {
      loadPrompts();
      setMessage({ type: 'success', text: 'Prompt duplicated successfully' });
    }
  };

  const handleSetActive = (id: string, section: string) => {
    PromptLibraryService.setActivePrompt(id, section);
    loadPrompts();
    setMessage({ type: 'success', text: 'Active prompt updated' });
  };

  const handleExport = () => {
    const exportData = PromptLibraryService.exportPrompts();
    const blob = new Blob([exportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `prompt-library-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const result = PromptLibraryService.importPrompts(importData);
    setMessage({ type: result.success ? 'success' : 'error', text: result.message });
    
    if (result.success) {
      loadPrompts();
      setShowImport(false);
      setImportData('');
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'contract-to-provisioning': return <Brain className="h-4 w-4" />;
      case 'contract-to-invoice': return <CheckCircle className="h-4 w-4" />;
      case 'contract-to-booking': return <AlertCircle className="h-4 w-4" />;
      case 'validation': return <CheckCircle className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'contract-to-provisioning': return 'bg-purple-100 text-purple-800';
      case 'contract-to-invoice': return 'bg-green-100 text-green-800';
      case 'contract-to-booking': return 'bg-orange-100 text-orange-800';
      case 'validation': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <MessageSquare className="h-6 w-6 text-purple-600" />
          <h2 className="text-xl font-semibold text-gray-900">Prompt Library</h2>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowImport(true)}
            className="flex items-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </button>
          <button
            onClick={handleExport}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
          <button
            onClick={handleCreateNew}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
          >
            <Plus className="h-4 w-4" />
            <span>New Prompt</span>
          </button>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`mb-4 p-3 rounded-lg border ${
          message.type === 'success' 
            ? 'bg-green-50 border-green-200 text-green-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center space-x-2">
            {message.type === 'success' ? 
              <CheckCircle className="h-4 w-4" /> : 
              <AlertCircle className="h-4 w-4" />
            }
            <span>{message.text}</span>
            <button
              onClick={() => setMessage(null)}
              className="ml-auto text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search prompts..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Category</label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            {categories.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Section</label>
          <select
            value={selectedSection}
            onChange={(e) => setSelectedSection(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            {sections.map(sec => (
              <option key={sec.value} value={sec.value}>{sec.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Prompt List */}
      <div className="space-y-4">
        {filteredPrompts.map((prompt) => (
          <div key={prompt.id} className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{prompt.name}</h3>
                  <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(prompt.category)}`}>
                    {getCategoryIcon(prompt.category)}
                    <span>{prompt.category}</span>
                  </span>
                  {prompt.isActive && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <Zap className="h-3 w-3 mr-1" />
                      Active
                    </span>
                  )}
                </div>
                
                <p className="text-gray-600 mb-3">{prompt.description}</p>
                
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <span>Section: {sections.find(s => s.value === prompt.section)?.label || prompt.section}</span>
                  <span>Version: {prompt.version}</span>
                  <span>Modified: {new Date(prompt.lastModified).toLocaleDateString()}</span>
                  <span>Variables: {prompt.variables.length}</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowPreview(showPreview === prompt.id ? null : prompt.id)}
                  className="p-2 text-gray-400 hover:text-gray-600"
                  title="Preview"
                >
                  {showPreview === prompt.id ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
                
                {!prompt.isActive && (
                  <button
                    onClick={() => handleSetActive(prompt.id, prompt.section)}
                    className="p-2 text-green-400 hover:text-green-600"
                    title="Set as active"
                  >
                    <Zap className="h-4 w-4" />
                  </button>
                )}
                
                <button
                  onClick={() => handleEdit(prompt)}
                  className="p-2 text-blue-400 hover:text-blue-600"
                  title="Edit"
                >
                  <Edit3 className="h-4 w-4" />
                </button>
                
                <button
                  onClick={() => handleDuplicate(prompt.id)}
                  className="p-2 text-purple-400 hover:text-purple-600"
                  title="Duplicate"
                >
                  <Copy className="h-4 w-4" />
                </button>
                
                <button
                  onClick={() => handleDelete(prompt.id)}
                  className="p-2 text-red-400 hover:text-red-600"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            {/* Preview */}
            {showPreview === prompt.id && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg border">
                <h4 className="font-medium text-gray-900 mb-2">Prompt Content:</h4>
                <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono bg-white p-3 rounded border max-h-64 overflow-y-auto">
                  {prompt.prompt}
                </pre>
                {prompt.variables.length > 0 && (
                  <div className="mt-3">
                    <h5 className="font-medium text-gray-900 mb-1">Variables:</h5>
                    <div className="flex flex-wrap gap-2">
                      {prompt.variables.map(variable => (
                        <span key={variable} className="inline-flex items-center px-2 py-1 rounded bg-blue-100 text-blue-800 text-xs font-mono">
                          {`{${variable}}`}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {prompt.tags && prompt.tags.length > 0 && (
                  <div className="mt-3">
                    <h5 className="font-medium text-gray-900 mb-1">Tags:</h5>
                    <div className="flex flex-wrap gap-2">
                      {prompt.tags.map(tag => (
                        <span key={tag} className="inline-flex items-center px-2 py-1 rounded bg-purple-100 text-purple-800 text-xs">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        
        {filteredPrompts.length === 0 && (
          <div className="text-center py-12">
            <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No prompts found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || selectedCategory !== 'all' || selectedSection !== 'all'
                ? 'Try adjusting your filters or search terms.'
                : 'Create your first prompt to get started.'}
            </p>
            <button
              onClick={handleCreateNew}
              className="inline-flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
            >
              <Plus className="h-4 w-4" />
              <span>Create Prompt</span>
            </button>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingPrompt && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-lg font-semibold">
                {isCreating ? 'Create New Prompt' : 'Edit Prompt'}
              </h3>
              <button onClick={handleCancel} className="text-gray-400 hover:text-gray-600">
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                    <input
                      type="text"
                      value={editingPrompt.name}
                      onChange={(e) => setEditingPrompt({...editingPrompt, name: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                    <select
                      value={editingPrompt.category}
                      onChange={(e) => setEditingPrompt({...editingPrompt, category: e.target.value as any})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      {categories.slice(1).map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Section</label>
                    <select
                      value={editingPrompt.section}
                      onChange={(e) => setEditingPrompt({...editingPrompt, section: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      {sections.slice(1).map(sec => (
                        <option key={sec.value} value={sec.value}>{sec.label}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <div className="flex items-center space-x-2">
                        <span>Active</span>
                        <input
                          type="checkbox"
                          checked={editingPrompt.isActive}
                          onChange={(e) => setEditingPrompt({...editingPrompt, isActive: e.target.checked})}
                          className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                        />
                      </div>
                    </label>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    value={editingPrompt.description}
                    onChange={(e) => setEditingPrompt({...editingPrompt, description: e.target.value})}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Variables (comma-separated)</label>
                  <input
                    type="text"
                    value={editingPrompt.variables.join(', ')}
                    onChange={(e) => setEditingPrompt({
                      ...editingPrompt, 
                      variables: e.target.value.split(',').map(v => v.trim()).filter(v => v)
                    })}
                    placeholder="source1Data, source2Data, auditType"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tags (comma-separated)</label>
                  <input
                    type="text"
                    value={editingPrompt.tags?.join(', ') || ''}
                    onChange={(e) => setEditingPrompt({
                      ...editingPrompt, 
                      tags: e.target.value.split(',').map(v => v.trim()).filter(v => v)
                    })}
                    placeholder="validation, comparison, analysis"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Prompt Content</label>
                  <textarea
                    value={editingPrompt.prompt}
                    onChange={(e) => setEditingPrompt({...editingPrompt, prompt: e.target.value})}
                    rows={20}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 font-mono text-sm"
                    placeholder="Enter your prompt content here..."
                  />
                  <div className="text-xs text-gray-500 mt-1">
                    {editingPrompt.prompt.length} / 10,000 characters
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-3 p-6 border-t bg-gray-50">
              <button
                onClick={handleCancel}
                className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
              >
                <Save className="h-4 w-4" />
                <span>Save Prompt</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImport && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-lg font-semibold">Import Prompts</h3>
              <button onClick={() => setShowImport(false)} className="text-gray-400 hover:text-gray-600">
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">JSON Data</label>
                <textarea
                  value={importData}
                  onChange={(e) => setImportData(e.target.value)}
                  rows={10}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 font-mono text-sm"
                  placeholder="Paste your exported prompt library JSON here..."
                />
              </div>
              
              <div className="flex items-center justify-end space-x-3">
                <button
                  onClick={() => setShowImport(false)}
                  className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleImport}
                  disabled={!importData.trim()}
                  className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-gray-400"
                >
                  <Upload className="h-4 w-4" />
                  <span>Import</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};