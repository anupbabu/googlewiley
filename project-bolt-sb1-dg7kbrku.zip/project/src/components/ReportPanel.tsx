import React from 'react';
import { Download, FileText, Database, CheckCircle, XCircle, AlertTriangle, FileDown } from 'lucide-react';
import { AuditReport } from '../types/audit';
import { ReportGenerator } from '../services/reportGenerator';

interface ReportPanelProps {
  report: AuditReport | null;
}

export const ReportPanel: React.FC<ReportPanelProps> = ({ report }) => {
  const handleDownload = (format: 'pdf' | 'json') => {
    if (report) {
      ReportGenerator.downloadReport(report, format);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass': return <CheckCircle className="h-8 w-8 text-green-500" />;
      case 'fail': return <XCircle className="h-8 w-8 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-8 w-8 text-yellow-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass': return 'bg-green-50 border-green-200';
      case 'fail': return 'bg-red-50 border-red-200';
      case 'warning': return 'bg-yellow-50 border-yellow-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-900">Audit Report</h2>
      </div>

      {!report && (
        <div className="bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 p-8 text-center">
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Report Generated</h3>
          <p className="text-gray-600">
            Complete data extraction and comparison to generate an audit report.
          </p>
        </div>
      )}

      {report && (
        <div className={`rounded-lg border-2 p-6 ${getStatusColor(report.overallStatus)}`}>
          <div className="flex items-center space-x-4 mb-6">
            {getStatusIcon(report.overallStatus)}
            <div>
              <h3 className="text-xl font-bold text-gray-900">Audit Complete</h3>
              <p className="text-gray-600">
                Report generated on {new Date(report.timestamp).toLocaleString()}
              </p>
              <div className="mt-2 space-y-1">
                <p className="text-sm text-gray-600">
                  <strong>Audit ID:</strong> <code className="bg-gray-100 px-1 rounded text-xs">{report.auditId}</code>
                </p>
                {report.aiAgentId && (
                  <p className="text-sm text-gray-600">
                    <strong>AI Agent ID:</strong> <code className="bg-gray-100 px-1 rounded text-xs">{report.aiAgentId}</code>
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-gray-900">{report.summary.totalChecks}</div>
              <div className="text-sm text-gray-600">Total Checks</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{report.summary.passed}</div>
              <div className="text-sm text-gray-600">Passed</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-red-600">{report.summary.failed}</div>
              <div className="text-sm text-gray-600">Failed</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">{report.summary.warnings}</div>
              <div className="text-sm text-gray-600">Warnings</div>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={() => handleDownload('pdf')}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <FileDown className="h-4 w-4" />
              <span>Download Report as PDF</span>
            </button>
            <button
              onClick={() => handleDownload('json')}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
            >
              <Database className="h-4 w-4" />
              <span>Download JSON</span>
            </button>
          </div>

          <div className="mt-6 p-4 bg-white rounded-lg">
            <h4 className="font-semibold text-gray-900 mb-2">Quick Summary</h4>
            <p className="text-sm text-gray-700">
              {report.overallStatus === 'pass' && 
                'All data sources are consistent. No discrepancies found.'}
              {report.overallStatus === 'warning' && 
                'Minor discrepancies detected. Review recommended but not critical.'}
              {report.overallStatus === 'fail' && 
                'Critical discrepancies found. Immediate review and correction required.'}
            </p>
            {report.aiAgentId && (
              <p className="text-xs text-gray-500 mt-2">
                AI analysis performed by Agent {report.aiAgentId}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};