import React, { useState } from 'react';
import { TestTube, Download, RefreshCw, Database, Building2 } from 'lucide-react';
import { TestDataGenerator } from '../data/testData';
import { GoogleWorkspaceTestData } from '../data/googleWorkspaceTestData';
import { DataSource } from '../types/audit';

interface TestDataPanelProps {
  onLoadTestData: (dataSources: DataSource[], contractNumber: string) => void;
  onLoadSampleText: (text: string) => void;
}

export const TestDataPanel: React.FC<TestDataPanelProps> = ({
  onLoadTestData,
  onLoadSampleText
}) => {
  const [selectedScenario, setSelectedScenario] = useState<'perfect' | 'minor' | 'major' | 'multi'>('perfect');
  const [selectedDataSet, setSelectedDataSet] = useState<'generic' | 'google-workspace'>('google-workspace');
  const [isLoading, setIsLoading] = useState(false);

  const scenarios = [
    {
      id: 'perfect' as const,
      name: 'Perfect Match',
      description: 'All data sources match perfectly across systems',
      color: 'bg-green-50 border-green-200 text-green-800'
    },
    {
      id: 'minor' as const,
      name: 'Minor Discrepancies',
      description: 'Small formatting differences, high confidence matches',
      color: 'bg-yellow-50 border-yellow-200 text-yellow-800'
    },
    {
      id: 'major' as const,
      name: 'Major Discrepancies',
      description: 'Significant differences requiring investigation',
      color: 'bg-red-50 border-red-200 text-red-800'
    },
    {
      id: 'multi' as const,
      name: 'Multi-Product Bundle',
      description: 'Complex scenario with multiple product lines',
      color: 'bg-blue-50 border-blue-200 text-blue-800'
    }
  ];

  const dataSets = [
    {
      id: 'google-workspace' as const,
      name: 'Google Workspace',
      description: 'Real Google Workspace Enterprise Plus contract data',
      icon: <Building2 className="h-4 w-4" />,
      color: 'bg-blue-50 border-blue-200 text-blue-800'
    },
    {
      id: 'generic' as const,
      name: 'Generic Enterprise',
      description: 'Generic enterprise software contract scenarios',
      icon: <TestTube className="h-4 w-4" />,
      color: 'bg-gray-50 border-gray-200 text-gray-800'
    }
  ];

  const handleLoadTestData = async () => {
    setIsLoading(true);
    
    // Simulate loading delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    let testDataSources: DataSource[];
    let contractNumber: string;

    if (selectedDataSet === 'google-workspace') {
      testDataSources = GoogleWorkspaceTestData.getGoogleWorkspaceTestDataSources(selectedScenario);
      contractNumber = 'Q-259105';
    } else {
      testDataSources = TestDataGenerator.getTestDataSources('all-success');
      const testData = {
        perfect: TestDataGenerator.getPerfectMatchData(),
        minor: TestDataGenerator.getMinorDiscrepancyData(),
        major: TestDataGenerator.getMajorDiscrepancyData(),
        multi: TestDataGenerator.getMultiCurrencyData() // Use currency as multi scenario
      }[selectedScenario];

      // Update test data sources with selected scenario data
      testDataSources[0].data = testData.pdfData;
      testDataSources[1].data = testData.sapData;
      testDataSources[2].data = testData.oreoData;
      testDataSources[3].data = testData.mithraData;

      contractNumber = testData.pdfData.contractNumber || TestDataGenerator.generateContractNumber();
    }
    
    onLoadTestData(testDataSources, contractNumber);
    setIsLoading(false);
  };

  const handleLoadSampleText = () => {
    let sampleText: string;
    
    if (selectedDataSet === 'google-workspace') {
      // Load JSON format for Google Workspace
      sampleText = GoogleWorkspaceTestData.getSampleJSONData(selectedScenario);
    } else {
      sampleText = TestDataGenerator.getSampleContractText(selectedScenario);
    }
    
    onLoadSampleText(sampleText);
  };

  const handleDownloadTestData = () => {
    let testData: any;
    
    if (selectedDataSet === 'google-workspace') {
      testData = {
        perfect: GoogleWorkspaceTestData.getPerfectMatchData(),
        minor: GoogleWorkspaceTestData.getMinorDiscrepancyData(),
        major: GoogleWorkspaceTestData.getMajorDiscrepancyData(),
        multi: GoogleWorkspaceTestData.getMultiProductData()
      }[selectedScenario];
    } else {
      testData = {
        perfect: TestDataGenerator.getPerfectMatchData(),
        minor: TestDataGenerator.getMinorDiscrepancyData(),
        major: TestDataGenerator.getMajorDiscrepancyData(),
        multi: TestDataGenerator.getMultiCurrencyData()
      }[selectedScenario];
    }

    const blob = new Blob([JSON.stringify(testData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `test-data-${selectedDataSet}-${selectedScenario}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-lg border-2 border-blue-200 p-6 mb-6">
      <div className="flex items-center space-x-3 mb-6">
        <TestTube className="h-6 w-6 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900">Test Data Generator</h3>
      </div>

      <div className="space-y-6">
        {/* Data Set Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Select Data Set
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {dataSets.map((dataSet) => (
              <button
                key={dataSet.id}
                onClick={() => setSelectedDataSet(dataSet.id)}
                className={`p-4 rounded-lg border-2 text-left transition-all ${
                  selectedDataSet === dataSet.id
                    ? dataSet.color + ' border-current'
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center space-x-2 mb-2">
                  {dataSet.icon}
                  <div className="font-medium">{dataSet.name}</div>
                </div>
                <div className="text-sm opacity-80">{dataSet.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Scenario Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Select Test Scenario
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {scenarios.map((scenario) => (
              <button
                key={scenario.id}
                onClick={() => setSelectedScenario(scenario.id)}
                className={`p-4 rounded-lg border-2 text-left transition-all ${
                  selectedScenario === scenario.id
                    ? scenario.color + ' border-current'
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <div className="font-medium">{scenario.name}</div>
                <div className="text-sm mt-1 opacity-80">{scenario.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleLoadTestData}
            disabled={isLoading}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Database className="h-4 w-4" />
            )}
            <span>{isLoading ? 'Loading...' : 'Load Test Data'}</span>
          </button>

          <button
            onClick={handleLoadSampleText}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            <TestTube className="h-4 w-4" />
            <span>Load Sample JSON Data</span>
          </button>

          <button
            onClick={handleDownloadTestData}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            <Download className="h-4 w-4" />
            <span>Download JSON</span>
          </button>
        </div>

        {/* Current Selection Summary */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-medium text-gray-900 mb-2">
            Current Selection: {dataSets.find(d => d.id === selectedDataSet)?.name} - {scenarios.find(s => s.id === selectedScenario)?.name}
          </h4>
          <p className="text-sm text-gray-600 mb-3">
            {scenarios.find(s => s.id === selectedScenario)?.description}
          </p>
          
          {selectedDataSet === 'google-workspace' && (
            <div className="text-xs text-gray-500 space-y-1">
              <div><strong>Customer:</strong> Virtusa Consulting Services Private Limited</div>
              <div><strong>Product:</strong> Google Workspace Enterprise Plus</div>
              <div><strong>Quote ID:</strong> Q-259105</div>
              <div><strong>Contract Value:</strong> ₹2,575,800.00 (24M) + ₹478,377.30 (36M)</div>
              <div><strong>Currency:</strong> INR</div>
            </div>
          )}
          
          {selectedDataSet === 'generic' && (
            <div className="text-xs text-gray-500">
              <strong>Sample Files:</strong> {TestDataGenerator.getSampleFileNames().slice(0, 3).join(', ')}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};