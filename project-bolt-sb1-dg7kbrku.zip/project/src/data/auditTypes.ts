import { AuditTypeConfig, AuditType } from '../types/audit';

export const AUDIT_TYPE_CONFIGS: Record<AuditType, AuditTypeConfig> = {
  'contract-to-invoice': {
    id: 'contract-to-invoice',
    name: 'Contract to Invoice',
    description: 'Reconcile contract terms with billing invoices',
    dataSources: {
      primary: 'Order Form',
      secondary: 'SAP System',
      tertiary: 'Mithra/Billy System'
    },
    keyFields: ['quoteId', 'customerName', 'product', 'quantity', 'unitCost', 'billingFrequency'],
    icon: 'Receipt',
    color: 'green'
  },
  'contract-to-booking': {
    id: 'contract-to-booking',
    name: 'Contract to Booking',
    description: 'Validate contract details against booking records',
    dataSources: {
      primary: 'Order Form',
      secondary: 'SAP System',
      tertiary: 'OREO UI'
    },
    keyFields: ['quoteId', 'customerName', 'product', 'serviceStartDate', 'quantity'],
    icon: 'Calendar',
    color: 'purple'
  },
  'contract-to-provisioning': {
    id: 'contract-to-provisioning',
    name: 'Contract to Provisioning',
    description: 'Ensure contract services match provisioned resources',
    dataSources: {
      primary: 'Order Form',
      secondary: 'SAP System',
      tertiary: 'OREO UI & Mithra/Billy System'
    },
    keyFields: ['product', 'serviceStartDate', 'serviceEndDate', 'customerName', 'quantity'],
    icon: 'Settings',
    color: 'orange'
  },
  'approval-vs-policy': {
    id: 'approval-vs-policy',
    name: 'Approval vs Policy',
    description: 'Check if approvals comply with policy requirements',
    dataSources: {
      primary: 'Approval Workflow',
      secondary: 'SAP System',
      tertiary: 'OREO UI'
    },
    keyFields: ['approvalLevel', 'contractValue', 'approver', 'policyCompliance'],
    icon: 'CheckCircle',
    color: 'teal'
  },
  'approval-vs-contract': {
    id: 'approval-vs-contract',
    name: 'Approval vs Contract',
    description: 'Verify approved terms match final contract',
    dataSources: {
      primary: 'Approval System',
      secondary: 'Order Form',
      tertiary: 'SAP System'
    },
    keyFields: ['contractValue', 'paymentTerms', 'serviceDescription', 'approvalDate'],
    icon: 'FileCheck',
    color: 'red'
  }
};

export class AuditTypeService {
  static getAuditTypeConfig(auditType: AuditType): AuditTypeConfig {
    return AUDIT_TYPE_CONFIGS[auditType];
  }

  static getAllAuditTypes(): AuditTypeConfig[] {
    return Object.values(AUDIT_TYPE_CONFIGS);
  }

  static getAuditTypesByCategory(category: 'contract' | 'approval'): AuditTypeConfig[] {
    return Object.values(AUDIT_TYPE_CONFIGS).filter(config => 
      category === 'contract' 
        ? config.id.startsWith('contract-')
        : config.id.startsWith('approval-')
    );
  }

  static getDataSourceLabels(auditType: AuditType): string[] {
    const config = this.getAuditTypeConfig(auditType);
    return [
      config.dataSources.primary,
      config.dataSources.secondary,
      config.dataSources.tertiary
    ].filter(Boolean);
  }
}