import { ContractData, ExtractedOrderForm, OrderHeader, OrderLineItem, Summary } from '../types/audit';

export class GoogleWorkspaceTestData {
  // Perfect match scenario - all systems align perfectly
  static getPerfectMatchData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        // PDF Extracted Data
        quoteId: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        orderTerm: '24M OD',
        quantity: '27,000',
        unitCost: '₹2,650.00',
        billingFrequency: 'Monthly in Advance',
        
        // Legacy compatibility
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      sapData: {
        // SAP System Data
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        quantity: '27,000',
        lineAmount: '₹2,650.00',
        duration: '24M OD',
        
        // Legacy compatibility
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      oreoData: {
        // OREO UI Data
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        quantity: '27,000',
        lineAmount: '₹2,650.00',
        duration: '24M OD',
        
        // Legacy compatibility
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      mithraData: {
        // Mithra/Billy System Data
        soldToParty: 'Virtusa Consulting Services Private Limited',
        billingParty: 'Virtusa Consulting Services Pvt Ltd - Finance',
        
        // Legacy compatibility
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        billingFrequency: 'Monthly in Advance',
        currency: 'INR'
      }
    };
  }

  // Minor discrepancies scenario - formatting differences, case variations
  static getMinorDiscrepancyData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        quoteId: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        orderTerm: '24M OD',
        quantity: '27,000',
        unitCost: '₹2,650.00',
        billingFrequency: 'Monthly in Advance',
        
        // Legacy
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      sapData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'VIRTUSA CONSULTING SERVICES PRIVATE LIMITED', // Case difference
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '31/03/2025', // Different date format
        serviceEndDate: '30/03/2027',
        quantity: '27000', // No comma separator
        lineAmount: 'INR 2,650.00', // Different currency format
        duration: '24 Months OD', // Slightly different format
        
        // Legacy
        customerName: 'VIRTUSA CONSULTING SERVICES PRIVATE LIMITED',
        contractNumber: 'Q-259105',
        contractValue: 'INR 2,575,800.00',
        startDate: '31/03/2025',
        endDate: '30/03/2027',
        currency: 'INR'
      },
      oreoData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Pvt. Ltd.', // Abbreviated format
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '03/31/2025', // US date format
        serviceEndDate: '03/30/2027',
        quantity: '27,000',
        lineAmount: '2650.00 INR', // Different currency position
        duration: '24M OD',
        
        // Legacy
        customerName: 'Virtusa Consulting Services Pvt. Ltd.',
        contractNumber: 'Q-259105',
        contractValue: '2650.00 INR',
        startDate: '03/31/2025',
        endDate: '03/30/2027',
        currency: 'INR'
      },
      mithraData: {
        soldToParty: 'Virtusa Consulting Services Pvt Ltd', // Slightly different abbreviation
        billingParty: 'Virtusa Finance Department',
        
        // Legacy
        customerName: 'Virtusa Consulting Services Pvt Ltd',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        billingFrequency: 'Monthly', // Simplified format
        currency: 'INR'
      }
    };
  }

  // Major discrepancies scenario - significant differences that should fail validation
  static getMajorDiscrepancyData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        quoteId: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        orderTerm: '24M OD',
        quantity: '27,000',
        unitCost: '₹2,650.00',
        billingFrequency: 'Monthly in Advance',
        
        // Legacy
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      sapData: {
        solutionQuoteNumber: 'SQN-259999', // WRONG QUOTE NUMBER - CRITICAL FAILURE
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Business Standard', // WRONG PRODUCT - CRITICAL FAILURE
        productId: 'GAPPS-BUS-STD-1USER-1MO', // WRONG PRODUCT ID - CRITICAL FAILURE
        operationType: 'Renewal', // WRONG OPERATION TYPE - FAILURE
        serviceStartDate: '2025-04-01', // WRONG START DATE - FAILURE
        serviceEndDate: '2026-03-31', // WRONG END DATE - CRITICAL FAILURE
        quantity: '25,000', // WRONG QUANTITY - CRITICAL FAILURE
        lineAmount: '₹1,850.00', // WRONG PRICE - CRITICAL FAILURE
        duration: '12M OD', // WRONG DURATION - CRITICAL FAILURE
        
        // Legacy
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹1,387,500.00', // WRONG TOTAL
        startDate: '2025-04-01',
        endDate: '2026-03-31',
        currency: 'INR'
      },
      oreoData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Technologies Private Limited', // WRONG COMPANY NAME - FAILURE
        product: 'Google Workspace Enterprise Standard', // WRONG PRODUCT VARIANT - FAILURE
        productId: 'GAPPS-ENT-STD-1USER-1MO', // WRONG PRODUCT ID - FAILURE
        operationType: 'Amendment', // WRONG OPERATION TYPE - FAILURE
        serviceStartDate: '2025-04-15', // WRONG START DATE - FAILURE
        serviceEndDate: '2027-03-30',
        quantity: '30,000', // WRONG QUANTITY - FAILURE
        lineAmount: '₹2,450.00', // WRONG PRICE - FAILURE
        duration: '24M OD',
        
        // Legacy
        customerName: 'Virtusa Technologies Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹2,205,000.00', // WRONG TOTAL
        startDate: '2025-04-15',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      mithraData: {
        soldToParty: 'Virtusa Corporation India', // WRONG COMPANY NAME - FAILURE
        billingParty: 'External Billing Services Ltd', // WRONG BILLING ENTITY - CRITICAL FAILURE
        
        // Legacy
        customerName: 'Virtusa Corporation India',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        billingFrequency: 'Quarterly', // WRONG BILLING FREQUENCY - CRITICAL FAILURE
        currency: 'USD' // WRONG CURRENCY - CRITICAL FAILURE
      }
    };
  }

  // Multi-product scenario - handling multiple line items
  static getMultiProductData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        quoteId: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus + Archived User',
        productId: 'GAPPS-ENT-PLUS-BUNDLE',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2030-03-30', // 5-year term covering both periods
        orderTerm: '60M OD', // Total term
        quantity: '32,000', // Combined quantity (27,000 + 5,000)
        unitCost: '₹2,560.00', // Blended rate
        billingFrequency: 'Monthly in Advance',
        
        // Legacy
        contractNumber: 'Q-259105',
        contractValue: '₹3,156,915,060.00', // Total contract value
        startDate: '2025-03-31',
        endDate: '2030-03-30',
        currency: 'INR'
      },
      sapData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus + Archived User',
        productId: 'GAPPS-ENT-PLUS-BUNDLE',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2030-03-30',
        quantity: '32,000',
        lineAmount: '₹2,560.00',
        duration: '60M OD',
        
        // Legacy
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹3,156,915,060.00',
        startDate: '2025-03-31',
        endDate: '2030-03-30',
        currency: 'INR'
      },
      oreoData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus + Archived User',
        productId: 'GAPPS-ENT-PLUS-BUNDLE',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2030-03-30',
        quantity: '32,000',
        lineAmount: '₹2,560.00',
        duration: '60M OD',
        
        // Legacy
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹3,156,915,060.00',
        startDate: '2025-03-31',
        endDate: '2030-03-30',
        currency: 'INR'
      },
      mithraData: {
        soldToParty: 'Virtusa Consulting Services Private Limited',
        billingParty: 'Virtusa Consulting Services Pvt Ltd - Accounts Payable',
        
        // Legacy
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹3,156,915,060.00',
        billingFrequency: 'Monthly in Advance',
        currency: 'INR'
      }
    };
  }

  // Generate sample contract text for PDF extraction
  static getSampleContractText(scenario: 'perfect' | 'minor' | 'major' | 'multi' = 'perfect'): string {
    // Generate structured order form text that matches the new extraction format
    const orderData = {
      perfect: this.getPerfectMatchData().pdfData,
      minor: this.getMinorDiscrepancyData().pdfData,
      major: this.getMajorDiscrepancyData().pdfData,
      multi: this.getMultiProductData().pdfData
    }[scenario];

    return `
GOOGLE WORKSPACE ORDER FORM
===========================

Date: ${new Date().toLocaleDateString('en-US')}
QuoteID: ${orderData.quoteId || 'Q-259105'}
PricingValidUntil: 03/31/2025

Customer Information
--------------------
Customer: ${orderData.customerName}
PrimaryDomain: Virtusa.com
OffDomainEmail: prasddddddd@hotmail.com
SalesRep: Tidddtdd aarnnuxx

Customer Contact Details
------------------------
CustomerDetails:
  XohXmmed SXXX KXXXX
  888 E TASMAN DR. SUITE #210
  MILPITAS, California 95035
  United States
  +91 80081 11076
  XXXXXXXXXalXXXm@Virtusa.com

CustomerBillingDetails:
  MoXXXXXh SalXXXXman KaXXXXe
  Plot No.10, Sy No.115
  Nanakramguda Village
  Hyderabad, Telangana 500018
  India
  +91 80081 11076
  salmankaleemm@Virtusa.com

Order Line Items
----------------
1. ServiceName: ${orderData.product}
   OperationType: ${orderData.operationType}
   BillingFrequency: ${orderData.billingFrequency}
   ServiceStartDate: 03/31/2025
   ServiceEndDate: 03/30/2027
   OrderTerm: ${orderData.orderTerm}
   Quantity: ${orderData.quantity}
   UnitCost: 2650.00
   Discount: —
   TotalCost: ${orderData.contractValue?.replace(/[₹,]/g, '') || '2575800.00'}

Summary
-------------
TotalINR: ${orderData.contractValue?.replace(/[₹,]/g, '') || '2575800.00'}

Notes
-----
- All prices are exclusive of taxes.
- Discounts are per contractual terms.
- Service starts upon activation.
    `;
  }

  // Generate sample JSON data for the new extraction format
  static getSampleJSONData(scenario: 'perfect' | 'minor' | 'major' | 'multi' = 'perfect'): string {
    const orderData = {
      perfect: this.getPerfectMatchData().pdfData,
      minor: this.getMinorDiscrepancyData().pdfData,
      major: this.getMajorDiscrepancyData().pdfData,
      multi: this.getMultiProductData().pdfData
    }[scenario];

    // Create JSON structure based on the provided format
    const jsonData = [{
      "OrderHeader": {
        "Date": "03/31/2025",
        "QuoteID": orderData.quoteId || "Q-259105",
        "PricingValidUntil": "03/31/2025",
        "Customer": orderData.customerName || "Virtusa Consulting Services Private Limited",
        "CustomerDetails": "Mohammed Salman Kaleem\n888 E TASMAN DR. SUITE # 210\nMILPITAS California\n95035\nUnited States\n+91 80081 11076\nsalmankaleemm@virtusa.com",
        "CustomerBillingDetails": "Mohammed Salman Kaleem\nPlot No.10, Sy No.115\nNanakramguda Village\nHyderabad Telangana\n500018\nIndia\n+91 80081 11076\nsalmankaleemm@virtusa.com",
        "PrimaryDomain": "virtusa.com",
        "OffDomainEmail": "prashantshukla@hotmail.com",
        "SalesRep": "Timothy Harmount"
      },
      "OrderLineItems": this.generateLineItemsForScenario(scenario),
      "Summary": {
        "TotalINR": this.getTotalForScenario(scenario)
      }
    }];

    return JSON.stringify(jsonData, null, 2);
  }

  private static generateLineItemsForScenario(scenario: string): any[] {
    switch (scenario) {
      case 'multi':
        return [
          {
            "ServiceName": "Google Workspace Enterprise Plus\nGAPPS-EN\nT-PLUS-1U\nSER-1MO",
            "OperationType": "New",
            "BillingFrequency": "Monthly in Advance",
            "ServiceStartDate": "03/31/2025",
            "ServiceEndDate": "03/30/2027",
            "OrderTerm": "24M OD",
            "Quantity": "27,000",
            "UnitCost": "2,650.00",
            "Discount": " ",
            "TotalCost": "2,575,800.00"
          },
          {
            "ServiceName": "Google Workspace Enterprise Plus\nArchived User\nGAPPS-AU\n-ENT-PLUS\n-1USER-1M\n0",
            "OperationType": "New",
            "BillingFrequency": "Monthly in Advance",
            "ServiceStartDate": "03/31/2025",
            "ServiceEndDate": "03/30/2027",
            "OrderTerm": "24M OD",
            "Quantity": "5,000",
            "UnitCost": "470.00",
            "Discount": " ",
            "TotalCost": "84,600.00"
          },
          {
            "ServiceName": "Google Workspace Enterprise Plus\nGAPPS-EN\nT-PLUS-1U\nSER-1MO",
            "OperationType": "New",
            "BillingFrequency": "Monthly in Advance",
            "ServiceStartDate": "03/31/2027",
            "ServiceEndDate": "03/30/2030",
            "OrderTerm": "36M OD",
            "Quantity": "27,000",
            "UnitCost": "2,650.00",
            "Discount": "81.43%\n(Additional\nDiscount)",
            "TotalCost": "478,377.30"
          },
          {
            "ServiceName": "Google Workspace Enterprise Plus\nArchived User\nGAPPS-AU\n-ENT-PLUS\n-1USER-1M\n0",
            "OperationType": "New",
            "BillingFrequency": "Monthly in Advance",
            "ServiceStartDate": "03/31/2027",
            "ServiceEndDate": "03/30/2030",
            "OrderTerm": "36M OD",
            "Quantity": "5,000",
            "UnitCost": "470.00",
            "Discount": "78.50%\n(Additional\nDiscount)",
            "TotalCost": "18,189.00"
          }
        ];
      
      default:
        return [
          {
            "ServiceName": "Google Workspace Enterprise Plus\nGAPPS-EN\nT-PLUS-1U\nSER-1MO",
            "OperationType": "New",
            "BillingFrequency": "Monthly in Advance",
            "ServiceStartDate": "03/31/2025",
            "ServiceEndDate": "03/30/2027",
            "OrderTerm": "24M OD",
            "Quantity": "27,000",
            "UnitCost": "2,650.00",
            "Discount": " ",
            "TotalCost": "2,575,800.00"
          }
        ];
    }
  }

  private static getTotalForScenario(scenario: string): string {
    switch (scenario) {
      case 'multi':
        return "3,156,915,060.00";
      default:
        return "2,575,800.00";
    }
  }

  // Get test data sources with Google Workspace data
  static getGoogleWorkspaceTestDataSources(scenario: 'perfect' | 'minor' | 'major' | 'multi' = 'perfect') {
    const data = {
      perfect: this.getPerfectMatchData(),
      minor: this.getMinorDiscrepancyData(),
      major: this.getMajorDiscrepancyData(),
      multi: this.getMultiProductData()
    }[scenario];

    return [
      {
        id: 'pdf',
        name: 'Order Form (PDF)',
        type: 'pdf' as const,
        status: 'success' as const,
        data: data.pdfData,
        extractedAt: new Date(Date.now() - 300000).toISOString()
      },
      {
        id: 'sap',
        name: 'SAP System',
        type: 'sap' as const,
        status: 'success' as const,
        data: data.sapData,
        extractedAt: new Date(Date.now() - 240000).toISOString()
      },
      {
        id: 'oreo',
        name: 'OREO UI',
        type: 'oreo' as const,
        status: 'success' as const,
        data: data.oreoData,
        extractedAt: new Date(Date.now() - 180000).toISOString()
      },
      {
        id: 'mithra',
        name: 'Mithra/Billy System',
        type: 'mithra' as const,
        status: 'success' as const,
        data: data.mithraData,
        extractedAt: new Date(Date.now() - 120000).toISOString()
      }
    ];
  }
}