import { ContractData, DataSource, ComparisonResult, ExtractedOrderForm } from '../types/audit';

export class TestDataGenerator {
  // Perfect match scenario aligned with Google Workspace Order Form
  static getPerfectMatchData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    const baseQuoteId = 'Q-259105';
    const baseCustomerName = 'Virtusa Consulting Services Private Limited';
    const baseProduct = 'Google Workspace Enterprise Plus';
    const baseProductId = 'GAPPS-ENT-PLUS-1USER-1MO';
    const baseOperationType = 'New';
    const baseServiceStartDate = '2025-03-31';
    const baseServiceEndDate = '2027-03-30';
    const baseOrderTerm = '24M OD';
    const baseQuantity = '27,000';
    const baseUnitCost = '₹2,650.00';
    const baseBillingFrequency = 'Monthly in Advance';
    const baseContractValue = '₹2,575,800.00';

    return {
      pdfData: {
        // PDF Fields
        quoteId: baseQuoteId,
        customerName: baseCustomerName,
        product: baseProduct,
        productId: baseProductId,
        operationType: baseOperationType,
        serviceStartDate: baseServiceStartDate,
        serviceEndDate: baseServiceEndDate,
        orderTerm: baseOrderTerm,
        quantity: baseQuantity,
        unitCost: baseUnitCost,
        billingFrequency: baseBillingFrequency,
        // Legacy compatibility
        contractNumber: baseQuoteId,
        contractValue: baseContractValue,
        startDate: baseServiceStartDate,
        endDate: baseServiceEndDate,
        currency: 'INR'
      },
      sapData: {
        // SAP Fields
        solutionQuoteNumber: baseQuoteId.replace('Q-', 'SQN-'),
        soldToParty: baseCustomerName,
        product: baseProduct,
        productId: baseProductId,
        operationType: baseOperationType,
        serviceStartDate: baseServiceStartDate,
        serviceEndDate: baseServiceEndDate,
        quantity: baseQuantity,
        lineAmount: baseUnitCost,
        duration: baseOrderTerm,
        // Legacy compatibility
        customerName: baseCustomerName,
        contractNumber: baseQuoteId,
        contractValue: baseContractValue,
        startDate: baseServiceStartDate,
        endDate: baseServiceEndDate,
        currency: 'INR'
      },
      oreoData: {
        // OREO UI Fields
        solutionQuoteNumber: baseQuoteId.replace('Q-', 'SQN-'),
        soldToParty: baseCustomerName,
        product: baseProduct,
        productId: baseProductId,
        operationType: baseOperationType,
        serviceStartDate: baseServiceStartDate,
        serviceEndDate: baseServiceEndDate,
        quantity: baseQuantity,
        lineAmount: baseUnitCost,
        duration: baseOrderTerm,
        // Legacy compatibility
        customerName: baseCustomerName,
        contractNumber: baseQuoteId,
        contractValue: baseContractValue,
        startDate: baseServiceStartDate,
        endDate: baseServiceEndDate,
        currency: 'INR'
      },
      mithraData: {
        // Mithra/Billy System Fields
        soldToParty: baseCustomerName,
        billingParty: 'Virtusa Consulting Services Pvt Ltd - Finance Department',
        // Legacy compatibility
        customerName: baseCustomerName,
        contractNumber: baseQuoteId,
        contractValue: baseContractValue,
        billingFrequency: baseBillingFrequency,
        currency: 'INR'
      }
    };
  }

  // Scenario with minor discrepancies aligned with Google Workspace
  static getMinorDiscrepancyData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        quoteId: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        orderTerm: '24M OD',
        quantity: '27,000',
        unitCost: '₹2,650.00',
        billingFrequency: 'Monthly in Advance',
        // Legacy
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      sapData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'VIRTUSA CONSULTING SERVICES PRIVATE LIMITED', // Case difference
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '31/03/2025', // Different date format
        serviceEndDate: '30/03/2027',
        quantity: '27000', // No comma separator
        lineAmount: 'INR 2,650.00', // Different currency format
        duration: '24 Months OD', // Slightly different format
        // Legacy
        customerName: 'VIRTUSA CONSULTING SERVICES PRIVATE LIMITED',
        contractNumber: 'Q-259105',
        contractValue: 'INR 2,575,800.00',
        startDate: '31/03/2025',
        endDate: '30/03/2027',
        currency: 'INR'
      },
      oreoData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Pvt. Ltd.', // Abbreviated format
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '03/31/2025', // US date format
        serviceEndDate: '03/30/2027',
        quantity: '27,000',
        lineAmount: '2650.00 INR', // Different currency position
        duration: '24M OD',
        // Legacy
        customerName: 'Virtusa Consulting Services Pvt. Ltd.',
        contractNumber: 'Q-259105',
        contractValue: '2575800.00 INR',
        startDate: '03/31/2025',
        endDate: '03/30/2027',
        currency: 'INR'
      },
      mithraData: {
        soldToParty: 'Virtusa Consulting Services Pvt Ltd', // Slightly different abbreviation
        billingParty: 'Virtusa Finance Department',
        // Legacy
        customerName: 'Virtusa Consulting Services Pvt Ltd',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        billingFrequency: 'Monthly', // Simplified format
        currency: 'INR'
      }
    };
  }

  // Enhanced scenario with MAJOR discrepancies - designed to fail multiple checks
  static getMajorDiscrepancyData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        quoteId: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        orderTerm: '24M OD',
        quantity: '27,000',
        unitCost: '₹2,650.00',
        billingFrequency: 'Monthly in Advance',
        // Legacy
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      sapData: {
        solutionQuoteNumber: 'SQN-259999', // COMPLETELY DIFFERENT QUOTE NUMBER - CRITICAL FAILURE
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Business Standard', // WRONG PRODUCT - CRITICAL FAILURE
        productId: 'GAPPS-BUS-STD-1USER-1MO', // WRONG PRODUCT ID - CRITICAL FAILURE
        operationType: 'Renewal', // WRONG OPERATION TYPE - FAILURE
        serviceStartDate: '2025-04-01', // WRONG START DATE - CRITICAL FAILURE
        serviceEndDate: '2026-03-31', // WRONG END DATE - CRITICAL FAILURE
        quantity: '25,000', // WRONG QUANTITY - CRITICAL FAILURE
        lineAmount: '₹1,850.00', // WRONG PRICE - CRITICAL FAILURE
        duration: '12M OD', // WRONG DURATION - CRITICAL FAILURE
        // Legacy
        customerName: 'Virtusa Consulting Services Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹1,387,500.00', // WRONG TOTAL
        startDate: '2025-04-01',
        endDate: '2026-03-31',
        currency: 'INR'
      },
      oreoData: {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Technologies Private Limited', // WRONG COMPANY NAME - FAILURE
        product: 'Google Workspace Enterprise Standard', // WRONG PRODUCT VARIANT - FAILURE
        productId: 'GAPPS-ENT-STD-1USER-1MO', // WRONG PRODUCT ID - FAILURE
        operationType: 'Amendment', // WRONG OPERATION TYPE - FAILURE
        serviceStartDate: '2025-04-15', // WRONG START DATE - FAILURE
        serviceEndDate: '2027-03-30',
        quantity: '30,000', // WRONG QUANTITY - FAILURE
        lineAmount: '₹2,450.00', // WRONG PRICE - FAILURE
        duration: '24M OD',
        // Legacy
        customerName: 'Virtusa Technologies Private Limited',
        contractNumber: 'Q-259105',
        contractValue: '₹2,205,000.00', // WRONG TOTAL
        startDate: '2025-04-15',
        endDate: '2027-03-30',
        currency: 'INR'
      },
      mithraData: {
        soldToParty: 'Virtusa Corporation India', // WRONG COMPANY NAME - FAILURE
        billingParty: 'External Billing Services Ltd', // WRONG BILLING ENTITY - CRITICAL FAILURE
        // Legacy
        customerName: 'Virtusa Corporation India',
        contractNumber: 'Q-259105',
        contractValue: '₹2,575,800.00',
        billingFrequency: 'Quarterly', // WRONG BILLING FREQUENCY - CRITICAL FAILURE
        currency: 'USD' // WRONG CURRENCY - CRITICAL FAILURE
      }
    };
  }

  // Complex multi-currency scenario
  static getMultiCurrencyData(): {
    pdfData: ContractData;
    sapData: ContractData;
    oreoData: ContractData;
    mithraData: ContractData;
  } {
    return {
      pdfData: {
        quoteId: 'Q-259106',
        customerName: 'European Enterprises GmbH',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-04-01',
        serviceEndDate: '2026-03-31',
        orderTerm: '12M OD',
        quantity: '5,000',
        unitCost: '€25.00',
        billingFrequency: 'Monthly in Advance',
        // Legacy
        contractNumber: 'Q-259106',
        contractValue: '€125,000.00',
        startDate: '2025-04-01',
        endDate: '2026-03-31',
        currency: 'EUR'
      },
      sapData: {
        solutionQuoteNumber: 'SQN-259106',
        soldToParty: 'European Enterprises GmbH',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '2025-04-01',
        serviceEndDate: '2026-03-31',
        quantity: '5,000',
        lineAmount: 'EUR 25.00',
        duration: '12M OD',
        // Legacy
        customerName: 'European Enterprises GmbH',
        contractNumber: 'Q-259106',
        contractValue: 'EUR 125,000.00',
        startDate: '2025-04-01',
        endDate: '2026-03-31',
        currency: 'EUR'
      },
      oreoData: {
        solutionQuoteNumber: 'SQN-259106',
        soldToParty: 'European Enterprises GmbH',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        operationType: 'New',
        serviceStartDate: '01/04/2025',
        serviceEndDate: '31/03/2026',
        quantity: '5,000',
        lineAmount: '$27.50', // Converted to USD
        duration: '12M OD',
        // Legacy
        customerName: 'European Enterprises GmbH',
        contractNumber: 'Q-259106',
        contractValue: '$137,500.00',
        startDate: '01/04/2025',
        endDate: '31/03/2026',
        currency: 'USD' // Different currency
      },
      mithraData: {
        soldToParty: 'European Enterprises GmbH',
        billingParty: 'European Enterprises - Accounting',
        // Legacy
        customerName: 'European Enterprises GmbH',
        contractNumber: 'Q-259106',
        contractValue: '€125,000.00',
        billingFrequency: 'Monthly in Advance',
        currency: 'EUR'
      }
    };
  }

  // Generate sample contract text for PDF extraction testing
  static getSampleContractText(scenario: 'perfect' | 'minor' | 'major' | 'currency' = 'perfect'): string {
    const orderData = {
      perfect: this.getPerfectMatchData().pdfData,
      minor: this.getMinorDiscrepancyData().pdfData,
      major: this.getMajorDiscrepancyData().pdfData,
      currency: this.getMultiCurrencyData().pdfData
    }[scenario];

    return `
GOOGLE WORKSPACE ORDER FORM
===========================

Date: ${new Date().toLocaleDateString('en-US')}
QuoteID: ${orderData.quoteId || 'Q-259105'}
PricingValidUntil: 03/31/2025

Customer Information
--------------------
Customer: ${orderData.customerName}
PrimaryDomain: ${orderData.customerName?.toLowerCase().replace(/\s+/g, '')}.com
SalesRep: Account Manager

Order Line Items
----------------
1. ServiceName: ${orderData.product}
   OperationType: ${orderData.operationType}
   BillingFrequency: ${orderData.billingFrequency}
   ServiceStartDate: 03/31/2025
   ServiceEndDate: 03/30/2027
   OrderTerm: ${orderData.orderTerm}
   Quantity: ${orderData.quantity}
   UnitCost: ${orderData.unitCost?.replace(/[₹,]/g, '') || '2650.00'}
   TotalCost: ${orderData.contractValue?.replace(/[₹,]/g, '') || '2575800.00'}

Summary
-------------
TotalINR: ${orderData.contractValue?.replace(/[₹,]/g, '') || '2575800.00'}

Notes
-----
- All prices are exclusive of taxes.
- Service starts upon activation.
- ${orderData.billingFrequency} billing cycle.
    `;
  }

  // Generate test data sources with different statuses
  static getTestDataSources(scenario: 'all-success' | 'mixed-status' | 'with-errors' = 'all-success'): DataSource[] {
    const baseDataSources: DataSource[] = [
      {
        id: 'pdf',
        name: 'Order Form (PDF)',
        type: 'pdf',
        status: 'pending',
        data: null
      },
      {
        id: 'sap',
        name: 'SAP System',
        type: 'sap',
        status: 'pending',
        data: null
      },
      {
        id: 'oreo',
        name: 'OREO UI',
        type: 'oreo',
        status: 'pending',
        data: null
      },
      {
        id: 'mithra',
        name: 'Mithra/Billy System',
        type: 'mithra',
        status: 'pending',
        data: null
      }
    ];

    switch (scenario) {
      case 'all-success':
        const perfectData = this.getPerfectMatchData();
        return [
          {
            ...baseDataSources[0],
            status: 'success',
            data: perfectData.pdfData,
            extractedAt: new Date(Date.now() - 300000).toISOString() // 5 minutes ago
          },
          {
            ...baseDataSources[1],
            status: 'success',
            data: perfectData.sapData,
            extractedAt: new Date(Date.now() - 240000).toISOString() // 4 minutes ago
          },
          {
            ...baseDataSources[2],
            status: 'success',
            data: perfectData.oreoData,
            extractedAt: new Date(Date.now() - 180000).toISOString() // 3 minutes ago
          },
          {
            ...baseDataSources[3],
            status: 'success',
            data: perfectData.mithraData,
            extractedAt: new Date(Date.now() - 120000).toISOString() // 2 minutes ago
          }
        ];

      case 'mixed-status':
        const minorData = this.getMinorDiscrepancyData();
        return [
          {
            ...baseDataSources[0],
            status: 'success',
            data: minorData.pdfData,
            extractedAt: new Date(Date.now() - 300000).toISOString()
          },
          {
            ...baseDataSources[1],
            status: 'loading',
            data: null
          },
          {
            ...baseDataSources[2],
            status: 'pending',
            data: null
          },
          {
            ...baseDataSources[3],
            status: 'pending',
            data: null
          }
        ];

      case 'with-errors':
        const majorData = this.getMajorDiscrepancyData();
        return [
          {
            ...baseDataSources[0],
            status: 'success',
            data: majorData.pdfData,
            extractedAt: new Date(Date.now() - 300000).toISOString()
          },
          {
            ...baseDataSources[1],
            status: 'error',
            data: null,
            error: 'SAP API connection timeout - please retry'
          },
          {
            ...baseDataSources[2],
            status: 'success',
            data: majorData.oreoData,
            extractedAt: new Date(Date.now() - 180000).toISOString()
          },
          {
            ...baseDataSources[3],
            status: 'error',
            data: null,
            error: 'Mithra/Billy System authentication failed'
          }
        ];

      default:
        return baseDataSources;
    }
  }

  // Generate sample comparison results with enhanced major discrepancy scenario
  static getSampleComparisonResults(scenario: 'perfect' | 'minor' | 'major' = 'perfect'): ComparisonResult[] {
    switch (scenario) {
      case 'perfect':
        return [
          {
            field: 'quoteId',
            source1Value: 'Q-259105',
            source2Value: 'SQN-259105',
            source3Value: 'SQN-259105',
            match: true,
            confidence: 100,
            notes: 'All values match perfectly'
          },
          {
            field: 'customerName',
            source1Value: 'Virtusa Consulting Services Private Limited',
            source2Value: 'Virtusa Consulting Services Private Limited',
            source3Value: 'Virtusa Consulting Services Private Limited',
            match: true,
            confidence: 100,
            notes: 'All values match perfectly'
          },
          {
            field: 'product',
            source1Value: 'Google Workspace Enterprise Plus',
            source2Value: 'Google Workspace Enterprise Plus',
            source3Value: 'Google Workspace Enterprise Plus',
            match: true,
            confidence: 100,
            notes: 'All values match perfectly'
          },
          {
            field: 'productId',
            source1Value: 'GAPPS-ENT-PLUS-1USER-1MO',
            source2Value: 'GAPPS-ENT-PLUS-1USER-1MO',
            source3Value: 'GAPPS-ENT-PLUS-1USER-1MO',
            match: true,
            confidence: 100,
            notes: 'All values match perfectly'
          },
          {
            field: 'quantity',
            source1Value: '27,000',
            source2Value: '27,000',
            source3Value: '27,000',
            match: true,
            confidence: 100,
            notes: 'All values match perfectly'
          }
        ];

      case 'minor':
        return [
          {
            field: 'quoteId',
            source1Value: 'Q-259105',
            source2Value: 'SQN-259105',
            source3Value: 'SQN-259105',
            match: true,
            confidence: 100,
            notes: 'All values match after normalization'
          },
          {
            field: 'customerName',
            source1Value: 'Virtusa Consulting Services Private Limited',
            source2Value: 'VIRTUSA CONSULTING SERVICES PRIVATE LIMITED',
            source3Value: 'Virtusa Consulting Services Pvt. Ltd.',
            match: false,
            confidence: 85,
            notes: 'SAP value has different case formatting, OREO uses abbreviation'
          },
          {
            field: 'unitCost',
            source1Value: '₹2,650.00',
            source2Value: 'INR 2,650.00',
            source3Value: '2650.00 INR',
            match: false,
            confidence: 90,
            notes: 'Different formatting but same value'
          },
          {
            field: 'serviceStartDate',
            source1Value: '2025-03-31',
            source2Value: '31/03/2025',
            source3Value: '03/31/2025',
            match: false,
            confidence: 95,
            notes: 'Different date formats but same date'
          },
          {
            field: 'billingFrequency',
            source1Value: 'Monthly in Advance',
            source2Value: 'Monthly in Advance',
            source3Value: 'Monthly in Advance',
            match: true,
            confidence: 100,
            notes: 'All values match perfectly'
          }
        ];

      case 'major':
        return [
          // CRITICAL FAILURES - These should show as red/failed
          {
            field: 'quoteId',
            source1Value: 'Q-259105',
            source2Value: 'SQN-259999', // COMPLETELY DIFFERENT
            source3Value: 'SQN-259105',
            match: false,
            confidence: 15, // VERY LOW CONFIDENCE - CRITICAL FAILURE
            notes: 'SAP quote number completely different - critical mismatch requiring immediate investigation'
          },
          {
            field: 'product',
            source1Value: 'Google Workspace Enterprise Plus',
            source2Value: 'Google Workspace Business Standard', // DIFFERENT PRODUCT
            source3Value: 'Google Workspace Enterprise Standard', // ALSO DIFFERENT
            match: false,
            confidence: 10, // VERY LOW CONFIDENCE - CRITICAL FAILURE
            notes: 'All three systems show different products - critical discrepancy'
          },
          {
            field: 'productId',
            source1Value: 'GAPPS-ENT-PLUS-1USER-1MO',
            source2Value: 'GAPPS-BUS-STD-1USER-1MO', // WRONG PRODUCT ID
            source3Value: 'GAPPS-ENT-STD-1USER-1MO', // ALSO WRONG
            match: false,
            confidence: 25, // LOW CONFIDENCE - FAILURE
            notes: 'All systems show different product IDs - requires investigation'
          },
          {
            field: 'unitCost',
            source1Value: '₹2,650.00',
            source2Value: '₹1,850.00', // 30% LESS - CRITICAL
            source3Value: '₹2,450.00', // 8% LESS
            match: false,
            confidence: 5, // VERY LOW CONFIDENCE - CRITICAL FAILURE
            notes: 'Significant financial discrepancies across all systems - critical issue'
          },
          {
            field: 'quantity',
            source1Value: '27,000',
            source2Value: '25,000', // 7% LESS
            source3Value: '30,000', // 11% MORE
            match: false,
            confidence: 20, // LOW CONFIDENCE - FAILURE
            notes: 'Quantity differs significantly across all systems'
          },
          {
            field: 'serviceStartDate',
            source1Value: '2025-03-31',
            source2Value: '2025-04-01', // ONE DAY LATER
            source3Value: '2025-04-15', // TWO WEEKS LATER
            match: false,
            confidence: 30, // LOW CONFIDENCE - FAILURE
            notes: 'Service start dates differ significantly across systems'
          },
          {
            field: 'serviceEndDate',
            source1Value: '2027-03-30',
            source2Value: '2026-03-31', // ONE YEAR EARLIER
            source3Value: '2027-03-30',
            match: false,
            confidence: 35, // LOW CONFIDENCE - FAILURE
            notes: 'SAP shows significantly earlier end date'
          },
          {
            field: 'operationType',
            source1Value: 'New',
            source2Value: 'Renewal', // COMPLETELY DIFFERENT
            source3Value: 'Amendment', // ALSO DIFFERENT
            match: false,
            confidence: 15, // VERY LOW CONFIDENCE - CRITICAL FAILURE
            notes: 'All systems show different operation types - critical mismatch'
          },
          {
            field: 'customerName',
            source1Value: 'Virtusa Consulting Services Private Limited',
            source2Value: 'Virtusa Consulting Services Private Limited',
            source3Value: 'Virtusa Technologies Private Limited', // DIFFERENT ENTITY
            source4Value: 'Virtusa Corporation India', // MITHRA ALSO DIFFERENT
            match: false,
            confidence: 40, // LOW CONFIDENCE - FAILURE
            notes: 'Customer names differ between OREO and Mithra systems'
          },
          {
            field: 'billingFrequency',
            source1Value: 'Monthly in Advance',
            source2Value: 'Monthly in Advance',
            source3Value: 'Monthly in Advance',
            source4Value: 'Quarterly', // COMPLETELY DIFFERENT BILLING
            match: false,
            confidence: 25, // LOW CONFIDENCE - FAILURE
            notes: 'Mithra/Billy system shows completely different billing frequency'
          }
        ];

      default:
        return [];
    }
  }

  // Generate realistic file names for testing
  static getSampleFileNames(): string[] {
    return [
      'Google_Workspace_Order_Q-259105_Virtusa_Signed.pdf',
      'GWS_Enterprise_Plus_Quote_Virtusa_2025.pdf',
      'Order_Form_Google_Workspace_Q259105.pdf',
      'Virtusa_Google_Workspace_Contract_2025.pdf',
      'GWS_Order_Form_27000_Users_Virtusa.pdf'
    ];
  }

  // Generate sample audit IDs
  static generateAuditId(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `AUD-${timestamp}-${random}`;
  }

  // Generate sample contract numbers
  static generateContractNumber(): string {
    const year = new Date().getFullYear();
    const sequence = Math.floor(Math.random() * 999999) + 100000;
    return `Q-${sequence}`;
  }
}