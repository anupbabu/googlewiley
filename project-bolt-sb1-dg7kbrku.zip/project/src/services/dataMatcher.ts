import { ContractData, MappingRule, ComparisonResult } from '../types/audit';
import { GenAIDataMatcher } from './genAIDataMatcher';

export class DataMatcher {
  private mappingRules: MappingRule[] = [
    {
      id: 'quote-id',
      sourceField: 'quoteId',
      targetField: 'quoteId',
      required: true
    },
    {
      id: 'customer-name',
      sourceField: 'customerName',
      targetField: 'customerName',
      transformation: 'uppercase',
      required: true
    },
    {
      id: 'product',
      sourceField: 'product',
      targetField: 'product',
      required: true
    },
    {
      id: 'product-id',
      sourceField: 'productId',
      targetField: 'productId',
      required: true
    },
    {
      id: 'operation-type',
      sourceField: 'operationType',
      targetField: 'operationType',
      required: true
    },
    {
      id: 'service-start-date',
      sourceField: 'serviceStartDate',
      targetField: 'serviceStartDate',
      transformation: 'date_format',
      required: true
    },
    {
      id: 'service-end-date',
      sourceField: 'serviceEndDate',
      targetField: 'serviceEndDate',
      transformation: 'date_format',
      required: true
    },
    {
      id: 'order-term',
      sourceField: 'orderTerm',
      targetField: 'orderTerm',
      required: true
    },
    {
      id: 'quantity',
      sourceField: 'quantity',
      targetField: 'quantity',
      required: true
    },
    {
      id: 'unit-cost',
      sourceField: 'unitCost',
      targetField: 'unitCost',
      transformation: 'currency_format',
      required: true,
      tolerance: 0.01
    },
    {
      id: 'billing-frequency',
      sourceField: 'billingFrequency',
      targetField: 'billingFrequency',
      required: true
    }
  ];

  compareData(
    source1Data: ContractData,
    source2Data: ContractData,
    source3Data: ContractData | null = null,
    source4Data: ContractData | null = null
  ): ComparisonResult[] {
    // Check if AI comparison should be used
    if (GenAIDataMatcher.shouldUseAI()) {
      console.log('Using GenAI-powered data comparison');
      // Return a promise that will be handled by the calling component
      // For now, we'll use the traditional method but this can be enhanced
    }
    
    const results: ComparisonResult[] = [];

    this.mappingRules.forEach(rule => {
      // Handle field mapping for different systems
      const source1Value = this.getFieldValue(source1Data, rule.sourceField, 'pdf');
      const source2Value = this.getFieldValue(source2Data, rule.sourceField, 'sap');
      const source3Value = source3Data ? this.getFieldValue(source3Data, rule.sourceField, 'oreo') : null;
      const source4Value = source4Data ? this.getFieldValue(source4Data, rule.sourceField, 'mithra') : null;

      // Transform values
      const transformedSource1 = this.transformValue(source1Value, rule.transformation);
      const transformedSource2 = this.transformValue(source2Value, rule.transformation);
      const transformedSource3 = source3Value ? this.transformValue(source3Value, rule.transformation) : null;
      const transformedSource4 = source4Value ? this.transformValue(source4Value, rule.transformation) : null;

      // Determine comparison type and perform appropriate matching
      const comparisonResult = this.performStructuredComparison(
        rule.sourceField,
        transformedSource1,
        transformedSource2,
        transformedSource3,
        transformedSource4,
        rule
      );

      results.push(comparisonResult);
    });

    return results;
  }

  private performStructuredComparison(
    field: string,
    source1Value: any,
    source2Value: any,
    source3Value: any,
    source4Value: any,
    rule: MappingRule
  ): ComparisonResult {
    // Define comparison criteria based on the structured requirements
    const comparisonCriteria = this.getComparisonCriteria(field);
    
    let match = false;
    let confidence = 0;
    let notes = '';

    switch (comparisonCriteria.type) {
      case '3-way':
        // Compare PDF, SAP, and OREO values
        const threeWayValues = [source1Value, source2Value, source3Value].filter(v => v !== null && v !== undefined);
        match = this.valuesMatch(threeWayValues, rule);
        confidence = Math.round(this.calculateConfidence(threeWayValues, rule));
        notes = this.generateStructuredNotes(threeWayValues, match, field, '3-way');
        break;

      case '2-way':
        // Compare PDF and Mithra values (for billing system checks)
        const twoWayValues = [source1Value, source4Value].filter(v => v !== null && v !== undefined);
        match = this.valuesMatch(twoWayValues, rule);
        confidence = Math.round(this.calculateConfidence(twoWayValues, rule));
        notes = this.generateStructuredNotes(twoWayValues, match, field, '2-way');
        break;

      case 'single-check':
        // Check if value exists and is not null (for Order Term)
        match = source1Value !== null && source1Value !== undefined && source1Value !== '';
        confidence = match ? 100 : 0;
        notes = match ? 'Value present in PDF' : 'Value missing in PDF';
        break;

      default:
        // Fallback to all available values
        const allValues = [source1Value, source2Value, source3Value, source4Value].filter(v => v !== null && v !== undefined);
        match = this.valuesMatch(allValues, rule);
        confidence = Math.round(this.calculateConfidence(allValues, rule));
        notes = this.generateStructuredNotes(allValues, match, field, 'multi-way');
    }

    return {
      field,
      source1Value,
      source2Value,
      source3Value,
      source4Value,
      match,
      confidence,
      notes
    };
  }

  private getComparisonCriteria(field: string): { type: string; criteria: string } {
    // Define comparison criteria based on the requirements
    const criteriaMap: Record<string, { type: string; criteria: string }> = {
      // Order Has Been Processed? - 3-way comparisons
      'quoteId': { type: '3-way', criteria: 'equals' },
      'customerName': { type: '3-way', criteria: 'equals' },
      'product': { type: '3-way', criteria: 'equals' },
      'productId': { type: '3-way', criteria: 'equals' },
      'operationType': { type: '3-way', criteria: 'equals' },
      'serviceStartDate': { type: '3-way', criteria: 'equals' },
      'serviceEndDate': { type: '3-way', criteria: 'equals' },
      'quantity': { type: '3-way', criteria: 'equals' },
      'unitCost': { type: '3-way', criteria: 'equals' },
      
      // Single check
      'orderTerm': { type: 'single-check', criteria: 'not-null' },
      
      // Terms of Booking vs Order Form - 3-way comparison
      'billingFrequency': { type: '3-way', criteria: 'equals' },
      
      // Mithra/Billy System checks would be handled separately in the UI
    };

    return criteriaMap[field] || { type: '3-way', criteria: 'equals' };
  }

  private getFieldValue(data: ContractData, field: string, sourceType: string): any {
    // Handle field mapping between different systems
    switch (sourceType) {
      case 'pdf':
        // Order Form uses direct field names
        return data[field as keyof ContractData];
      
      case 'sap':
        // SAP field mapping
        switch (field) {
          case 'quoteId': return data.solutionQuoteNumber || data.contractNumber;
          case 'customerName': return data.soldToParty || data.customerName;
          case 'unitCost': return data.lineAmount || data.contractValue;
          case 'serviceStartDate': return data.serviceStartDate || data.startDate;
          case 'serviceEndDate': return data.serviceEndDate || data.endDate;
          case 'orderTerm': return data.duration || data.orderTerm;
          default: return data[field as keyof ContractData];
        }
      
      case 'oreo':
        // OREO field mapping
        switch (field) {
          case 'quoteId': return data.solutionQuoteNumber || data.contractNumber;
          case 'customerName': return data.soldToParty || data.customerName;
          case 'unitCost': return data.lineAmount || data.contractValue;
          case 'serviceStartDate': return data.serviceStartDate || data.startDate;
          case 'serviceEndDate': return data.serviceEndDate || data.endDate;
          case 'orderTerm': return data.duration || data.orderTerm;
          default: return data[field as keyof ContractData];
        }
      
      case 'mithra':
        // Mithra/Billy field mapping (limited fields)
        switch (field) {
          case 'customerName': return data.soldToParty || data.customerName;
          case 'billingFrequency': return data.billingFrequency;
          default: return null; // Mithra only has limited fields
        }
      
      default:
        return data[field as keyof ContractData];
    }
  }

  private transformValue(value: any, transformation?: string): any {
    if (!value) return value;

    switch (transformation) {
      case 'uppercase':
        return String(value).toUpperCase().trim();
      case 'lowercase':
        return String(value).toLowerCase().trim();
      case 'currency_format':
        return this.normalizeCurrency(String(value));
      case 'date_format':
        return this.normalizeDate(String(value));
      default:
        return String(value).trim();
    }
  }

  private normalizeCurrency(value: string): number {
    // Remove currency symbols and convert to number
    const cleaned = value.replace(/[$€£,USD EUR GBP\s]/g, '');
    return parseFloat(cleaned) || 0;
  }

  private normalizeDate(value: string): string {
    // Convert various date formats to YYYY-MM-DD
    const date = new Date(value.replace(/\//g, '-'));
    if (isNaN(date.getTime())) return value;
    return date.toISOString().split('T')[0];
  }

  private valuesMatch(values: any[], rule: MappingRule): boolean {
    if (values.length < 2) return true;

    if (rule.transformation === 'currency_format' && rule.tolerance) {
      const numbers = values.map(v => Number(v));
      for (let i = 0; i < numbers.length - 1; i++) {
        for (let j = i + 1; j < numbers.length; j++) {
          if (Math.abs(numbers[i] - numbers[j]) > rule.tolerance) {
            return false;
          }
        }
      }
      return true;
    }

    // Check if all values are the same
    const firstValue = values[0];
    return values.every(value => value === firstValue);
  }

  private calculateConfidence(values: any[], rule: MappingRule): number {
    if (values.length < 2) return 100;
    
    if (this.valuesMatch(values, rule)) return 100;

    // Count how many values match the most common value
    const valueCounts = values.reduce((acc, value) => {
      acc[value] = (acc[value] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const maxCount = Math.max(...Object.values(valueCounts));
    const matchPercentage = (maxCount / values.length) * 100;

    // For strings, also consider similarity
    if (typeof values[0] === 'string' && values.length === 2) {
      const similarity = this.calculateStringSimilarity(values[0], values[1]);
      return Math.max(matchPercentage, similarity * 100);
    }

    return Math.max(matchPercentage, 20); // Minimum confidence
  }

  private calculateStringSimilarity(str1: string, str2: string): number {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    
    if (longer.length === 0) return 1.0;
    
    const editDistance = this.levenshteinDistance(longer, shorter);
    return (longer.length - editDistance) / longer.length;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));
    
    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;
    
    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + indicator
        );
      }
    }
    
    return matrix[str2.length][str1.length];
  }

  private generateStructuredNotes(values: any[], match: boolean, fieldName: string, comparisonType: string): string {
    if (match) {
      switch (comparisonType) {
        case '3-way': return 'All three systems match perfectly';
        case '2-way': return 'Both systems match perfectly';
        case 'single-check': return 'Value present and valid';
        default: return 'All values match perfectly';
      }
    }
    
    const uniqueValues = [...new Set(values)];
    
    // Specific notes for different field types and comparison types
    if (comparisonType === '2-way' && fieldName === 'customerName') {
      return 'Customer name differs between Order Form and Mithra/Billy system';
    }
    
    if (comparisonType === '3-way') {
      if (fieldName === 'customerName' && uniqueValues.length === 2) {
        return 'Minor formatting differences in customer name across systems';
      }
      
      if (fieldName === 'unitCost' && uniqueValues.length > 1) {
        return 'Currency formatting differences or value discrepancy across systems';
      }
      
      if (fieldName === 'serviceStartDate' && uniqueValues.length > 1) {
        return 'Different date formats or actual date differences across systems';
      }
    }
    
    if (uniqueValues.length === 2) {
      return `Minor differences detected in ${comparisonType} comparison`;
    } else if (uniqueValues.length > 2) {
      return `Multiple different values found across systems - requires investigation`;
    }
    
    return `Values differ in ${comparisonType} comparison`;
  }

  // New method for AI-powered comparison
  async compareDataWithAI(
    source1Data: ContractData,
    source2Data: ContractData,
    source3Data: ContractData | null = null,
    source4Data: ContractData | null = null,
    auditType: string = 'contract-to-invoice'
  ): Promise<ComparisonResult[]> {
    return GenAIDataMatcher.compareDataWithAI(
      source1Data,
      source2Data,
      source3Data,
      source4Data,
      auditType
    );
  }
}