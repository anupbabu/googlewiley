export interface LLMConfig {
  id: string;
  name: string;
  provider: 'openai' | 'gemini' | 'anthropic' | 'azure';
  model: string;
  apiEndpoint: string;
  apiKeyEnvVar: string;
  maxTokens: number;
  temperature: number;
  isActive: boolean;
  description: string;
  supportedFeatures: string[];
}

export class LLMConfigService {
  private static readonly STORAGE_KEY = 'llmConfigurations';

  // Default LLM configurations
  private static getDefaultConfigs(): LLMConfig[] {
    return [
      {
        id: 'gemini-pro',
        name: 'Google Gemini Pro',
        provider: 'gemini',
        model: 'gemini-1.5-flash',
        apiEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent',
        apiKeyEnvVar: 'VITE_GEMINI_API_KEY',
        maxTokens: 2048,
        temperature: 0.2,
        isActive: true,
        description: 'Google Gemini Pro - Advanced reasoning with multimodal capabilities',
        supportedFeatures: ['Data Comparison', 'Rule Extraction', 'Risk Assessment', 'Document Analysis']
      },
      {
        id: 'gemini-ultra',
        name: 'Google Gemini Ultra',
        provider: 'gemini',
        model: 'gemini-ultra',
        apiEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-ultra:generateContent',
        apiKeyEnvVar: 'VITE_GEMINI_API_KEY',
        maxTokens: 4096,
        temperature: 0.1,
        isActive: false,
        description: 'Google Gemini Ultra - Most capable model for complex tasks',
        supportedFeatures: ['Data Comparison', 'Rule Extraction', 'Risk Assessment', 'Advanced Analysis', 'Multimodal']
      },
      {
        id: 'openai-gpt4',
        name: 'OpenAI GPT-4',
        provider: 'openai',
        model: 'gpt-4',
        apiEndpoint: 'https://api.openai.com/v1/chat/completions',
        apiKeyEnvVar: 'VITE_OPENAI_API_KEY',
        maxTokens: 3000,
        temperature: 0.2,
        isActive: false,
        description: 'OpenAI GPT-4 - Most capable model for complex reasoning and analysis',
        supportedFeatures: ['Data Comparison', 'Rule Extraction', 'Risk Assessment', 'Multi-language']
      },
      {
        id: 'openai-gpt35',
        name: 'OpenAI GPT-3.5 Turbo',
        provider: 'openai',
        model: 'gpt-3.5-turbo',
        apiEndpoint: 'https://api.openai.com/v1/chat/completions',
        apiKeyEnvVar: 'VITE_OPENAI_API_KEY',
        maxTokens: 2000,
        temperature: 0.2,
        isActive: false,
        description: 'OpenAI GPT-3.5 Turbo - Fast and cost-effective for most tasks',
        supportedFeatures: ['Data Comparison', 'Rule Extraction', 'Basic Analysis']
      },
      {
        id: 'anthropic-claude',
        name: 'Anthropic Claude 3',
        provider: 'anthropic',
        model: 'claude-3-opus-20240229',
        apiEndpoint: 'https://api.anthropic.com/v1/messages',
        apiKeyEnvVar: 'VITE_ANTHROPIC_API_KEY',
        maxTokens: 3000,
        temperature: 0.2,
        isActive: false,
        description: 'Anthropic Claude 3 - Excellent for analysis and reasoning tasks',
        supportedFeatures: ['Data Comparison', 'Rule Extraction', 'Risk Assessment', 'Ethical Analysis']
      },
      {
        id: 'azure-openai',
        name: 'Azure OpenAI GPT-4',
        provider: 'azure',
        model: 'gpt-4',
        apiEndpoint: 'https://your-resource.openai.azure.com/openai/deployments/gpt-4/chat/completions?api-version=2023-12-01-preview',
        apiKeyEnvVar: 'VITE_AZURE_OPENAI_API_KEY',
        maxTokens: 3000,
        temperature: 0.2,
        isActive: false,
        description: 'Azure OpenAI GPT-4 - Enterprise-grade OpenAI with enhanced security',
        supportedFeatures: ['Data Comparison', 'Rule Extraction', 'Risk Assessment', 'Enterprise Security']
      }
    ];
  }

  static getAllConfigs(): LLMConfig[] {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (error) {
        console.error('Error parsing stored LLM configs:', error);
      }
    }
    
    const defaultConfigs = this.getDefaultConfigs();
    this.saveConfigs(defaultConfigs);
    return defaultConfigs;
  }

  static saveConfigs(configs: LLMConfig[]): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(configs));
  }

  static getActiveConfig(): LLMConfig | null {
    const configs = this.getAllConfigs();
    return configs.find(config => config.isActive) || null;
  }

  static setActiveConfig(configId: string): void {
    const configs = this.getAllConfigs();
    
    // Deactivate all configs
    configs.forEach(config => {
      config.isActive = false;
    });
    
    // Activate the selected config
    const targetConfig = configs.find(config => config.id === configId);
    if (targetConfig) {
      targetConfig.isActive = true;
    }
    
    this.saveConfigs(configs);
  }

  static updateConfig(updatedConfig: LLMConfig): void {
    const configs = this.getAllConfigs();
    const index = configs.findIndex(config => config.id === updatedConfig.id);
    
    if (index >= 0) {
      configs[index] = updatedConfig;
      this.saveConfigs(configs);
    }
  }

  static addConfig(newConfig: LLMConfig): void {
    const configs = this.getAllConfigs();
    configs.push(newConfig);
    this.saveConfigs(configs);
  }

  static deleteConfig(configId: string): void {
    const configs = this.getAllConfigs();
    const filtered = configs.filter(config => config.id !== configId);
    this.saveConfigs(filtered);
  }

  static validateConfig(config: Partial<LLMConfig>): string[] {
    const errors: string[] = [];
    
    if (!config.name?.trim()) {
      errors.push('Configuration name is required');
    }
    
    if (!config.provider) {
      errors.push('Provider is required');
    }
    
    if (!config.model?.trim()) {
      errors.push('Model name is required');
    }
    
    if (!config.apiEndpoint?.trim()) {
      errors.push('API endpoint is required');
    }
    
    if (!config.apiKeyEnvVar?.trim()) {
      errors.push('API key environment variable is required');
    }
    
    if (config.maxTokens && (config.maxTokens < 100 || config.maxTokens > 10000)) {
      errors.push('Max tokens must be between 100 and 10,000');
    }
    
    if (config.temperature && (config.temperature < 0 || config.temperature > 2)) {
      errors.push('Temperature must be between 0 and 2');
    }
    
    return errors;
  }

  static testConnection(config: LLMConfig): Promise<{ success: boolean; message: string }> {
    return new Promise((resolve) => {
      // Simulate API connection test
      setTimeout(() => {
        const apiKey = import.meta.env[config.apiKeyEnvVar];
        
        if (!apiKey) {
          resolve({
            success: false,
            message: `API key not found in environment variable: ${config.apiKeyEnvVar}`
          });
          return;
        }
        
        // Simulate connection test (in real implementation, make actual API call)
        const success = Math.random() > 0.2; // 80% success rate for demo
        
        resolve({
          success,
          message: success 
            ? `Successfully connected to ${config.name}` 
            : `Failed to connect to ${config.name}. Please check your API key and endpoint.`
        });
      }, 1500);
    });
  }

  static getProviderIcon(provider: string): string {
    switch (provider) {
      case 'openai': return '🤖';
      case 'gemini': return '💎';
      case 'anthropic': return '🧠';
      case 'azure': return '☁️';
      default: return '🔧';
    }
  }

  static getProviderColor(provider: string): string {
    switch (provider) {
      case 'openai': return 'bg-green-100 text-green-800 border-green-200';
      case 'gemini': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'anthropic': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'azure': return 'bg-cyan-100 text-cyan-800 border-cyan-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  }

  static exportConfigs(): string {
    const configs = this.getAllConfigs();
    return JSON.stringify(configs, null, 2);
  }

  static importConfigs(jsonData: string): { success: boolean; message: string; imported?: number } {
    try {
      const importedConfigs = JSON.parse(jsonData);
      
      if (!Array.isArray(importedConfigs)) {
        return { success: false, message: 'Invalid format: Expected an array of configurations' };
      }
      
      const validConfigs = importedConfigs.filter(config => {
        const errors = this.validateConfig(config);
        return errors.length === 0;
      });
      
      if (validConfigs.length === 0) {
        return { success: false, message: 'No valid configurations found in import data' };
      }
      
      // Merge with existing configs
      const existingConfigs = this.getAllConfigs();
      const mergedConfigs = [...existingConfigs];
      
      validConfigs.forEach(importedConfig => {
        const existingIndex = mergedConfigs.findIndex(config => config.id === importedConfig.id);
        if (existingIndex >= 0) {
          // Update existing
          mergedConfigs[existingIndex] = importedConfig;
        } else {
          // Add new
          mergedConfigs.push(importedConfig);
        }
      });
      
      this.saveConfigs(mergedConfigs);
      
      return {
        success: true,
        message: `Successfully imported ${validConfigs.length} configurations`,
        imported: validConfigs.length
      };
    } catch (error) {
      return {
        success: false,
        message: `Import failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
}