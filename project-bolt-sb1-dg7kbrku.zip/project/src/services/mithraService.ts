import { ContractData } from '../types/audit';

// Simulates Mithra/Billy System API integration with Google Workspace aligned data
export class MithraService {
  private static readonly BASE_URL = 'https://api.mithra-billy.example.com';
  
  static async fetchBillingData(contractNumber: string): Promise<ContractData> {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    // Simulate potential API failures
    if (Math.random() > 0.94) {
      throw new Error('Mithra/Billy System API connection timeout');
    }
    
    // Mock Mithra/Billy response aligned with Google Workspace Order Form
    const mockMithraData: ContractData = {
      soldToParty: 'Virtusa Consulting Services Private Limited',
      billingParty: 'Virtusa Consulting Services Pvt Ltd - Finance Department',
      
      // Legacy fields for backward compatibility
      customerName: 'Virtusa Consulting Services Private Limited',
      contractNumber: contractNumber,
      contractValue: '₹2,575,800.00',
      billingFrequency: 'Monthly in Advance',
      currency: 'INR'
    };

    // Simulate Mithra/Billy data variations based on contract
    if (contractNumber === 'Q-259105') {
      // Simulate minor billing system variations
      if (Math.random() > 0.8) {
        mockMithraData.soldToParty = 'Virtusa Consulting Services Pvt Ltd'; // Abbreviated
        mockMithraData.customerName = 'Virtusa Consulting Services Pvt Ltd';
      }
      
      if (Math.random() > 0.7) {
        mockMithraData.billingParty = 'Virtusa Finance Department'; // Simplified
      }
      
      if (Math.random() > 0.9) {
        mockMithraData.billingFrequency = 'Monthly'; // Simplified format
      }
    }

    return mockMithraData;
  }
  
  static async fetchBillingHistory(contractNumber: string): Promise<any[]> {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Return mock billing history aligned with Google Workspace contract
    const monthlyAmount = '₹214,650.00'; // Total / 12 months
    
    return [
      {
        invoiceNumber: 'INV-GWS-2025-001',
        billingDate: '2025-03-31',
        amount: monthlyAmount,
        status: 'Pending',
        description: 'Google Workspace Enterprise Plus - Month 1'
      },
      {
        invoiceNumber: 'INV-GWS-2025-002',
        billingDate: '2025-04-30',
        amount: monthlyAmount,
        status: 'Scheduled',
        description: 'Google Workspace Enterprise Plus - Month 2'
      },
      {
        invoiceNumber: 'INV-GWS-2025-003',
        billingDate: '2025-05-31',
        amount: monthlyAmount,
        status: 'Scheduled',
        description: 'Google Workspace Enterprise Plus - Month 3'
      }
    ];
  }
  
  static async fetchCustomerBillingProfile(customerName: string): Promise<any> {
    await new Promise(resolve => setTimeout(resolve, 600));
    
    return {
      customerName: 'Virtusa Consulting Services Private Limited',
      billingContact: {
        name: 'MoXXXXXh SalXXXXman KaXXXXe',
        email: 'salmankaleemm@Virtusa.com',
        phone: '+91 80081 11076',
        address: {
          line1: 'Plot No.10, Sy No.115',
          line2: 'Nanakramguda Village',
          city: 'Hyderabad',
          state: 'Telangana',
          postalCode: '500018',
          country: 'India'
        }
      },
      paymentTerms: 'Monthly in Advance',
      currency: 'INR',
      taxId: 'GSTIN-VIRTUSA-001',
      billingCycle: 'Monthly',
      preferredPaymentMethod: 'Bank Transfer'
    };
  }
}