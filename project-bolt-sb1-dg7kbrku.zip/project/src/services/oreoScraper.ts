import { ContractData } from '../types/audit';

// Simulates screen scraping from OREO UI with Google Workspace aligned data
export class OreoScraper {
  static async scrapeContractData(contractNumber: string): Promise<ContractData> {
    // Simulate scraping delay
    await new Promise(resolve => setTimeout(resolve, 1800));
    
    // Simulate potential scraping failures
    if (Math.random() > 0.92) {
      throw new Error('Unable to locate contract data on OREO UI');
    }
    
    // Mock scraped data aligned with Google Workspace Order Form
    const mockOreoData: ContractData = {
      solutionQuoteNumber: contractNumber.replace('Q-', 'SQN-'),
      soldToParty: 'Virtusa Consulting Services Private Limited',
      product: 'Google Workspace Enterprise Plus',
      productId: 'GAPPS-ENT-PLUS-1USER-1MO',
      operationType: 'New',
      serviceStartDate: '31/03/2025', // Different date format from UI
      serviceEndDate: '30/03/2027',
      quantity: '27,000',
      lineAmount: '₹2,650.00',
      duration: '24M OD',
      
      // Legacy fields for backward compatibility
      contractNumber: contractNumber,
      customerName: 'Virtusa Consulting Services Private Limited',
      contractValue: '₹2,575,800.00',
      startDate: '31/03/2025',
      endDate: '30/03/2027',
      paymentTerms: 'Monthly in Advance',
      serviceDescription: 'Google Workspace Enterprise Plus License and Support Services',
      billingFrequency: 'Monthly in Advance',
      currency: 'INR'
    };

    // Simulate UI scraping variations based on contract
    if (contractNumber === 'Q-259105') {
      // Simulate minor UI formatting differences
      if (Math.random() > 0.6) {
        mockOreoData.serviceStartDate = '03/31/2025'; // US date format
        mockOreoData.serviceEndDate = '03/30/2027';
        mockOreoData.startDate = '03/31/2025';
        mockOreoData.endDate = '03/30/2027';
      }
      
      if (Math.random() > 0.7) {
        mockOreoData.soldToParty = 'Virtusa Consulting Services Pvt. Ltd.'; // Abbreviated
        mockOreoData.customerName = 'Virtusa Consulting Services Pvt. Ltd.';
      }
      
      if (Math.random() > 0.8) {
        mockOreoData.lineAmount = '2650.00 INR'; // Different currency position
        mockOreoData.contractValue = '2575800.00 INR';
      }
    }

    return mockOreoData;
  }
  
  static generateSamplePage(contractData: ContractData): string {
    return `
      <div class="oreo-contract-details">
        <h1>Google Workspace Contract Information</h1>
        <div class="contract-header">
          <span class="solution-quote-number">${contractData.solutionQuoteNumber}</span>
          <span class="sold-to-party">${contractData.soldToParty}</span>
        </div>
        <div class="product-details">
          <div class="product">${contractData.product}</div>
          <div class="product-id">${contractData.productId}</div>
          <div class="operation-type">${contractData.operationType}</div>
          <div class="line-amount">${contractData.lineAmount}</div>
          <div class="quantity">${contractData.quantity}</div>
        </div>
        <div class="service-period">
          <span class="start-date">${contractData.serviceStartDate}</span>
          <span class="end-date">${contractData.serviceEndDate}</span>
          <span class="duration">${contractData.duration}</span>
        </div>
        <div class="billing-info">
          <span class="billing-frequency">${contractData.billingFrequency}</span>
          <span class="currency">${contractData.currency}</span>
        </div>
      </div>
    `;
  }
}