import { AuditType } from '../types/audit';

export interface PromptTemplate {
  id: string;
  name: string;
  category: AuditType | 'general' | 'validation';
  section: string; // e.g., 'order-processed', 'booking-terms', 'billing-systems'
  description: string;
  prompt: string;
  variables: string[]; // Variables that can be substituted in the prompt
  tags: string[]; // Tags for categorization and filtering
  lastModified: string;
  version: number;
  isActive: boolean;
}

export class PromptLibraryService {
  private static readonly STORAGE_KEY = 'promptLibrary';

  // Default prompts for different sections
  private static getDefaultPrompts(): PromptTemplate[] {
    return [
      {
        id: 'order-processed-comparison',
        name: 'Order Has Been Processed - Data Comparison',
        category: 'contract-to-provisioning',
        section: 'order-processed',
        description: 'Compares order processing data across PDF, SAP, and OREO systems to verify order completion',
        prompt: `You are analyzing contract data to verify that an order has been properly processed across all systems.

ANALYSIS FOCUS: Order Processing Verification
Compare the following fields across Order Form, SAP system, and OREO UI:

CRITICAL FIELDS TO ANALYZE:
- Quote ID / Solution Quote Number
- Customer Name / Sold to Party
- Product Name and Product ID
- Operation Type (New/Renewal/Amendment)
- Service Start and End Dates
- Order Term Duration
- Quantity (user licenses)
- Unit Cost / Line Amount

BUSINESS RULES:
1. Quote IDs: Q-XXXXXX (Order Form) should match SQN-XXXXXX (SAP/OREO) - same base number
2. Customer names: Allow for standard business abbreviations (Pvt Ltd vs Private Limited)
3. Product information: Must match exactly - critical for provisioning
4. Financial amounts: Must match within 1% tolerance
5. Dates: Allow different formats but must represent same calendar dates
6. Quantities: Must match exactly for licensing compliance

RISK ASSESSMENT:
- Critical: Wrong customer, wrong product, significant amount differences (>5%)
- High: Wrong service dates, wrong quantities, wrong operation type
- Medium: Minor formatting differences, acceptable abbreviations
- Low: Date format variations, currency symbol differences

Variables: {source1Data}, {source2Data}, {source3Data}, {auditType}

Provide detailed analysis with business context and actionable recommendations.`,
        variables: ['source1Data', 'source2Data', 'source3Data', 'auditType'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      },
      {
        id: 'booking-terms-comparison',
        name: 'Terms of Booking vs Order Form Amendment',
        category: 'contract-to-booking',
        section: 'booking-terms',
        description: 'Validates booking terms and billing arrangements match between systems',
        prompt: `You are analyzing contract data to ensure booking terms and billing arrangements are consistent.

ANALYSIS FOCUS: Booking Terms and Billing Validation
Compare booking terms and billing information across systems:

KEY VALIDATION POINTS:
- Billing Frequency (Monthly, Quarterly, Annual)
- Payment Terms and Conditions
- Order Term Duration consistency
- Contract Value calculations
- Currency and pricing alignment

BUSINESS RULES:
1. Billing frequency must be consistent across all systems
2. Order terms should align with service period
3. Contract values should match within acceptable tolerance
4. Payment terms must be clearly defined and consistent

RISK ASSESSMENT:
- Critical: Mismatched billing frequency, wrong contract values
- High: Inconsistent payment terms, currency mismatches
- Medium: Minor term variations, formatting differences
- Low: Acceptable business language variations

Variables: {billingData}, {contractTerms}, {orderForm}

Focus on financial accuracy and billing compliance.`,
        variables: ['billingData', 'contractTerms', 'orderForm'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      },
      {
        id: 'billing-systems-comparison',
        name: 'Mithra/Google Admin/Billy Systems Reflection',
        category: 'contract-to-invoice',
        section: 'billing-systems',
        description: 'Verifies that billing systems accurately reflect contract details',
        prompt: `You are analyzing whether billing systems (Mithra/Billy) accurately reflect the contract details.

ANALYSIS FOCUS: Billing System Accuracy
Verify that billing systems contain accurate contract information:

BILLING SYSTEM VALIDATION:
- Customer information consistency
- Billing party and sold-to party alignment
- Billing frequency and payment terms
- Contract value and pricing accuracy
- Service period alignment

BUSINESS RULES:
1. Customer names may have variations but must represent same entity
2. Billing party may differ from sold-to party (internal vs external billing)
3. Billing frequency must match contract terms exactly
4. Financial amounts must be accurate for revenue recognition

RISK ASSESSMENT:
- Critical: Wrong customer in billing system, incorrect billing amounts
- High: Wrong billing frequency, mismatched service periods
- Medium: Minor customer name variations, billing party differences
- Low: Formatting differences in addresses or contact information

Variables: {contractData}, {billingSystemData}, {customerInfo}

Ensure billing accuracy and compliance with contract terms.`,
        variables: ['contractData', 'billingSystemData', 'customerInfo'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      },
      {
        id: 'risk-assessment-general',
        name: 'General Risk Assessment',
        category: 'general',
        section: 'general',
        description: 'General risk assessment framework for contract data discrepancies',
        prompt: `You are performing a comprehensive risk assessment of contract data discrepancies.

RISK ASSESSMENT FRAMEWORK:

CRITICAL RISKS (Immediate Action Required):
- Wrong customer entity (legal/billing implications)
- Wrong product or service (provisioning/licensing issues)
- Significant financial discrepancies (>5% variance)
- Missing or incorrect regulatory compliance data

HIGH RISKS (Urgent Review Required):
- Service date mismatches (SLA/delivery impact)
- Quantity discrepancies (licensing/capacity issues)
- Wrong operation type (billing/renewal impact)
- Payment term inconsistencies

MEDIUM RISKS (Review Recommended):
- Minor financial variances (1-5%)
- Formatting inconsistencies
- Non-critical field mismatches
- Documentation gaps

LOW RISKS (Monitor):
- Acceptable business abbreviations
- Date format variations (same date)
- Currency symbol differences
- Minor contact information variations

Variables: {discrepancies}, {businessImpact}, {complianceRequirements}

Provide prioritized recommendations based on business impact.`,
        variables: ['discrepancies', 'businessImpact', 'complianceRequirements'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      },
      {
        id: 'validation-rules-extraction',
        name: 'Validation Rules Extraction',
        category: 'general',
        section: 'rules-extraction',
        description: 'Extracts validation rules from knowledge documents',
        prompt: `You are extracting validation rules from knowledge documents for contract compliance.

RULE EXTRACTION GUIDELINES:

FIELD VALIDATION RULES:
- Format requirements (IDs, dates, currencies)
- Value constraints (ranges, allowed values)
- Pattern matching (regex patterns)
- Cross-field dependencies

BUSINESS LOGIC RULES:
- Approval workflows and thresholds
- Compliance requirements
- Data consistency rules
- Exception handling procedures

TOLERANCE RULES:
- Acceptable variance ranges
- Rounding tolerances
- Currency conversion rules
- Date format variations

PRIORITY CLASSIFICATION:
- High: Regulatory compliance, financial accuracy
- Medium: Operational efficiency, data quality
- Low: Formatting consistency, documentation

Variables: {knowledgeContent}, {documentType}, {complianceStandards}

Extract actionable, specific validation rules with clear criteria.`,
        variables: ['knowledgeContent', 'documentType', 'complianceStandards'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      },
      {
        id: 'approval-workflow-validation',
        name: 'Approval Workflow Compliance Check',
        category: 'validation',
        section: 'approval-workflow',
        description: 'Validates approval workflow compliance with organizational policies',
        prompt: `You are analyzing approval workflow data to ensure compliance with organizational policies.

ANALYSIS FOCUS: Approval Workflow Compliance
Verify that approval processes follow established organizational policies:

VALIDATION POINTS:
- Approval authority levels
- Required approval sequence
- Policy compliance checks
- Documentation requirements
- Escalation procedures

BUSINESS RULES:
1. Approvals must be from authorized personnel
2. Approval sequence must follow policy hierarchy
3. All required approvals must be obtained
4. Documentation must be complete and accurate

Variables: {approvalData}, {policyRequirements}, {workflowData}

Focus on policy compliance and approval authority validation.`,
        variables: ['approvalData', 'policyRequirements', 'workflowData'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      },
      {
        id: 'contract-alignment-check',
        name: 'Contract Alignment Verification',
        category: 'validation',
        section: 'contract-alignment',
        description: 'Verifies that approved terms match final contract details',
        prompt: `You are analyzing contract data to ensure approved terms match the final contract.

ANALYSIS FOCUS: Contract Alignment Verification
Compare approved terms with final contract to ensure consistency:

VALIDATION POINTS:
- Financial terms alignment
- Service specifications matching
- Timeline consistency
- Terms and conditions alignment
- Amendment tracking

BUSINESS RULES:
1. Contract values must match approved amounts
2. Service terms must align with approval
3. Any changes require re-approval
4. Amendment history must be documented

Variables: {approvedTerms}, {contractData}, {amendmentHistory}

Ensure contract terms match approved specifications.`,
        variables: ['approvedTerms', 'contractData', 'amendmentHistory'],
        tags: [],
        lastModified: new Date().toISOString(),
        version: 1,
        isActive: true
      }
    ];
  }

  static getAllPrompts(): PromptTemplate[] {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (error) {
        console.error('Error parsing stored prompts:', error);
        // Return default prompts if parsing fails
        const defaultPrompts = this.getDefaultPrompts();
        this.savePrompts(defaultPrompts);
        return defaultPrompts;
      }
    }
    
    // Return default prompts if none stored
    const defaultPrompts = this.getDefaultPrompts();
    this.savePrompts(defaultPrompts);
    return defaultPrompts;
  }

  static savePrompts(prompts: PromptTemplate[]): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(prompts));
  }

  static getPromptById(id: string): PromptTemplate | null {
    const prompts = this.getAllPrompts();
    return prompts.find(p => p.id === id) || null;
  }

  static getPromptsByCategory(category: PromptTemplate['category']): PromptTemplate[] {
    const prompts = this.getAllPrompts();
    return prompts.filter(p => p.category === category);
  }

  static getPromptsBySection(section: string): PromptTemplate[] {
    const prompts = this.getAllPrompts();
    return prompts.filter(p => p.section === section);
  }

  static savePrompt(prompt: PromptTemplate): void {
    const prompts = this.getAllPrompts();
    const existingIndex = prompts.findIndex(p => p.id === prompt.id);
    
    if (existingIndex >= 0) {
      // Update existing prompt
      prompts[existingIndex] = {
        ...prompt,
        lastModified: new Date().toISOString(),
        version: prompts[existingIndex].version + 1
      };
    } else {
      // Add new prompt
      prompts.push({
        ...prompt,
        lastModified: new Date().toISOString(),
        version: 1
      });
    }
    
    this.savePrompts(prompts);
  }

  static deletePrompt(id: string): void {
    const prompts = this.getAllPrompts();
    const filtered = prompts.filter(p => p.id !== id);
    this.savePrompts(filtered);
  }

  static duplicatePrompt(id: string): PromptTemplate | null {
    const original = this.getPromptById(id);
    if (!original) return null;

    const duplicate: PromptTemplate = {
      ...original,
      id: `${original.id}_copy_${Date.now()}`,
      name: `${original.name} (Copy)`,
      lastModified: new Date().toISOString(),
      version: 1
    };

    this.savePrompt(duplicate);
    return duplicate;
  }

  static getActivePromptForSection(section: string): PromptTemplate | null {
    const prompts = this.getPromptsBySection(section);
    return prompts.find(p => p.isActive) || null;
  }

  static setActivePrompt(id: string, section: string): void {
    const prompts = this.getAllPrompts();
    
    // Deactivate all prompts in the section
    prompts.forEach(p => {
      if (p.section === section) {
        p.isActive = false;
      }
    });
    
    // Activate the selected prompt
    const targetPrompt = prompts.find(p => p.id === id);
    if (targetPrompt) {
      targetPrompt.isActive = true;
    }
    
    this.savePrompts(prompts);
  }

  static validatePrompt(prompt: Partial<PromptTemplate>): string[] {
    const errors: string[] = [];
    
    if (!prompt.name?.trim()) {
      errors.push('Prompt name is required');
    }
    
    if (!prompt.prompt?.trim()) {
      errors.push('Prompt content is required');
    }
    
    if (!prompt.section?.trim()) {
      errors.push('Section is required');
    }
    
    if (!prompt.category) {
      errors.push('Category is required');
    }
    
    if (prompt.prompt && prompt.prompt.length > 10000) {
      errors.push('Prompt content is too long (max 10,000 characters)');
    }
    
    return errors;
  }

  static exportPrompts(): string {
    const prompts = this.getAllPrompts();
    return JSON.stringify(prompts, null, 2);
  }

  static importPrompts(jsonData: string): { success: boolean; message: string; imported?: number } {
    try {
      const importedPrompts = JSON.parse(jsonData);
      
      if (!Array.isArray(importedPrompts)) {
        return { success: false, message: 'Invalid format: Expected an array of prompts' };
      }
      
      const validPrompts = importedPrompts.filter(p => {
        const errors = this.validatePrompt(p);
        return errors.length === 0;
      });
      
      if (validPrompts.length === 0) {
        return { success: false, message: 'No valid prompts found in import data' };
      }
      
      // Merge with existing prompts
      const existingPrompts = this.getAllPrompts();
      const mergedPrompts = [...existingPrompts];
      
      validPrompts.forEach(importedPrompt => {
        const existingIndex = mergedPrompts.findIndex(p => p.id === importedPrompt.id);
        if (existingIndex >= 0) {
          // Update existing
          mergedPrompts[existingIndex] = {
            ...importedPrompt,
            lastModified: new Date().toISOString(),
            version: mergedPrompts[existingIndex].version + 1
          };
        } else {
          // Add new
          mergedPrompts.push({
            ...importedPrompt,
            lastModified: new Date().toISOString(),
            version: 1
          });
        }
      });
      
      this.savePrompts(mergedPrompts);
      
      return {
        success: true,
        message: `Successfully imported ${validPrompts.length} prompts`,
        imported: validPrompts.length
      };
    } catch (error) {
      return {
        success: false,
        message: `Import failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
}