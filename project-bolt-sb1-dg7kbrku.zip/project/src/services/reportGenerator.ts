import { AuditReport, ComparisonResult, DataSource, AuditType } from '../types/audit';
import { AuditTypeService } from '../data/auditTypes';

export class ReportGenerator {
  static generateReport(
    auditId: string,
    contractNumber: string,
    auditType: AuditType,
    dataSources: DataSource[],
    comparisons: ComparisonResult[],
    aiAgentId?: string
  ): AuditReport {
    const summary = this.calculateSummary(comparisons);
    const overallStatus = this.determineOverallStatus(summary);

    return {
      auditId,
      aiAgentId,
      timestamp: new Date().toISOString(),
      contractNumber,
      auditType,
      dataSources,
      comparisons,
      overallStatus,
      summary
    };
  }

  static generateHTMLReport(report: AuditReport): string {
    const auditConfig = AuditTypeService.getAuditTypeConfig(report.auditType);
    
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compliance Audit Report - ${report.auditId}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        .header { background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .ids-section { background: #e3f2fd; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #1976d2; }
        .audit-type { background: #e3f2fd; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #2196f3; }
        .status-pass { color: #28a745; }
        .status-fail { color: #dc3545; }
        .status-warning { color: #ffc107; }
        .comparison-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        .comparison-table th, .comparison-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        .comparison-table th { background-color: #f8f9fa; }
        .match-true { background-color: #d4edda; }
        .match-false { background-color: #f8d7da; }
        .summary-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0; }
        .summary-card { background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; }
        .id-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
        .id-card { background: #ffffff; padding: 12px; border-radius: 6px; border: 1px solid #e0e0e0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Compliance Audit Report</h1>
        <p><strong>Contract Number:</strong> ${report.contractNumber}</p>
        <p><strong>Generated:</strong> ${new Date(report.timestamp).toLocaleString()}</p>
        <p><strong>Overall Status:</strong> <span class="status-${report.overallStatus}">${report.overallStatus.toUpperCase()}</span></p>
    </div>

    <div class="ids-section">
        <h3>System Identifiers</h3>
        <div class="id-grid">
            <div class="id-card">
                <strong>Audit ID:</strong><br>
                <code>${report.auditId}</code>
            </div>
            <div class="id-card">
                <strong>AI Agent ID:</strong><br>
                <code>${report.aiAgentId || 'N/A'}</code>
            </div>
        </div>
    </div>

    <div class="audit-type">
        <h3>${auditConfig.name}</h3>
        <p>${auditConfig.description}</p>
        <p><strong>Data Sources:</strong> ${auditConfig.dataSources.primary} → ${auditConfig.dataSources.secondary}${auditConfig.dataSources.tertiary ? ` → ${auditConfig.dataSources.tertiary}` : ''}</p>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <h3>${report.summary.totalChecks}</h3>
            <p>Total Checks</p>
        </div>
        <div class="summary-card">
            <h3 class="status-pass">${report.summary.passed}</h3>
            <p>Passed</p>
        </div>
        <div class="summary-card">
            <h3 class="status-fail">${report.summary.failed}</h3>
            <p>Failed</p>
        </div>
        <div class="summary-card">
            <h3 class="status-warning">${report.summary.warnings}</h3>
            <p>Warnings</p>
        </div>
    </div>

    <h2>Data Source Status</h2>
    <table class="comparison-table">
        <thead>
            <tr>
                <th>Source</th>
                <th>Type</th>
                <th>Status</th>
                <th>Extracted At</th>
            </tr>
        </thead>
        <tbody>
            ${report.dataSources.map(source => `
                <tr>
                    <td>${source.name}</td>
                    <td>${source.type.toUpperCase()}</td>
                    <td class="status-${source.status}">${source.status}</td>
                    <td>${source.extractedAt || 'N/A'}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>

    <h2>Field Comparison Results</h2>
    <table class="comparison-table">
        <thead>
            <tr>
                <th>Field</th>
                <th>${auditConfig.dataSources.primary}</th>
                <th>${auditConfig.dataSources.secondary}</th>
                ${auditConfig.dataSources.tertiary ? `<th>${auditConfig.dataSources.tertiary}</th>` : ''}
                <th>Match</th>
                <th>Confidence</th>
                <th>Notes</th>
            </tr>
        </thead>
        <tbody>
            ${report.comparisons.map(comp => `
                <tr class="match-${comp.match}">
                    <td><strong>${comp.field}</strong></td>
                    <td>${comp.source1Value}</td>
                    <td>${comp.source2Value}</td>
                    ${auditConfig.dataSources.tertiary ? `<td>${comp.source3Value}</td>` : ''}
                    <td>${comp.match ? '✓' : '✗'}</td>
                    <td>${comp.confidence}%</td>
                    <td>${comp.notes || ''}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>

    <div style="margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
        <h3>Audit Conclusion</h3>
        <p>This automated compliance audit (${auditConfig.name}) has completed the comparison of data across the specified systems. 
        ${report.overallStatus === 'pass' ? 'All critical checks have passed successfully.' : 
          report.overallStatus === 'fail' ? 'Critical discrepancies have been identified that require immediate attention.' :
          'Some warnings have been identified that should be reviewed.'}</p>
        ${report.aiAgentId ? `<p><strong>AI Analysis:</strong> This report was generated using AI Agent ${report.aiAgentId} for intelligent data comparison and risk assessment.</p>` : ''}
    </div>
</body>
</html>
    `;
  }

  static downloadReport(report: AuditReport, format: 'pdf' | 'json' = 'pdf'): void {
    if (format === 'pdf') {
      this.generatePDFReport(report);
    } else {
      // JSON download
      const content = JSON.stringify(report, null, 2);
      const blob = new Blob([content], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `audit-report-${report.auditId}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }

  private static generatePDFReport(report: AuditReport): void {
    // Check if html2pdf is available
    if (typeof (window as any).html2pdf === 'undefined') {
      console.error('html2pdf library not loaded. Falling back to JSON download.');
      alert('PDF generation library not available. Downloading as JSON instead.');
      this.downloadReport(report, 'json');
      return;
    }

    try {
      // Generate HTML content for PDF
      const htmlContent = this.generateHTMLReport(report);
      
      // Create a temporary container with the HTML content
      const container = document.createElement('div');
      container.innerHTML = htmlContent;
      container.style.cssText = `
        position: fixed;
        top: -9999px;
        left: -9999px;
        width: 8.5in;
        background: white;
        font-family: Arial, sans-serif;
        line-height: 1.6;
        padding: 0.5in;
      `;
      
      document.body.appendChild(container);
      
      // Configure PDF options
      const opt = {
        margin: [0.5, 0.5, 0.5, 0.5],
        filename: `audit-report-${report.auditId}.pdf`,
        image: { 
          type: 'jpeg', 
          quality: 0.95 
        },
        html2canvas: { 
          scale: 1.5,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff',
          logging: false,
          letterRendering: true
        },
        jsPDF: { 
          unit: 'in', 
          format: 'letter', 
          orientation: 'portrait',
          compress: true
        },
        pagebreak: { 
          mode: ['avoid-all', 'css', 'legacy'] 
        }
      };
      
      // Generate PDF
      (window as any).html2pdf()
        .set(opt)
        .from(container)
        .save()
        .then(() => {
          console.log('PDF generated successfully');
          document.body.removeChild(container);
        })
        .catch((error: any) => {
          console.error('PDF generation failed:', error);
          document.body.removeChild(container);
          
          // Try alternative method
          this.generatePDFAlternative(report);
        });
        
    } catch (error) {
      console.error('Error in PDF generation setup:', error);
      this.generatePDFAlternative(report);
    }
  }

  private static generatePDFAlternative(report: AuditReport): void {
    console.log('Trying alternative PDF generation method...');
    
    try {
      // Use browser's print functionality as fallback
      const printContent = this.generatePrintableHTML(report);
      
      // Create a new window for printing
      const printWindow = window.open('', '_blank', 'width=800,height=600');
      if (!printWindow) {
        throw new Error('Could not open print window');
      }
      
      printWindow.document.write(printContent);
      printWindow.document.close();
      
      // Wait for content to load
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          
          // Close the window after a delay
          setTimeout(() => {
            printWindow.close();
          }, 1000);
        }, 500);
      };
      
      // Show user message
      alert('PDF generation library had issues. A print dialog has been opened. Please save as PDF from the print dialog.');
      
    } catch (error) {
      console.error('Alternative PDF generation failed:', error);
      this.generateSimplePDF(report);
    }
  }

  private static generatePrintableHTML(report: AuditReport): string {
    const auditConfig = AuditTypeService.getAuditTypeConfig(report.auditType);
    
    return `
<!DOCTYPE html>
<html>
<head>
    <title>Audit Report - ${report.auditId}</title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            line-height: 1.4; 
            font-size: 12px;
        }
        h1 { color: #333; font-size: 18px; margin-bottom: 10px; }
        h2 { color: #555; font-size: 14px; margin: 15px 0 8px 0; }
        h3 { color: #666; font-size: 12px; margin: 10px 0 5px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 10px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background-color: #f5f5f5; font-weight: bold; }
        .header { background: #f8f9fa; padding: 15px; margin-bottom: 15px; }
        .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 15px 0; }
        .summary-card { background: #f8f9fa; padding: 10px; text-align: center; border: 1px solid #ddd; }
        .match-true { background-color: #d4edda; }
        .match-false { background-color: #f8d7da; }
        .status-pass { color: #28a745; font-weight: bold; }
        .status-fail { color: #dc3545; font-weight: bold; }
        .status-warning { color: #ffc107; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Compliance Audit Report</h1>
        <p><strong>Audit ID:</strong> ${report.auditId}</p>
        <p><strong>AI Agent ID:</strong> ${report.aiAgentId || 'N/A'}</p>
        <p><strong>Contract Number:</strong> ${report.contractNumber}</p>
        <p><strong>Generated:</strong> ${new Date(report.timestamp).toLocaleString()}</p>
        <p><strong>Audit Type:</strong> ${auditConfig.name}</p>
        <p><strong>Overall Status:</strong> <span class="status-${report.overallStatus}">${report.overallStatus.toUpperCase()}</span></p>
    </div>

    <div class="summary">
        <div class="summary-card">
            <div style="font-size: 16px; font-weight: bold;">${report.summary.totalChecks}</div>
            <div>Total Checks</div>
        </div>
        <div class="summary-card">
            <div style="font-size: 16px; font-weight: bold; color: #28a745;">${report.summary.passed}</div>
            <div>Passed</div>
        </div>
        <div class="summary-card">
            <div style="font-size: 16px; font-weight: bold; color: #dc3545;">${report.summary.failed}</div>
            <div>Failed</div>
        </div>
        <div class="summary-card">
            <div style="font-size: 16px; font-weight: bold; color: #ffc107;">${report.summary.warnings}</div>
            <div>Warnings</div>
        </div>
    </div>

    <h2>Field Comparison Results</h2>
    <table>
        <thead>
            <tr>
                <th>Field</th>
                <th>${auditConfig.dataSources.primary}</th>
                <th>${auditConfig.dataSources.secondary}</th>
                ${auditConfig.dataSources.tertiary ? `<th>${auditConfig.dataSources.tertiary}</th>` : ''}
                <th>Match</th>
                <th>Confidence</th>
                <th>Notes</th>
            </tr>
        </thead>
        <tbody>
            ${report.comparisons.map(comp => `
                <tr class="match-${comp.match}">
                    <td><strong>${comp.field}</strong></td>
                    <td>${comp.source1Value || 'N/A'}</td>
                    <td>${comp.source2Value || 'N/A'}</td>
                    ${auditConfig.dataSources.tertiary ? `<td>${comp.source3Value || 'N/A'}</td>` : ''}
                    <td>${comp.match ? '✓' : '✗'}</td>
                    <td>${comp.confidence}%</td>
                    <td>${(comp.notes || '').substring(0, 100)}${comp.notes && comp.notes.length > 100 ? '...' : ''}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>

    <div style="margin-top: 30px; padding: 15px; background: #f8f9fa; border: 1px solid #ddd;">
        <h3>Audit Conclusion</h3>
        <p>This automated compliance audit (${auditConfig.name}) has completed the comparison of data across the specified systems. 
        ${report.overallStatus === 'pass' ? 'All critical checks have passed successfully.' : 
          report.overallStatus === 'fail' ? 'Critical discrepancies have been identified that require immediate attention.' :
          'Some warnings have been identified that should be reviewed.'}</p>
        ${report.aiAgentId ? `<p><strong>AI Analysis:</strong> This report was generated using AI Agent ${report.aiAgentId} for intelligent data comparison and risk assessment.</p>` : ''}
    </div>
</body>
</html>`;
  }

  private static generateSimplePDF(report: AuditReport): void {
    // Create a simple HTML structure that's guaranteed to work
    const auditConfig = AuditTypeService.getAuditTypeConfig(report.auditType);
    
    const simpleHTML = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 800px;">
        <h1 style="color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px;">
          Compliance Audit Report
        </h1>
        
        <div style="background: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px;">
          <h3>Report Information</h3>
          <p><strong>Audit ID:</strong> ${report.auditId}</p>
          <p><strong>AI Agent ID:</strong> ${report.aiAgentId || 'N/A'}</p>
          <p><strong>Contract Number:</strong> ${report.contractNumber}</p>
          <p><strong>Generated:</strong> ${new Date(report.timestamp).toLocaleString()}</p>
          <p><strong>Audit Type:</strong> ${auditConfig.name}</p>
          <p><strong>Overall Status:</strong> ${report.overallStatus.toUpperCase()}</p>
        </div>
        
        <div style="background: #e3f2fd; padding: 15px; margin: 20px 0; border-radius: 5px;">
          <h3>Summary</h3>
          <p><strong>Total Checks:</strong> ${report.summary.totalChecks}</p>
          <p><strong>Passed:</strong> ${report.summary.passed}</p>
          <p><strong>Failed:</strong> ${report.summary.failed}</p>
          <p><strong>Warnings:</strong> ${report.summary.warnings}</p>
        </div>
        
        <div style="margin: 20px 0;">
          <h3>Field Comparison Results</h3>
          <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
            <thead>
              <tr style="background: #f8f9fa;">
                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Field</th>
                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Match</th>
                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Confidence</th>
                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Notes</th>
              </tr>
            </thead>
            <tbody>
              ${report.comparisons.map(comp => `
                <tr style="background: ${comp.match ? '#d4edda' : '#f8d7da'};">
                  <td style="border: 1px solid #ddd; padding: 8px;">${comp.field}</td>
                  <td style="border: 1px solid #ddd; padding: 8px;">${comp.match ? '✓' : '✗'}</td>
                  <td style="border: 1px solid #ddd; padding: 8px;">${comp.confidence}%</td>
                  <td style="border: 1px solid #ddd; padding: 8px;">${comp.notes || ''}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        
        <div style="margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 5px;">
          <h3>Conclusion</h3>
          <p>This automated compliance audit has completed successfully. 
          ${report.overallStatus === 'pass' ? 'All critical checks have passed.' : 
            report.overallStatus === 'fail' ? 'Critical discrepancies require attention.' :
            'Some warnings should be reviewed.'}</p>
          ${report.aiAgentId ? `<p><strong>AI Analysis:</strong> Generated using AI Agent ${report.aiAgentId}</p>` : ''}
        </div>
      </div>
    `;
    
    // Create container for simple PDF
    const container = document.createElement('div');
    container.innerHTML = simpleHTML;
    container.style.cssText = `
      position: fixed;
      top: -9999px;
      left: -9999px;
      width: 800px;
      background: white;
      padding: 20px;
    `;
    
    document.body.appendChild(container);
    
    const opt = {
      margin: 0.5,
      filename: `audit-report-${report.auditId}.pdf`,
      image: { type: 'jpeg', quality: 0.9 },
      html2canvas: { scale: 1 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    
    (window as any).html2pdf()
      .set(opt)
      .from(container)
      .save()
      .then(() => {
        console.log('Simple PDF generated successfully');
        document.body.removeChild(container);
      })
      .catch((error: any) => {
        console.error('All PDF generation methods failed:', error);
        document.body.removeChild(container);
        alert('PDF generation failed. Downloading as JSON instead.');
        this.downloadReport(report, 'json');
      });
  }

  private static calculateSummary(comparisons: ComparisonResult[]) {
    const totalChecks = comparisons.length;
    let passed = 0;
    let failed = 0;
    let warnings = 0;

    comparisons.forEach(comp => {
      if (comp.match) {
        passed++;
      } else if (comp.confidence >= 60) {
        warnings++;
      } else {
        failed++;
      }
    });

    return { totalChecks, passed, failed, warnings };
  }

  private static determineOverallStatus(summary: any): 'pass' | 'fail' | 'warning' {
    if (summary.failed > 0) return 'fail';
    if (summary.warnings > 0) return 'warning';
    return 'pass';
  }
}