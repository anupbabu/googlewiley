import { ContractData } from '../types/audit';

// Simulates SAP API integration with Google Workspace aligned data
export class SAPApiService {
  private static readonly BASE_URL = 'https://api.sap.example.com';
  
  static async fetchContractData(contractNumber: string): Promise<ContractData> {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simulate potential API failures
    if (Math.random() > 0.95) {
      throw new Error('SAP API connection timeout');
    }
    
    // Mock SAP response aligned with Google Workspace Order Form
    const mockSAPData: ContractData = {
      solutionQuoteNumber: contractNumber.replace('Q-', 'SQN-'),
      soldToParty: 'Virtusa Consulting Services Private Limited',
      product: 'Google Workspace Enterprise Plus',
      productId: 'GAPPS-ENT-PLUS-1USER-1MO',
      operationType: 'New',
      serviceStartDate: '2025-03-31',
      serviceEndDate: '2027-03-30',
      quantity: '27,000',
      lineAmount: '₹2,650.00',
      duration: '24M OD',
      
      // Legacy fields for backward compatibility
      contractNumber: contractNumber,
      customerName: 'Virtusa Consulting Services Private Limited',
      contractValue: '₹2,575,800.00',
      startDate: '2025-03-31',
      endDate: '2027-03-30',
      paymentTerms: 'Monthly in Advance',
      serviceDescription: 'Google Workspace Enterprise Plus License & Support',
      billingFrequency: 'Monthly in Advance',
      currency: 'INR'
    };

    // Simulate SAP data variations based on contract number
    if (contractNumber === 'Q-259105') {
      // Perfect match scenario
      return mockSAPData;
    } else if (Math.random() > 0.7) {
      // Minor variations
      mockSAPData.soldToParty = 'VIRTUSA CONSULTING SERVICES PRIVATE LIMITED'; // Case difference
      mockSAPData.serviceStartDate = '31/03/2025'; // Different date format
      mockSAPData.lineAmount = 'INR 2,650.00'; // Different currency format
    }
    
    if (Math.random() > 0.8) {
      mockSAPData.quantity = '27000'; // No comma separator
      mockSAPData.duration = '24 Months OD'; // Expanded format
    }

    return mockSAPData;
  }
  
  static async searchContracts(criteria: Partial<ContractData>): Promise<ContractData[]> {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Return mock search results aligned with Google Workspace data
    return [
      {
        solutionQuoteNumber: 'SQN-259105',
        soldToParty: 'Virtusa Consulting Services Private Limited',
        product: 'Google Workspace Enterprise Plus',
        productId: 'GAPPS-ENT-PLUS-1USER-1MO',
        lineAmount: '₹2,650.00',
        serviceStartDate: '2025-03-31',
        serviceEndDate: '2027-03-30',
        quantity: '27,000',
        
        // Legacy fields
        contractNumber: 'Q-259105',
        customerName: 'Virtusa Consulting Services Private Limited',
        contractValue: '₹2,575,800.00',
        startDate: '2025-03-31',
        endDate: '2027-03-30',
        paymentTerms: 'Monthly in Advance',
        currency: 'INR'
      }
    ];
  }
}