export interface ContractData {
  // PDF Fields
  quoteId?: string;
  contractNumber?: string;
  customerName: string;
  product?: string;
  productId?: string;
  operationType?: string;
  serviceStartDate?: string;
  serviceEndDate?: string;
  orderTerm?: string;
  quantity?: string | number;
  unitCost?: string;
  billingFrequency?: string;
  
  // Legacy fields for backward compatibility
  contractValue?: string;
  startDate?: string;
  endDate?: string;
  paymentTerms?: string;
  serviceDescription?: string;
  currency?: string;
  
  // SAP specific fields
  solutionQuoteNumber?: string;
  soldToParty?: string;
  lineAmount?: string;
  duration?: string;
  
  // Mithra/Billy specific fields
  billingParty?: string;
}

// New structured data types for order form extraction
export interface OrderHeader {
  date: string; // MM/DD/YYYY format
  quoteID: string;
  pricingValidUntil: string; // MM/DD/YYYY format
  customer: string;
  customerDetails: string;
  customerBillingDetails: string;
  primaryDomain: string;
  offDomainEmail: string;
  salesRep: string;
}

export interface OrderLineItem {
  serviceName: string;
  operationType: string;
  billingFrequency: string;
  serviceStartDate: string; // MM/DD/YYYY format
  serviceEndDate: string; // MM/DD/YYYY format
  orderTerm: string;
  quantity: number;
  unitCost: number; // numeric value
  discount: string;
  totalCost: number; // numeric value
}

export interface Summary {
  totalINR: number; // numeric value
}

export interface ExtractedOrderForm {
  orderHeader: OrderHeader;
  orderLineItems: OrderLineItem[];
  summary: Summary;
  // Keep legacy ContractData for backward compatibility
  legacyData?: ContractData;
}

export interface DataSource {
  id: string;
  name: string;
  type: 'pdf' | 'sap' | 'oreo' | 'mithra';
  status: 'pending' | 'loading' | 'success' | 'error';
  data: ContractData | ExtractedOrderForm | null;
  extractedAt?: string;
  error?: string;
}

export interface MappingRule {
  id: string;
  sourceField: string;
  targetField: string;
  transformation?: 'uppercase' | 'lowercase' | 'date_format' | 'currency_format';
  required: boolean;
  tolerance?: number; // For numeric comparisons
}

export interface ComparisonResult {
  field: string;
  source1Value: any;
  source2Value: any;
  source3Value?: any;
  source4Value?: any; // For Mithra/Billy system
  match: boolean;
  confidence: number;
  notes?: string;
  riskLevel?: 'low' | 'medium' | 'high' | 'critical';
  businessImpact?: string;
}

export interface AuditReport {
  auditId: string;
  aiAgentId?: string;
  timestamp: string;
  contractNumber: string;
  auditType: AuditType;
  dataSources: DataSource[];
  comparisons: ComparisonResult[];
  overallStatus: 'pass' | 'fail' | 'warning';
  summary: {
    totalChecks: number;
    passed: number;
    failed: number;
    warnings: number;
  };
}

export type AuditType = 
  | 'contract-to-invoice'
  | 'contract-to-booking'
  | 'contract-to-provisioning'
  | 'approval-vs-policy'
  | 'approval-vs-contract';

export interface AuditTypeConfig {
  id: AuditType;
  name: string;
  description: string;
  dataSources: {
    primary: string;
    secondary: string;
    tertiary?: string;
  };
  keyFields: string[];
  icon: string;
  color: string;
}

export interface ValidationRule {
  id: string;
  category: string;
  condition: string;
  rule: string;
  auditType?: string;
  rubric?: string;
  priority?: 'high' | 'medium' | 'low';
  description?: string;
}